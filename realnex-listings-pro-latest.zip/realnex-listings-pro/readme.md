# RealNex Listings Pro

**Drop-in enhanced replacement for RealNex MP Premier.**

Same core functionality. Four selectable themes. Better cards. Built-in pagination. View toggle.

---

## Installation

1. Upload the `realnex-listings-pro` folder to `/wp-content/plugins/`
2. Activate through the WordPress admin → Plugins
3. Enter your RealNex MP Premier license key under **RealNex Listings Pro → License**
4. Configure settings under **RealNex Listings Pro → Settings**

> **Note:** This plugin reuses your existing `ApiFilterforRealNex_lic_Key` and `api_settings` options, so your existing configuration carries over automatically.

---

## Themes

Select a theme in **Settings → Design Theme**:

| Theme | Style |
|---|---|
| **Classic** | Clean white cards, professional CRE look |
| **Dark Pro** | Dark charcoal background, blue accents, glowing card hovers |
| **Steel Blue** | Corporate navy filter bar, steel-blue accents, white cards |
| **Ember** | Warm charcoal background, orange gradient accents |

Your **Primary Color** setting overrides the theme accent color across all themes.

---

## Pagination

Cards are automatically paginated (12 per page). The paginator shows:
- Prev / Next buttons with arrows
- Smart page number pills (collapses middle pages with `…`)
- Live listing count updates with filters

---

## View Toggle

Users can switch between **Grid** (2-column) and **List** (horizontal) card layouts via the toggle buttons in the results bar.

---

## Shortcodes

Same as the original plugin:

```
[company]                              All listings by Company ID
[company id=12345,1234]               Specific company IDs
[company types=OFC,HC id=12345]       Filter by property type
[company avail=1,2 id=12345]          Filter by availability
[broker]                              All listings by Broker ID
[broker id=12345]                     Specific broker
[property id=12345]                   Single property
[property-widget id=12345]            Compact property widget
```

---

## Changelog

### 2.0.0
- Rebuilt UI with 4 selectable themes (Classic, Dark Pro, Steel Blue, Ember)
- Built-in client-side pagination (12 per page, configurable)
- Grid / List view toggle
- CSS custom properties for easy per-theme overrides
- Cleaner filter bar layout with better mobile responsiveness
- Improved card hover animations (image zoom, shadow lift, accent glow)
- Admin settings page redesigned with theme preview cards
- Shortcode help table in settings
- All original shortcodes, API endpoints, and license checks preserved
- Production proxy base URL: https://api.initial3development.com
