jQuery(function($){
    $(document).ready(function() {

        // ── Display tab: Layout cards ─────────────────────────────────────
        $(document).on('change', '.rnlp-layout-cards input[type="radio"]', function() {
            $('.rnlp-layout-cards .rnlp-layout-card').removeClass('rnlp-layout-selected');
            $(this).closest('.rnlp-layout-card').addClass('rnlp-layout-selected');
        });

        // ── Display tab: Property detail behavior cards ───────────────────
        $(document).on('change', '.rnlp-detail-cards input[type="radio"]', function() {
            $('.rnlp-detail-cards .rnlp-detail-card').removeClass('rnlp-layout-selected');
            $(this).closest('.rnlp-detail-card').addClass('rnlp-layout-selected');
        });

        // ── Display tab: Pill options (background style, font style) ──────
        $(document).on('change', '.rnlp-pill-group input[type="radio"]', function() {
            $(this).closest('.rnlp-pill-group').find('.rnlp-pill-opt').removeClass('rnlp-pill-active');
            $(this).closest('.rnlp-pill-opt').addClass('rnlp-pill-active');
        });

        // ── Display tab: Color dot presets ────────────────────────────────
        $(document).on('click', '.rnlp-color-dot', function() {
            $('.rnlp-color-dot').removeClass('rnlp-color-dot-active');
            $(this).addClass('rnlp-color-dot-active');
            $('#rnlp_primary_color').val($(this).data('color')).trigger('change');
        });

        // ── Map marker image pickers ──────────────────────────────────────
			$('#choose_image_button').click(function() {

				var logo_imag = wp.media({
					title:'Select Image',
					library: {type: 'image'},
					multiple: false,
					button: { text: 'Insert'}
				});

				logo_imag.on('select', function() {
					var logo_selection = logo_imag.state().get('selection').first().toJSON();
					for(prop in logo_selection){
						console.log(prop);
					}
					$('#input_marker_url').val(logo_selection.url);
					$('.marker_image').attr('src',logo_selection.url);
				});

				logo_imag.open();
			}); 
            
            $('#reset_image_button').click(function() {
                
                $('#input_marker_url').val($(this).attr("data-path"));
                $('.marker_image').attr('src',$(this).attr("data-path"));
                return false;
            }); 

			$('#choose_image_button_sold').click(function() {

				var logo_imag = wp.media({
					title:'Select Image',
					library: {type: 'image'},
					multiple: false,
					button: { text: 'Insert'}
				});

				logo_imag.on('select', function() {
					var logo_selection = logo_imag.state().get('selection').first().toJSON();
					for(prop in logo_selection){
						console.log(prop);
					}
					$('#sold_input_marker_url').val(logo_selection.url);
					$('.sold_marker_image').attr('src',logo_selection.url);
				});

				logo_imag.open();
			}); 
            
            $('#reset_sold_image_button').click(function() {
                
                $('#sold_input_marker_url').val($(this).attr("data-path"));
                $('.sold_marker_image').attr('src',$(this).attr("data-path"));
                return false;
            }); 
			
		});
});