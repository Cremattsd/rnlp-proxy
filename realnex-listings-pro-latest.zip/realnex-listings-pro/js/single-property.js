// image viewer
jQuery(document).ready(function($) {

  window.rnlpInitSingleProperty = function(context) {
    var $context = context ? $(context) : $(document);

    $context.find('.property_images').each(function () {
      var $gallery = $(this);
      if ($gallery.data('rnlp-gallery-ready')) return;
      $gallery.data('rnlp-gallery-ready', true);

      var $wrap = $gallery.closest('.rnlp-sp-gallery');
      var $thumbs = $wrap.find('.thumbnails');
      var navSelector = $thumbs.length ? $thumbs : null;

      if ($gallery.children().length > 1 && $.fn.slick) {
        $gallery.slick({
          autoplay: false,
          infinite: true,
          slidesToShow: 1,
          slidesToScroll: 1,
          dots: false,
          focusOnSelect: true,
          arrows: true,
          asNavFor: navSelector
        });
      }

      if ($thumbs.length && !$thumbs.data('rnlp-thumbs-ready') && $.fn.slick) {
        $thumbs.data('rnlp-thumbs-ready', true);
        $thumbs.slick({
          slidesToShow: 4,
          slidesToScroll: 1,
          asNavFor: $gallery,
          dots: false,
          arrows: false,
          centerMode: false,
          infinite: true,
          focusOnSelect: true,
          variableWidth: false
        });
      }

      if ($.fn.slickLightbox) {
        $gallery.slickLightbox({
          src: 'data-src',
          itemSelector: '.image img',
          caption: function (element) {
            return $(element).attr('alt');
          }
        });
      }
    });

    // ── Single property photo carousel ──────────────────────────────────
    $context.find('.rnlp-sp-carousel').each(function () {
      var wrap = this;
      if (wrap.dataset.rnlpCarouselReady) return;
      wrap.dataset.rnlpCarouselReady = '1';

      var track   = wrap.querySelector('.rnlp-carousel-track');
      var slides  = wrap.querySelectorAll('.rnlp-carousel-slide');
      var total   = slides.length;
      var current = 0;
      if (!track || total <= 1) return;

      var prevBtn = wrap.querySelector('.rnlp-carousel-prev');
      if (!prevBtn) {
        prevBtn = document.createElement('button');
        prevBtn.className = 'rnlp-carousel-btn rnlp-carousel-prev';
        prevBtn.type = 'button';
        prevBtn.setAttribute('aria-label', 'Previous photo');
        prevBtn.innerHTML = '&#8249;';
        wrap.appendChild(prevBtn);
      }

      var nextBtn = wrap.querySelector('.rnlp-carousel-next');
      if (!nextBtn) {
        nextBtn = document.createElement('button');
        nextBtn.className = 'rnlp-carousel-btn rnlp-carousel-next';
        nextBtn.type = 'button';
        nextBtn.setAttribute('aria-label', 'Next photo');
        nextBtn.innerHTML = '&#8250;';
        wrap.appendChild(nextBtn);
      }

      var counterWrap = wrap.querySelector('.rnlp-carousel-counter') || wrap.querySelector('.rnlp-photo-counter');
      if (!counterWrap) {
        counterWrap = document.createElement('div');
        counterWrap.className = 'rnlp-carousel-counter';
        wrap.appendChild(counterWrap);
      }

      var strip = wrap.nextElementSibling;
      if (strip && !strip.classList.contains('rnlp-thumb-strip')) strip = null;
      if (!strip) {
        strip = document.createElement('div');
        strip.className = 'rnlp-thumb-strip';
        Array.prototype.forEach.call(slides, function (slide, i) {
          var img = slide.querySelector('img');
          if (!img) return;
          var thumb = document.createElement('img');
          thumb.src = img.src;
          thumb.className = 'rnlp-thumb' + (i === 0 ? ' active' : '');
          thumb.dataset.index = i;
          thumb.alt = img.alt || ('Photo ' + (i + 1));
          strip.appendChild(thumb);
        });
        wrap.parentNode.insertBefore(strip, wrap.nextSibling);
      }
      var thumbs = strip.querySelectorAll('.rnlp-thumb');

      function update(idx) {
        current = ((idx % total) + total) % total;
        counterWrap.textContent = (current + 1) + ' / ' + total;
        Array.prototype.forEach.call(thumbs, function(t, i) {
          t.classList.toggle('active', i === current);
        });
      }

      function goTo(idx) {
        var nextIndex = ((idx % total) + total) % total;
        if ($.fn.slick && $(track).hasClass('slick-initialized')) {
          $(track).slick('slickGoTo', nextIndex);
          return;
        }
        track.style.transform = 'translateX(-' + (nextIndex * 100) + '%)';
        update(nextIndex);
      }

      Array.prototype.forEach.call(thumbs, function (thumb) {
        thumb.addEventListener('click', function () { goTo(parseInt(this.dataset.index, 10)); });
      });

      if ($.fn.slick) {
        $(track)
          .on('afterChange', function (event, slick, slickCurrent) {
            update(slickCurrent);
          })
          .slick({
            autoplay: false,
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: false,
            arrows: true,
            prevArrow: $(prevBtn),
            nextArrow: $(nextBtn),
            adaptiveHeight: false
          });
      } else {
        prevBtn.addEventListener('click', function () { goTo(current - 1); });
        nextBtn.addEventListener('click', function () { goTo(current + 1); });
      }
      update(0);

      // Arrow key navigation (scoped to when popup or page is visible)
      function onKey(e) {
        if (e.key === 'ArrowLeft')  goTo(current - 1);
        if (e.key === 'ArrowRight') goTo(current + 1);
      }
      document.addEventListener('keydown', onKey);

      // Lightbox on main photo click
      wrap.addEventListener('click', function (e) {
        var img = e.target.closest('.rnlp-carousel-img');
        if (!img) return;
        var activeImg = slides[current] && slides[current].querySelector('img');
        var src = (activeImg && (activeImg.dataset.fullsrc || activeImg.src)) || img.dataset.fullsrc || img.src;
        var lb = document.createElement('div');
        lb.className = 'rnlp-lightbox';
        lb.innerHTML = '<img src="' + src + '" alt=""><button class="rnlp-lightbox-close" aria-label="Close">×</button>';
        lb.addEventListener('click', function (ev) {
          if (ev.target === lb || ev.target.classList.contains('rnlp-lightbox-close')) lb.remove();
        });
        document.body.appendChild(lb);
      });
    });

    $context.find('.rnlp-sp-copy-url').each(function () {
      var btn = this;
      if (btn.dataset.rnlpCopyReady) return;
      btn.dataset.rnlpCopyReady = '1';
      btn.addEventListener('click', function() {
        var url = btn.dataset.url || window.location.href;
        if (navigator.clipboard) {
          navigator.clipboard.writeText(url).then(function(){
            var orig = btn.textContent;
            btn.textContent = 'Copied';
            setTimeout(function(){ btn.textContent = orig; }, 2000);
          });
        } else {
          window.prompt('Copy URL:', url);
        }
      });
    });
  };

  // window.onload = () => {$('#preloader').addClass('d-none')};
  $('#preloader').addClass('d-none');
  window.rnlpInitSingleProperty(document);

  if ($(".property-content")[0]) {
    const markerImg = $("#marker");
    const iconUrl = markerImg.data('prop-status') === 'SOLD' ? markerImg.data('src-sold') : markerImg.attr('src');
    const article = document.querySelector("#map");
    const lng = +article.dataset.lng;
    const lat = +article.dataset.lat;
    const position = {lat: lat, lng: lng};

    if (window.NEX_MAP_ID === 'googlemap') {
      function initMap() {
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 11,
          center: position,
          options: {
            gestureHandling: 'greedy'
          }
        });


        const marker = new google.maps.Marker({
          position,
          map,
          title: article.dataset.title,
          address: article.dataset.address,
        });

        marker.setIcon(iconUrl);

      }
      window.initMap = initMap;
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${window.GOOGLE_MAPS_API_KEY}&libraries=geometry,drawing,places&v=weekly&callback=initMap`;
      document.head.appendChild(script);
    }else {
      const map = L.map('map').setView([lat, lng], 15);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

      if (position.lat && position.lng) {
        const markerIcon = L.icon({
          iconUrl,
          iconSize: [48, 48],
        });
        L.marker([position.lat, position.lng], {icon: markerIcon}).addTo(map);
      }
      window.rnlpSPMap = map;
      setTimeout(function() { map.invalidateSize(); }, 300);
    }
    const inputElement = document.querySelector('#tab4'); // replace 'inputId' with your input's id

    inputElement.addEventListener('input', function(event) {
      if (event.target.checked){
        window.dispatchEvent(new Event('resize'));
      }
    });

  }

});
