(function($) {
  'use strict';

  var mode = window.RNLP_DETAIL_MODE || 'page';
  if (mode !== 'popup') return;

  var $overlay = $(
    '<div class="rnlp-detail-popup-overlay" style="display:none" aria-hidden="true">' +
      '<div class="rnlp-detail-popup-modal" role="dialog" aria-modal="true">' +
        '<button class="rnlp-detail-popup-close" type="button" aria-label="Close">×</button>' +
        '<div class="rnlp-detail-popup-scroll">' +
          '<div class="rnlp-detail-popup-content"></div>' +
        '</div>' +
      '</div>' +
    '</div>'
  );

  $('body').append($overlay);

  var $content = $overlay.find('.rnlp-detail-popup-content');
  var activeRequest = null;

  function openModal(url) {
    $('body').addClass('rnlp-detail-popup-open');
    $overlay.attr('aria-hidden', 'false').fadeIn(120);
    $content.html('<div class="rnlp-detail-popup-loading">Loading property details...</div>');

    if (activeRequest && activeRequest.abort) {
      activeRequest.abort();
    }

    activeRequest = $.ajax({ url: url, method: 'GET' })
      .done(function(html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var detail = doc.querySelector('.rnlp-sp-wrap');
        if (!detail) {
          window.location.href = url;
          return;
        }
        $content.empty().append(detail);
        $overlay.find('.rnlp-detail-popup-scroll').scrollTop(0);

        if (window.rnlpInitSingleProperty) {
          window.rnlpInitSingleProperty($content[0]);
        }
        if (window.rnlpSPMap) {
          setTimeout(function() { window.rnlpSPMap.invalidateSize(); }, 300);
        }
      })
      .fail(function(xhr, status) {
        if (status !== 'abort') {
          window.location.href = url;
        }
      });
  }

  function closeModal() {
    if (activeRequest && activeRequest.abort) {
      activeRequest.abort();
      activeRequest = null;
    }
    $overlay.fadeOut(120, function() {
      $overlay.attr('aria-hidden', 'true');
      $content.empty();
      $('body').removeClass('rnlp-detail-popup-open');
    });
  }

  $(document).on('click', '.rnlp-card-link, .rnlp-widget-card-link, .rnlp-sp-more-card', function(e) {
    var url = this.href;
    if (!url || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || this.target === '_blank') {
      return;
    }
    e.preventDefault();
    openModal(url);
  });

  $overlay.on('click', function(e) {
    if (e.target === this) {
      closeModal();
    }
  });

  $overlay.on('click', '.rnlp-detail-popup-close', function() {
    closeModal();
  });

  $(document).on('keydown', function(e) {
    if (e.key === 'Escape' && $overlay.is(':visible')) {
      closeModal();
    }
  });
})(jQuery);
