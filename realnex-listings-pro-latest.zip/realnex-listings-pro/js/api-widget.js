jQuery(function ($) {
    window.onload = () => {jQuery('.preloader').addClass('d-none')};
  });
  
  
  
  