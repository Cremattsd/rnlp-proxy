// ─── RealNex Listings Pro · Filter Engine ────────────────────────────────────
// Pure filter functions + DOM wiring. No Isotope, no lodash — just RAF chunking.

class FilterState {
  constructor() {
    this.initialState = {
      saleLease:       [],  // empty = show all availability types
      propertyTypes:   [],
      textSearchValue: '',
      brokerEmail:     '',
      buildingSize:    { min: 0, max: 0 },
      buildingPrice:   { min: 0, max: 0 },
      availableSpace:  { min: 0, max: 0 },
    };
    this.state    = { ...this.initialState };
    this.listener = null;
  }

  getState()    { return this.state; }
  resetState()  { this.setState(this.initialState); }

  setState(newState) {
    this.state = { ...this.state, ...newState };
    this.notify('state changed');
  }

  registerListener(listener) { this.listener = listener; }

  async notify() {
    const { data: listings } = window.nexFilterPlugin;
    const filteredData = await filterItemsByUIFilters( listings, this );
    if ( this.listener ) this.listener({ state: this.state, filteredData });
  }
}

// ── Pure filter functions ────────────────────────────────────────────────────

const filterItemsBySaleLease = (data, filterKeys) => {
  if (!filterKeys || filterKeys.length === 0) return data;
  return data.filter(({ listingType }) => filterKeys.includes(listingType));
};

const filterItemsByPropertyType = (data, filterKeys) => {
  if (filterKeys.length === 0) return data;
  return data.filter(({ propertyType }) =>
    propertyType.some(type => filterKeys.includes(type))
  );
};

const filterItemsByTextSearch = (data, value) => {
  if (!value) return data;
  return data.filter(({ fullAddress }) =>
    fullAddress.toLowerCase().includes(value.toLowerCase())
  );
};

const filterItemsByBrokerEmail = (data, value) => {
  if (!value) return data;
  const email = String(value).toLowerCase();
  return data.filter(({ brokerEmails }) =>
    Array.isArray(brokerEmails) && brokerEmails.map(String).map(v => v.toLowerCase()).includes(email)
  );
};

const filterItemsMinMax = (data, min, max, dataFilterKey) => {
  if (!min && !max) return data;
  return data.filter((el) => {
    const value = el[dataFilterKey];
    if (!value) return false;
    if (min && max) return value >= min && value <= max;
    if (min) return value >= min;
    if (max) return value <= max;
    return false;
  });
};

const handleMinMaxFilters = ({ min, max }) => {
  let newState = { min, max };
  if (max && min > max) { newState.min = max; newState.max = min; }
  return newState;
};

const handleMinMaxAvailableSpace = ({
  filter: { min: filterMin, max: filterMax },
  availableSpace: { min: objectMin, max: objectMax },
}) => {
  if (!filterMin && !filterMax) return true;
  return !(filterMax < objectMin || filterMin > objectMax);
};

let timer;
const debounce = (callback) => {
  clearTimeout(timer);
  timer = setTimeout(callback, 500);
};

// Process filter pipeline in thirds across animation frames to avoid jank on large datasets.
const renderInChunks = (pipeline, dataset) => {
  const chunkSize = Math.ceil(pipeline.length / 3);
  let result      = dataset;
  return new Promise((resolve) => {
    function step() {
      for (let i = 0; i < chunkSize && pipeline.length > 0; i++) {
        result = pipeline.shift()(result);
      }
      pipeline.length > 0 ? requestAnimationFrame(step) : resolve(result);
    }
    requestAnimationFrame(step);
  });
};

const filterItemsByUIFilters = (listings, filterState) => {
  const { saleLease, propertyTypes, textSearchValue, brokerEmail, availableSpace, ...ranges } = filterState.getState();
  return renderInChunks( [
    items => filterItemsBySaleLease(items, saleLease),
    items => filterItemsByPropertyType(items, propertyTypes),
    items => filterItemsByTextSearch(items, textSearchValue),
    items => filterItemsByBrokerEmail(items, brokerEmail),
    items => filterItemsMinMax(items, ranges.buildingSize.min,  ranges.buildingSize.max,  'buildingSize'),
    items => filterItemsMinMax(items, ranges.buildingPrice.min, ranges.buildingPrice.max, 'buildingPrice'),
    items => items.filter( item => handleMinMaxAvailableSpace({ filter: availableSpace, availableSpace: item.availableSpace }) ),
  ], listings );
};

// ── DOM wiring ───────────────────────────────────────────────────────────────

jQuery(document).ready(function ($) {
  if (!window.nexFilterPlugin) return;

  const filterState = new FilterState();
  window.nexFilterPlugin.store = filterState;

  // Expose applyFilters so listing-tpl.php pagination can hook in
  window.nexFilterPlugin.applyFilters = function () { filterState.notify(); };
  window.nexFilterPlugin.setBrokerFilter = function (email, name) {
    filterState.setState({ brokerEmail: String(email || '').toLowerCase() });
    const bar = document.getElementById('rnlp-broker-active-filter');
    const title = document.getElementById('rnlp-broker-active-title');
    if (bar && title) {
      title.textContent = name ? 'Listings by ' + name : '';
      bar.style.display = email ? 'flex' : 'none';
    }
  };
  window.nexFilterPlugin.clearBrokerFilter = function () {
    filterState.setState({ brokerEmail: '' });
    const bar = document.getElementById('rnlp-broker-active-filter');
    if (bar) bar.style.display = 'none';
  };

  // ── Filter listener: direct DOM show/hide (no Isotope) ──────────────────
  filterState.registerListener(({ filteredData }) => {
    const idItemsToShow = filteredData.map(({ id }) => String(id));
    document.querySelectorAll('#nex-items-container .rnlp-card').forEach(function (card) {
      const id = String(card.getAttribute('data-listing-id') || '');
      // Setting style.display triggers the MutationObserver in listing-tpl.php
      // which calls renderPage() to update pagination automatically.
      card.style.display = idItemsToShow.includes(id) ? '' : 'none';
    });
    // Update count immediately (pagination JS will also update it via renderPage)
    const countEl = document.getElementById('rnlp-results-count');
    if (countEl) {
      const n = idItemsToShow.length;
      countEl.textContent = n + ' listing' + (n !== 1 ? 's' : '');
    }
  });

  // ── Availability checkboxes ──────────────────────────────────────────────
  $(document).on('change', '.rnlp-avail-check', function () {
    const checked = [];
    $('.rnlp-avail-check:checked').each(function () { checked.push(this.value); });
    filterState.setState({ saleLease: checked });
  });

  // ── Property type checkboxes ─────────────────────────────────────────────
  $('#nex-properties input[type="checkbox"]').on('change', function () {
    const value       = this.value;
    const checkboxes  = $('#nex-properties input[type="checkbox"]');
    const allCheckbox = $('#nex-properties input[type="checkbox"][value="ALL"]');

    if (value === 'ALL') {
      if ($(this).is(':checked')) {
        checkboxes.prop('checked', true);
        const newState = checkboxes.not(allCheckbox).map(function () { return this.value; }).get();
        filterState.setState({ propertyTypes: newState });
      } else {
        checkboxes.prop('checked', false);
        filterState.setState({ propertyTypes: [] });
      }
    } else {
      let newState = [...filterState.getState().propertyTypes];
      if ($(this).is(':checked')) {
        newState.push(value);
      } else {
        newState = newState.filter(t => t !== value);
        allCheckbox.prop('checked', false);
      }
      filterState.setState({ propertyTypes: newState });
      if ($('#nex-properties input[type="checkbox"]:checked').length === checkboxes.length - 1) {
        allCheckbox.prop('checked', true);
      }
    }
  });

  // ── Text search ──────────────────────────────────────────────────────────
  $('#nex-text-search').on('input', function () {
    const value = this.value;
    debounce(() => filterState.setState({ textSearchValue: value }));
  });

  // ── Advanced filters apply ───────────────────────────────────────────────
  $('#nex-advanced-filters-apply-btn').on('click', function () {
    let newFilterState = {};
    [['building-size', 'buildingSize'], ['building-price', 'buildingPrice'], ['building-available-space', 'availableSpace']]
      .forEach(([idElPrefix, stateKey]) => {
        const minEl    = $(`#${idElPrefix}-min`);
        const maxEl    = $(`#${idElPrefix}-max`);
        const newState = handleMinMaxFilters({
          min: parseInt(minEl.val() || '0', 10),
          max: parseInt(maxEl.val() || minEl.val() || '0', 10),
        });
        if (newState.max && !newState.min) newState.min = 1;
        minEl.val(newState.min || '');
        maxEl.val(newState.max || '');
        newFilterState[stateKey] = newState;
      });
    filterState.setState(newFilterState);
    $('#nex-advanced-container').fadeOut(300);
  });

  // ── Reset ────────────────────────────────────────────────────────────────
  $('#nex-reset-btn').on('click', function () {
    filterState.resetState();
    const bar = document.getElementById('rnlp-broker-active-filter');
    if (bar) bar.style.display = 'none';
    // Reset availability checkboxes to default (For Lease + For Sale checked)
    $('.rnlp-avail-check').each(function () {
      $(this).prop('checked', this.value === 'For_Lease' || this.value === 'For_Sale');
    });
    $('#nex-properties input[type="checkbox"]').prop('checked', false);
    $('#nex-text-search').val('');
    ['building-size', 'building-price', 'building-available-space'].forEach((prefix) => {
      $(`#${prefix}-min`).val('');
      $(`#${prefix}-max`).val('');
    });
    // Show all cards (clear any inline display:none from filter)
    document.querySelectorAll('#nex-items-container .rnlp-card').forEach(function (c) {
      c.style.display = '';
    });
  });

  $(document).on('click', '#rnlp-broker-filter-reset', function () {
    if (window.nexFilterPlugin.clearBrokerFilter) {
      window.nexFilterPlugin.clearBrokerFilter();
    }
  });

  // ── Advanced panel toggle ────────────────────────────────────────────────
  $('#nex-advanced-btn').on('click', function () {
    $('#nex-advanced-container').fadeToggle(300);
  });

  // ── Dropdown outside-click close ─────────────────────────────────────────
  $(document).on('click', function (e) {
    if (!$(e.target).closest('#nex-advanced-container').length &&
        !$(e.target).closest('#nex-advanced-btn').length) {
      $('#nex-advanced-container').fadeOut(300);
    }
  });

  // ── Property type sub-group accordion ────────────────────────────────────
  $('.nex-dropdown-group-title').each(function () {
    const $title          = $(this);
    const $parentCheckbox = $title.find('.nex-dropdown-group-title__check');
    const $arrow          = $title.find('.nex-dropdown-arrow');
    const $group          = $title.closest('.nex-dropdown-group');
    const $childCheckboxes = $group.find('.nex-dropdown-list-item__check');

    $arrow.on('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      $group.toggleClass('open');
    });

    $parentCheckbox.on('change', function () {
      $childCheckboxes.prop('checked', $parentCheckbox.prop('checked'));
      updateParentState($parentCheckbox, $childCheckboxes);
    });

    $childCheckboxes.on('change', function () {
      updateParentState($parentCheckbox, $childCheckboxes);
    });
  });

  function updateParentState($parentCheckbox, $childCheckboxes) {
    const checkedCount = $childCheckboxes.filter(':checked').length;
    if (checkedCount === 0) {
      $parentCheckbox.prop('indeterminate', false).prop('checked', false);
    } else if (checkedCount === $childCheckboxes.length) {
      $parentCheckbox.prop('indeterminate', false).prop('checked', true);
    } else {
      $parentCheckbox.prop('indeterminate', true);
    }
  }
});
