const createClusterSvg = function (color, childCount) {
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
            <circle cx="20" cy="20" r="15" stroke-width="10" stroke="${color}" fill="${color}" stroke-opacity="0.6" />
            <text x="50%" y="50%" text-anchor="middle" fill="white" font-size="12px" dy=".3em">
              ${childCount}
            </text>
          </svg>`
};
const createInfoWindowContent = function ({name, img, listingType, address, price, buildingSize, readableTypes, url}) {
  return `<div class="info_content flex flex-col">
              <div class="relative"><img class="w-48 aspect-[4/3] block" src="${img + '?h=144&mode=max&200=default&autorotate=true'}" alt=""><div class="gmap-title">${listingType.replaceAll('_', ' ')}</div></div>
              <div class="w-48 py-1">
                  <h4 class="!leading-3 !font-bold !text-lg !text-black">${name}</h4>
                  ${ address ? `<span class="span-p">Address: ${address}</span>` : ''}
                  ${price ? `<span class="span-p">${(
                        Math.floor(price)).toLocaleString('en-US', {
                      style: 'currency',
                      currency: 'USD',
                      minimumFractionDigits: 0,
                      maximumFractionDigits: 0
                    })
                    }</span>` : ''}
                  ${buildingSize ? `<span class="span-p">${buildingSize.toLocaleString('en-US', {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 0
                  })} SF</span>` : ''}
                  <span class="span-p">${readableTypes.join(', ')}</span>
                  <a class="py-1 px-2 cbg-color block w-full text-center !text-white !no-underline" href="${url}">View Listing</a>
              </div>
          </div>`;
};

const createPhotoIcon = function(item) {
  const img = item.img ? item.img + '?h=60&mode=max&autorotate=true' : '';
  return L.divIcon({
    className:   'rnlp-photo-marker',
    html:        `<div class="rnlp-photo-marker-inner"${img ? ' style="background-image:url(' + img + ')"' : ''}></div>`,
    iconSize:    [54, 54],
    iconAnchor:  [27, 54],
    popupAnchor: [0, -58],
  });
};

const createMarkers = function ({items, markerIcon, markerIconSold}) {
  const markers = items.map((item) => {
    if (!item.geo.lat || !item.geo.lng) return null;
    const icon = createPhotoIcon(item);
    const popupContent = createInfoWindowContent(item);
    const elId = item.domId || item.id;
    const marker =  L.marker([item.geo.lat, item.geo.lng], {icon, elId}).bindPopup(popupContent);
    marker.on('popupopen', function(e) {
      const element = jQuery(`#${elId}`);
      if (!element || !element.length || !element[0]) return;
      element.removeClass('clicked');
      // Force reflow
      void element[0].offsetWidth;
      // Add animation class after a delay
      setTimeout(() => {
        if (!element[0]) return;
        element[0].scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'start'
        });
        element.addClass('clicked');
      }, 50); // Adjust delay as needed
    });

    return marker;
  });
  return markers.filter((marker) => !!marker);
};
const createMarkerClusterer = function ({map, markers, accentColor, markerClusterer}) {
  if (markerClusterer) markerClusterer.clearLayers();
  const newMarkerClusterer = L.markerClusterGroup({
    iconCreateFunction: function(cluster) {
      return L.divIcon({
        html: createClusterSvg(accentColor, cluster.getChildCount()),
        iconSize: L.point(40, 40)
      });
    }
  });
  markers.forEach((marker) => newMarkerClusterer.addLayer(marker));
  // add the cluster group to the map
  map.addLayer(newMarkerClusterer);
  return newMarkerClusterer;
};

const updateMarkers = ({filteredData}) => {
  if (!(window.nexFilterPlugin && window.nexFilterPlugin.store && typeof window.nexFilterPlugin.store.getMapState === 'function')) return;
  const {map, accentColor, markerClusterer} = window.nexFilterPlugin.store.getMapState();
  const newMarkers = createMarkers({items: filteredData});
  const newMarkerClusterer = createMarkerClusterer({map, markers: newMarkers, markerClusterer, accentColor});
  if (window.nexFilterPlugin && window.nexFilterPlugin.store && typeof window.nexFilterPlugin.store.setMapState === 'function') {
    window.nexFilterPlugin.store.setMapState({markers: newMarkers, markerClusterer: newMarkerClusterer});
  }
}
const boundMapWithMarkers = (filterState) => {
  const { map, markers } = filterState.getMapState();
  if (!map || markers.length === 0) return;
  const bounds = new L.LatLngBounds();
  markers.forEach((marker) => {
    bounds.extend(marker.getLatLng());
  });
  map.fitBounds(bounds);
}


const getElIdsOfMarkersInViewport = (filterState) => {
  const {map, markers} = filterState.getMapState();
  const bounds = map.getBounds();
  if (!bounds) return markers;
  return markers.filter(marker => bounds.contains(marker.getLatLng())).map(({options}) => options.elId);
};

const _centerOnZip = function(map, zip, zoom) {
  if (!zip) return;
  fetch('https://nominatim.openstreetmap.org/search?format=json&postalcode=' + encodeURIComponent(zip) + '&countrycodes=us&limit=1', {
    headers: {'User-Agent': 'RealNexListingsPro/1.0'}
  })
  .then(function(r) { return r.json(); })
  .then(function(data) {
    if (data && data[0]) {
      map.setView([parseFloat(data[0].lat), parseFloat(data[0].lon)], zoom);
    }
  })
  .catch(function() {});
};

jQuery(document).ready(function() {
  const markerImg = document.querySelector("#marker");
  if (!markerImg) return;
  const accentColor = markerImg.getAttribute('data-color');
  if (!(window.nexFilterPlugin && window.nexFilterPlugin.data)) return;
  const { data } = window.nexFilterPlugin;
  const mapCfg   = window.RNLP_MAP_CONFIG || {};
  const defaultZoom = mapCfg.defaultZoom || 10;
  const defaultZip  = mapCfg.defaultZip  || '';

  const mapEl = document.getElementById('map');
  if (!mapEl) return;
  const map = L.map('map').setView([40.7128, -74.0060], defaultZoom);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

  const markers = createMarkers({items: data});

  // create a marker cluster group
  const markerClusterer = createMarkerClusterer({map, markers, accentColor});

  // fit bounds if markers exist, else center on default ZIP
  if (markers.length > 0) {
    try { map.fitBounds(markerClusterer.getBounds()); } catch(e) {}
  } else if (defaultZip) {
    _centerOnZip(map, defaultZip, defaultZoom);
  }

  if (window.nexFilterPlugin &&
      window.nexFilterPlugin.store &&
      typeof window.nexFilterPlugin.store.setMapState === 'function') {
    window.nexFilterPlugin.store.setMapState({
      markers, map, markerClusterer, accentColor,
      updateMarkers, boundMapWithMarkers, getElIdsOfMarkersInViewport
    });
  }

  map.on('moveend', () => {
    if (window.nexFilterPlugin && window.nexFilterPlugin.store && typeof window.nexFilterPlugin.store.notifyMapUpdated === 'function') {
      window.nexFilterPlugin.store.notifyMapUpdated();
    }
  });
  map.on('zoomend', () => {
    if (window.nexFilterPlugin && window.nexFilterPlugin.store && typeof window.nexFilterPlugin.store.notifyMapUpdated === 'function') {
      window.nexFilterPlugin.store.notifyMapUpdated();
    }
  });
  setTimeout(() => {
    window.dispatchEvent(new Event('resize'));
  }, 500);
});
