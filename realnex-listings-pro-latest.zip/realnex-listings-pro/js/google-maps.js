const createInfoWindowContent = function ({name, img, type, address, price, sf, readableTypes, url}) {
  return `<div class="info_content flex flex-col">
              <div class="relative"><img class="w-48 aspect-[4/3] block" src="${img + '?h=144&mode=max&200=default&autorotate=true'}" alt=""><div class="gmap-title">${type.replaceAll('_', ' ')}</div></div>
              <div class="w-48 py-1">
                  <h4 class="!leading-3 !font-bold !text-lg !text-black">${name}</h4>
                  ${ address ? `<span class="span-p">Address: ${address}</span>` : ''}
                  ${price ? `<span class="span-p">${(
                      Math.floor(price)).toLocaleString('en-US', {
                      style: 'currency',
                      currency: 'USD',
                      minimumFractionDigits: 0,
                      maximumFractionDigits: 0
                    })
                  }</span>` : ''}
                  ${sf ? `<span class="span-p">${sf.toLocaleString('en-US', {
                      minimumFractionDigits: 0,
                      maximumFractionDigits: 0
                    })} SF</span>` : ''}
                  <span class="span-p">${readableTypes.join(', ')}</span>
                  <a class="py-1 px-2 cbg-color block w-full text-center !text-white !no-underline" href="${url}">View Listing</a>
              </div>
          </div>`
      ;
};
const createClusterSvg = function (color) {
  const encoded = window.btoa('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve"> <circle cx="20" cy="20" r="15" stroke-width="10" stroke="' + color + '" fill="' + color + '" stroke-opacity="0.6" /> </svg>');
  return ('data:image/svg+xml;base64,' + encoded);
};
const createMarkerClusterer = function ({map, markers, markerImg, markerClusterer}) {
  if (markerClusterer) markerClusterer.clearMarkers();
  return new MarkerClusterer(map, markers, {
    imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m',
    ignoreHidden: true,
    styles: [{
      width: 40,
      height: 40,
      url: createClusterSvg(markerImg.getAttribute('data-color')),
      textColor: 'white',
      textSize: 12,
    }]
  });
};

const createMarkers = function ({items, map, markerInfoWindow, markerImg}) {
  const markers = items.map(function (item, index) {
    if (!item.geo.lat || !item.geo.lng) return null;
    const marker = new google.maps.Marker({
      position: item.geo,
      index,
      title: item.name,
      elId: item.domId || item.id,
      lat: item.geo.lat,
      lng: item.geo.lng,
      name: item.name,
      img: item.img,
      type: item.listingType,
      address: item.address,
      price: item.buildingPrice,
      sf: item.buildingSize,
      readableTypes: item.readableTypes,
      url: item.url,
    })
    marker.setIcon(markerImg.getAttribute(`data-src${item.listingType === 'SOLD' ? '-sold' : ''}`));
    google.maps.event.addListener(marker, 'click', function() {
      const element = jQuery(`#${marker.elId}`);
      markerInfoWindow.close();
      markerInfoWindow.setContent(createInfoWindowContent(marker));
      markerInfoWindow.open(map, marker);
      element.removeClass('clicked');
      // Force reflow
      void element[0].offsetWidth;
      // Add animation class after a delay
      setTimeout(() => {
        element[0].scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'start'
        });
        element.addClass('clicked');
      }, 50); // Adjust delay as needed
    });
    return marker
  })
  return markers.filter(marker => !!marker);
};

const updateMarkers = ({filteredData}) => {
  const {map, markerImg, markerClusterer, markerInfoWindow} = window.nexFilterPlugin.store.getMapState();
  const newMarkers = createMarkers({items: filteredData, map, markerInfoWindow, markerImg});
  const newMarkerClusterer = createMarkerClusterer({map, markers: newMarkers, markerClusterer, markerImg});
  window.nexFilterPlugin.store.setMapState({markers: newMarkers, markerClusterer: newMarkerClusterer});
}
const boundMapWithMarkers = (filterState) => {
  const { map, markers } = filterState.getMapState();
  if (!map || markers.length === 0) return;
  const bounds = new google.maps.LatLngBounds();
  markers.forEach((marker) => {
    bounds.extend(marker.getPosition());
  });
  map.fitBounds(bounds);
}
const getElIdsOfMarkersInViewport = (filterState) => {
  const {map, markers} = filterState.getMapState();
  const bounds = map.getBounds();
  if (!bounds) return markers;
  return markers.filter(marker => bounds.contains(marker.getPosition())).map(({elId}) => (elId));
};
jQuery(document).ready(function() {
  const markerImg = document.querySelector("#marker");
  let markerInfoWindow = null;
  async function initMap() {
    // Request needed libraries.
    const { Map } = await google.maps.importLibrary("maps");

    const map = new Map(document.getElementById("map"), {
      zoom: 4,
      center: { lat: 37.0902, lng: -95.7129 },
      mapId: "MAP_ID",
      mapTypeId: 'roadmap',
      gestureHandling: 'greedy',
      disableDefaultUI: true,
      zoomControl: true,
    });
    markerInfoWindow = new google.maps.InfoWindow();
    const markers = createMarkers({
      items: window.nexFilterPlugin.data, map, markerInfoWindow, markerImg
    });
    const markerClusterer = createMarkerClusterer({map, markers, markerImg});

    window.nexFilterPlugin.store.setMapState({
      markers, map, markerImg, markerClusterer, markerInfoWindow,
      updateMarkers, boundMapWithMarkers, getElIdsOfMarkersInViewport
    });

    const bounds = new google.maps.LatLngBounds();
    markers.forEach((marker) => {
      bounds.extend(marker.getPosition());
    });
    map.fitBounds(bounds);

    // Listeners
    google.maps.event.addListener(map, 'click', function() {
      markerInfoWindow.close();
    });
    google.maps.event.addListener(map, 'dragend', () => window.nexFilterPlugin.store.notifyMapUpdated());

    google.maps.event.addListener(map, 'zoom_changed', () => window.nexFilterPlugin.store.notifyMapUpdated());
  }

  window.initMap = initMap;
  const script = document.createElement('script');
  script.src = `https://maps.googleapis.com/maps/api/js?key=${window.GOOGLE_MAPS_API_KEY}&libraries=geometry,drawing,places&v=weekly&callback=initMap`;
  document.head.appendChild(script);
});

