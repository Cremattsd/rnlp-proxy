/* RealNex Listings Pro — Lead Capture JS */
(function($){
    'use strict';

    // Inject modal HTML once
    var modalHtml = '<div id="rnlp-lead-overlay" style="display:none">'
        + '<div id="rnlp-lead-modal">'
        + '<button class="rnlp-modal-close" type="button" aria-label="Close">×</button>'
        + '<div class="rnlp-modal-crm-badge">→ RealNex CRM</div>'
        + '<h3 class="rnlp-modal-title">Schedule a Showing</h3>'
        + '<p class="rnlp-modal-prop" id="rnlp-modal-prop-name"></p>'
        + '<div class="rnlp-lead-form">'
        + '<div class="rnlp-lf-group"><label>Full Name <span class="rnlp-req">*</span></label><input type="text" id="rnlp-lf-name" placeholder="Your full name"></div>'
        + '<div class="rnlp-lf-group"><label>Email <span class="rnlp-req">*</span></label><input type="email" id="rnlp-lf-email" placeholder="you@example.com"></div>'
        + '<div class="rnlp-lf-group"><label>Phone</label><input type="tel" id="rnlp-lf-phone" placeholder="(555) 000-0000"></div>'
        + '<div class="rnlp-lf-group"><label>Message</label><textarea id="rnlp-lf-message" rows="3" placeholder="Tell us about your needs…"></textarea></div>'
        + '<div class="rnlp-lf-group rnlp-lf-project" id="rnlp-lf-project-wrap">'
        + '<label>Attach to CRM Project</label>'
        + '<input type="text" id="rnlp-lf-project" placeholder="Project ID (optional)">'
        + '</div>'
        + '<button type="button" id="rnlp-lf-submit" class="rnlp-lf-submit-btn">Submit Inquiry</button>'
        + '<div class="rnlp-lf-status" id="rnlp-lf-status"></div>'
        + '</div>'
        + '</div>'
        + '</div>';

    $('body').append(modalHtml);

    // State
    var currentPropName   = '';
    var currentPropId     = '';
    var currentBrokerEmail = '';

    // Open modal from "Inquire" button on cards or single property page
    $(document).on('click', '.rnlp-inquire-btn', function(e){
        e.preventDefault();
        e.stopPropagation();
        currentPropName    = $(this).data('prop-name')     || '';
        currentPropId      = $(this).data('prop-id')       || '';
        currentBrokerEmail = $(this).data('broker-email')  || '';
        $('#rnlp-modal-prop-name').text(currentPropName);
        $('#rnlp-lf-project').val(rnlpLead.default_project);
        $('#rnlp-lf-status').hide().text('');
        $('#rnlp-lead-overlay').fadeIn(180);
    });

    // Close
    $(document).on('click', '#rnlp-lead-overlay, .rnlp-modal-close', function(e){
        if (e.target === this) {
            $('#rnlp-lead-overlay').fadeOut(150);
        }
    });
    $(document).on('keydown', function(e){
        if (e.key === 'Escape') $('#rnlp-lead-overlay').fadeOut(150);
    });

    // Submit
    $(document).on('click', '#rnlp-lf-submit', function(){
        var name    = $('#rnlp-lf-name').val().trim();
        var email   = $('#rnlp-lf-email').val().trim();
        var phone   = $('#rnlp-lf-phone').val().trim();
        var message = $('#rnlp-lf-message').val().trim();
        var project = $('#rnlp-lf-project').val().trim();

        if (!name || !email) {
            showStatus('Name and email are required.', 'error');
            return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            showStatus('Please enter a valid email address.', 'error');
            return;
        }

        $('#rnlp-lf-submit').prop('disabled', true).text('Submitting…');
        showStatus('', '');

        $.ajax({
            url:  rnlpLead.ajaxurl,
            type: 'POST',
            data: {
                action:          'rnlp_submit_lead',
                nonce:           rnlpLead.nonce,
                rnlp_name:       name,
                rnlp_email:      email,
                rnlp_phone:      phone,
                rnlp_message:    message,
                rnlp_project_id: project,
                rnlp_property:   currentPropName,
                rnlp_prop_id:    currentPropId,
                broker_email:    currentBrokerEmail,
            },
            success: function(res){
                if (res.success) {
                    var d       = res.data;
                    var notice  = d.crm_notice || 'success';
                    var link    = d.crm_link   || '';
                    var html    = '<div class="rnlp-success">&#10003; Inquiry sent! We\'ll be in touch.</div>';
                    if (notice === 'not_connected') {
                        html += '<div class="rnlp-crm-notice">&#128161; <strong>Auto-track leads in RealNex CRM</strong> &mdash; '
                             + (link ? '<a href="' + link + '">Connect CRM &rarr;</a>' : '')
                             + '</div>';
                    } else if (notice === 'no_project') {
                        html += '<div class="rnlp-crm-notice">&#128203; Lead saved to CRM. '
                             + (link ? '<a href="' + link + '" target="_blank">Add a project to auto-track &rarr;</a>' : '')
                             + '</div>';
                    }
                    showHtml(html);
                    $('#rnlp-lf-name, #rnlp-lf-email, #rnlp-lf-phone, #rnlp-lf-message').val('');
                    setTimeout(function(){ $('#rnlp-lead-overlay').fadeOut(200); }, 3200);
                } else {
                    showStatus(res.data.message || 'Submission failed. Please try again.', 'error');
                }
            },
            error: function(){
                showStatus('Network error. Please try again.', 'error');
            },
            complete: function(){
                $('#rnlp-lf-submit').prop('disabled', false).text('Submit Inquiry');
            }
        });
    });

    function showStatus(msg, type){
        var el = $('#rnlp-lf-status');
        el.removeClass('rnlp-status-success rnlp-status-error')
          .addClass(type === 'success' ? 'rnlp-status-success' : 'rnlp-status-error')
          .text(msg);
        if (msg) el.show(); else el.hide();
    }

    function showHtml(html){
        var el = $('#rnlp-lf-status');
        el.removeClass('rnlp-status-success rnlp-status-error')
          .addClass('rnlp-status-success')
          .html(html)
          .show();
    }

})(jQuery);
