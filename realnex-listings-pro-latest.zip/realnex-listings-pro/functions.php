<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Proxy Config ────────────────────────────────────────────────────────────

function rnlp_get_api_base(): string {
    $settings = get_option('api_settings', []);
    $configured = isset($settings['rnlp_api_base_url']) ? esc_url_raw($settings['rnlp_api_base_url']) : '';
    $base_url = $configured ?: 'https://api.initial3development.com';

    if (defined('RNLP_API_BASE_URL') && RNLP_API_BASE_URL) {
        $base_url = RNLP_API_BASE_URL;
    }

    return untrailingslashit(apply_filters('rnlp_api_base_url', $base_url));
}

function rnlp_api_url(string $endpoint = ''): string {
    return rnlp_get_api_base() . '/' . ltrim($endpoint, '/');
}

function rnlp_get_api_environment(): string {
    $host = wp_parse_url(rnlp_get_api_base(), PHP_URL_HOST);
    if ($host === 'api.initial3development.com') {
        return 'production';
    }

    return $host ? 'custom' : 'unknown';
}

function rnlp_get_api_status(bool $force = false): array {
    $cache_key = 'rnlp_api_status';
    if (!$force) {
        $cached = get_transient($cache_key);
        if (is_array($cached)) {
            return $cached;
        }
    }

    $status = [
        'connected'   => false,
        'environment' => rnlp_get_api_environment(),
        'base_url'    => rnlp_get_api_base(),
        'health'      => null,
        'version'     => null,
        'message'     => 'API unavailable',
    ];

    $health = wp_remote_get(rnlp_api_url('health'), ['timeout' => 8]);
    if (is_wp_error($health)) {
        $status['message'] = $health->get_error_message();
        set_transient($cache_key, $status, 5 * MINUTE_IN_SECONDS);
        return $status;
    }

    $health_code = wp_remote_retrieve_response_code($health);
    $health_body = json_decode(wp_remote_retrieve_body($health), true);
    $status['health'] = [
        'code' => $health_code,
        'body' => is_array($health_body) ? $health_body : null,
    ];

    if ($health_code !== 200 || empty($health_body['success'])) {
        $status['message'] = $health_code === 404
            ? 'Health endpoint not found. The API root may return 404 without affecting plugin endpoints.'
            : 'Health check failed';
        set_transient($cache_key, $status, 5 * MINUTE_IN_SECONDS);
        return $status;
    }

    $status['connected'] = true;
    $status['message'] = 'Connected';

    $version = wp_remote_get(rnlp_api_url('version'), ['timeout' => 8]);
    if (!is_wp_error($version)) {
        $version_body = json_decode(wp_remote_retrieve_body($version), true);
        $status['version'] = [
            'code' => wp_remote_retrieve_response_code($version),
            'body' => is_array($version_body) ? $version_body : null,
        ];
        if (!empty($version_body['environment'])) {
            $status['environment'] = sanitize_key($version_body['environment']);
        }
    }

    set_transient($cache_key, $status, 5 * MINUTE_IN_SECONDS);
    return $status;
}

// ─── Plugin Paths ────────────────────────────────────────────────────────────

function pluginPath(): string {
    return plugin_dir_path( __FILE__ );
}

function imagePath(): string {
    return plugin_dir_url( __FILE__ ) . 'templates/img/';
}

// ─── Proxy Communication ─────────────────────────────────────────────────────

// Routes to any RNLP proxy endpoint; serial injection happens server-side.
function rnlp_proxy_request(string $endpoint, array $data): ?array {
    try {
        $resp = wp_remote_post(rnlp_api_url($endpoint), [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($data),
            'timeout' => 30,
        ]);
    } catch (Throwable $e) {
        return null;
    }
    if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) >= 400) {
        return null;
    }
    return json_decode(wp_remote_retrieve_body($resp), true);
}

function rnlp_listing_from_response(?array $response): ?array {
    if (empty($response) || !is_array($response)) {
        return null;
    }

    foreach (['property', 'listing', 'data'] as $key) {
        if (!empty($response[$key]) && is_array($response[$key])) {
            return $response[$key];
        }
    }

    if (isset($response[0]) && is_array($response[0])) {
        return $response[0];
    }

    return $response;
}

function rnlp_listing_matches_id(array $listing, string $listing_id): bool {
    $expected = sanitize_text_field($listing_id);
    if ($expected === '') {
        return false;
    }

    $actual = function_exists('rnlp_listing_id')
        ? rnlp_listing_id($listing)
        : sanitize_text_field($listing['Id'] ?? $listing['ListingId'] ?? $listing['PropertyId'] ?? '');

    return $actual !== '' && (string) $actual === (string) $expected;
}

function rnlp_single_listing_request(string $listing_id): ?array {
    $listing_id = sanitize_text_field($listing_id);
    if ($listing_id === '') {
        return null;
    }

    $serial = get_option('api_settings', [])['rnlp_serial'] ?? '';
    if (empty($serial)) {
        return null;
    }

    $single = rnlp_proxy_request('/listing/' . rawurlencode($listing_id), [
        'serial'     => $serial,
        'listing_id' => $listing_id,
        'id'         => $listing_id,
    ]);
    $listing = rnlp_listing_from_response($single);
    if (!empty($listing) && rnlp_listing_matches_id($listing, $listing_id)) {
        return ['property' => $listing] + (is_array($single) ? $single : []);
    }

    $legacy = rnlp_proxy_request('/property', [
        'serial'      => $serial,
        'property_id' => $listing_id,
        'listing_id'  => $listing_id,
        'id'          => $listing_id,
    ]);
    $listing = rnlp_listing_from_response($legacy);
    if (!empty($listing) && rnlp_listing_matches_id($listing, $listing_id)) {
        return ['property' => $listing] + (is_array($legacy) ? $legacy : []);
    }

    $all = rnlp_listings_request([
        'startIndex'  => 0,
        'NoOfRecords' => 10000,
        'SortBy'      => 'updated',
        'SortHow'     => 'desc',
        'SearchType'  => '',
    ]);
    if (is_array($all[0] ?? null)) {
        foreach ($all[0] as $candidate) {
            if (!is_array($candidate)) {
                continue;
            }
            if (rnlp_listing_matches_id($candidate, $listing_id)) {
                return ['property' => $candidate];
            }
        }
    }

    return null;
}

/**
 * Listings-specific proxy helper — wraps /listings endpoint.
 *
 * @param  array $filters  Filter params for RealNex SearchListing1
 * @return array|null
 */
function rnlp_listings_request(array $filters): ?array {
    $serial = get_option( 'api_settings', [] )['rnlp_serial'] ?? '';
    if ( empty( $serial ) ) {
        return null;
    }
    return rnlp_proxy_request( '/listings', [ 'serial' => $serial, 'filters' => $filters ] );
}

// Legacy direct-to-RealNex calls — still used by older template includes.
function api_request( string $data ): ?array {
    $context  = stream_context_create( [ 'http' => [
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query( json_decode( $data ) ),
    ] ] );
    $response = file_get_contents( 'https://searchv2.realnex.com/api/v2/SearchListing1', false, $context );
    return $response ? json_decode( $response, true ) : null;
}

function api_request_single( string $data ): ?array {
    $context  = stream_context_create( [ 'http' => [
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query( json_decode( $data ) ),
    ] ] );
    $response = file_get_contents( 'https://searchv2.realnex.com/api/v2/PropertyDetails', false, $context );
    return $response ? json_decode( $response, true ) : null;
}

// ─── Asset Enqueue ───────────────────────────────────────────────────────────

function rnlp_enqueue_admin_js( string $page ): void {
    if ( ( $_GET['page'] ?? '' ) === 'rnlp-filter_settings' ) {
        wp_enqueue_media();
        wp_enqueue_script( 'jq_img', plugin_dir_url( __FILE__ ) . 'js/admin.js', null, null, false );
    }
}
add_action( 'admin_enqueue_scripts', 'rnlp_enqueue_admin_js' );

function register_api_plugin_style_and_scripts(): void {
    $v        = date("Ymd");
    $settings = get_option('api_settings', []);

    wp_enqueue_style('slick-css',          plugin_dir_url(__FILE__) . 'assets/css/slick.css');
    wp_enqueue_style('slick-theme-css',    plugin_dir_url(__FILE__) . 'assets/css/slick-theme.css');
    wp_enqueue_style('slick-lightbox-css', plugin_dir_url(__FILE__) . 'assets/css/slick-lightbox.css');

    // Google Fonts — based on font_style setting
    $font_style = $settings['font_style'] ?? 'modern';
    $font_urls  = [
        'modern'  => 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&display=swap',
        'classic' => 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=DM+Sans:wght@400;500&display=swap',
        'bold'    => 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap',
    ];
    wp_enqueue_style('rnlp-font', $font_urls[ $font_style ] ?? $font_urls['modern']);

    // Theme CSS
    $active_theme = $settings['rnlp_theme'] ?? 'classic';
    wp_enqueue_style('rnlp-theme-css',     plugin_dir_url(__FILE__) . 'assets/css/theme-' . sanitize_key($active_theme) . '.css', [], $v);
    wp_enqueue_style('rnlp-main-css',      plugin_dir_url(__FILE__) . 'assets/css/rnlp-main.css', [], $v);
    wp_enqueue_script('slick-js',          plugin_dir_url(__FILE__) . 'js/lib/slick.min.js',          ['jquery'], $v, true);
    wp_enqueue_script('slick-lightbox-js', plugin_dir_url(__FILE__) . 'js/lib/slick-lightbox.min.js', ['jquery'], $v, true);
}
add_action( 'wp_head',             'setNexMapConfig' );
add_action( 'wp_enqueue_scripts', 'register_api_plugin_style_and_scripts' );
add_action( 'wp_enqueue_scripts', 'rnlp_enqueue_page_assets' );

// ─── URL & Routing ───────────────────────────────────────────────────────────

function rnlp_listing_id_from_attachment_url($url): string {
    $url = (string) $url;
    if (strpos($url, '/ListingAttachment/') === false) {
        return '';
    }

    $parts = explode('/ListingAttachment/', $url, 2);
    return isset($parts[1]) ? sanitize_text_field(strtok($parts[1], '/?')) : '';
}

function rnlp_listing_id(array $listing): string {
    $id = trim((string)($listing['Id'] ?? $listing['ListingId'] ?? $listing['PropertyId'] ?? ''));
    if ($id !== '') {
        return sanitize_text_field($id);
    }

    foreach ((array)($listing['Attachments'] ?? []) as $attachment) {
        $id = rnlp_listing_id_from_attachment_url($attachment['FileName'] ?? '');
        if ($id !== '') {
            return $id;
        }
    }

    return '';
}

function rnlp_current_listing_id(): string {
    foreach (['listing_id', 'id', 'listing', 'property_id', 'prop-id'] as $key) {
        if (isset($_GET[$key]) && $_GET[$key] !== '') {
            return sanitize_text_field(wp_unslash($_GET[$key]));
        }
    }

    foreach (['listing_id', 'id', 'listing', 'property_id'] as $key) {
        $value = get_query_var($key);
        if ($value !== '') {
            return sanitize_text_field($value);
        }
    }

    return '';
}

function rnlp_property_detail_url(array $listing): string {
    $id = rnlp_listing_id($listing);
    $slug = sanitize_title($listing['PropertyName'] ?? '');
    if ($slug === '' && $id !== '') {
        $slug = sanitize_title($id);
    }

    $url = home_url('/property/' . $slug . '/');
    return $id !== '' ? add_query_arg('listing_id', $id, $url) : $url;
}

// ─── Formatting & Display ────────────────────────────────────────────────────

function rnlp_parse_area_value($value): float {
    if ($value === null || $value === '') {
        return 0;
    }
    return (float) preg_replace('/[^0-9.]/', '', (string) $value);
}

function rnlp_format_area_sf($value): string {
    $value = rnlp_parse_area_value($value);
    return $value > 0 ? number_format($value, 0, '.', ',') . ' SF' : '';
}

function rnlp_available_sf_display(array $listing): string {
    $min = rnlp_parse_area_value($listing['SpaceAvailMin'] ?? 0);
    $max = rnlp_parse_area_value($listing['SpaceAvailMax'] ?? 0);

    if (!$min && !$max) {
        $space_values = [];
        foreach ((array)($listing['Space'] ?? $listing['Spaces'] ?? []) as $space) {
            $value = $space['SpaceAvailable']
                ?? $space['space_available']
                ?? $space['AvailSf']
                ?? $space['AvailableSf']
                ?? $space['SpaceAvailSf']
                ?? null;
            $value = rnlp_parse_area_value($value);
            if ($value > 0) {
                $space_values[] = $value;
            }
        }

        if ($space_values) {
            $min = min($space_values);
            $max = max($space_values);
        }
    }

    if (!$min && !$max) {
        // Direct top-level field fallback (AvailableSf / AvailSf)
        $direct = rnlp_parse_area_value(
            $listing['AvailableSf'] ?? $listing['AvailSf'] ?? $listing['AvailableArea'] ?? 0
        );
        if ($direct > 0) {
            return number_format($direct, 0, '.', ',') . ' SF';
        }
        return '';
    }

    if ($min && $max && $min !== $max) {
        return number_format($min, 0, '.', ',') . '-' . number_format($max, 0, '.', ',') . ' SF';
    }

    return number_format($min ?: $max, 0, '.', ',') . ' SF';
}

function rnlp_lot_size_display(array $listing): string {
    $land_size = rnlp_parse_area_value($listing['LandSize'] ?? 0);
    if (!$land_size) {
        return '';
    }

    $type = strtoupper((string)($listing['LandSizeType'] ?? 'AC'));
    if (in_array($type, ['SF', 'SQFT', 'SQUARE FEET'], true)) {
        return number_format($land_size, 0, '.', ',') . ' SF';
    }

    return rtrim(rtrim(number_format($land_size, 2, '.', ','), '0'), '.') . ' ' . ($type ?: 'AC');
}

// ─── Photo & Media ───────────────────────────────────────────────────────────

function rnlp_attachment_image_url($file_name, string $query = 'h=900&mode=max&404=default&autorotate=true'): string {
    $file_name = trim((string) $file_name);
    if ($file_name === '') {
        return '';
    }

    return esc_url($file_name . (strpos($file_name, '?') === false ? '?' : '&') . $query);
}

function rnlp_photo_attachments(array $listing): array {
    $attachments = [];

    $default = $listing['DefaultAttachment'] ?? null;
    if (is_array($default) && !empty($default['FileName']) && in_array(strtolower(pathinfo(parse_url($default['FileName'], PHP_URL_PATH) ?: $default['FileName'], PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) {
        $attachments[] = $default;
    } elseif (is_string($default) && $default !== '' && in_array(strtolower(pathinfo(parse_url($default, PHP_URL_PATH) ?: $default, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) {
        $attachments[] = ['FileName' => $default, 'DefaultAttachment' => true, 'SequenceNo' => -1];
    }

    $media_items = array_merge(
        (array)($listing['Photos'] ?? []),
        (array)($listing['Attachments'] ?? []),
        (array)($listing['Images'] ?? [])
    );

    foreach ($media_items as $attachment) {
        if (!is_array($attachment)) {
            continue;
        }

        $file = $attachment['FileName'] ?? $attachment['Url'] ?? $attachment['url'] ?? $attachment['PhotoUrl'] ?? '';
        if ($file !== '') {
            $attachment['FileName'] = $file;
        }
        $att_id = $attachment['Id'] ?? $attachment['AttachmentId'] ?? $attachment['id'] ?? '';
        $type = strtolower((string)($attachment['AttachmentType'] ?? ''));
        if ($file !== '') {
            $ext = strtolower(pathinfo(parse_url($file, PHP_URL_PATH) ?: $file, PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) {
                continue;
            }
        } elseif (!$att_id) {
            continue;
        }
        if ($type && $type !== 'photo' && $type !== 'image') {
            continue;
        }

        $attachments[] = $attachment;
    }

    usort($attachments, function($a, $b) {
        $a_default = !empty($a['DefaultAttachment']) ? 0 : 1;
        $b_default = !empty($b['DefaultAttachment']) ? 0 : 1;
        if ($a_default !== $b_default) {
            return $a_default <=> $b_default;
        }
        return (int)($a['SequenceNo'] ?? 9999) <=> (int)($b['SequenceNo'] ?? 9999);
    });

    $seen = [];
    return array_values(array_filter($attachments, function($attachment) use (&$seen) {
        $file = (string)($attachment['FileName'] ?? '');
        $key = $file !== '' ? $file : (string)($attachment['Id'] ?? $attachment['AttachmentId'] ?? $attachment['id'] ?? '');
        if ($key === '' || isset($seen[$key])) {
            return false;
        }
        $seen[$key] = true;
        return true;
    }));
}

// Constructs URL from ListingId+AttachmentId rather than FileName —
// FileName is unreliable in the RealNex v2 response shape.
function rnlp_first_photo_url( array $listing ): string {
    $photos = $listing['Photos'] ?? $listing['Attachments'] ?? $listing['Images'] ?? [];
    if ( ! empty( $photos ) && is_array( $photos ) ) {
        $first      = is_array( $photos[0] ) ? $photos[0] : $photos;
        $listing_id = $listing['Id'] ?? $listing['ListingId'] ?? $listing['PropertyId'] ?? '';
        $att_id     = $first['Id'] ?? $first['AttachmentId'] ?? $first['id'] ?? '';
        if ( $att_id && $listing_id ) {
            return 'https://realnex.com/s3/realnex.production/ListingAttachment/'
                . rawurlencode( (string) $listing_id ) . '/'
                . rawurlencode( (string) $att_id ) . '.jpg?h=800&mode=max';
        }
        // Fall back to direct URL fields
        $url = $first['Url'] ?? $first['url'] ?? $first['PhotoUrl'] ?? $first['FileName'] ?? '';
        if ( $url ) {
            return esc_url_raw( $url . ( strpos( $url, '?' ) === false ? '?h=800&mode=max' : '&h=800&mode=max' ) );
        }
    }
    return plugins_url( 'templates/img/no-image.png', __FILE__ );
}

function rnlp_first_nonempty_url(array $listing, array $keys): string {
    foreach ($keys as $key) {
        if (!empty($listing[$key]) && is_scalar($listing[$key]) && filter_var($listing[$key], FILTER_VALIDATE_URL)) {
            return esc_url_raw($listing[$key]);
        }
    }

    return '';
}

// ─── Property Feature Checks ─────────────────────────────────────────────────

function rnlp_truthy_field(array $listing, array $keys): bool {
    foreach ($keys as $key) {
        if (!array_key_exists($key, $listing)) {
            continue;
        }
        $value = $listing[$key];
        if (is_array($value)) {
            if (!empty($value)) return true;
            continue;
        }
        if (is_bool($value)) {
            if ($value) return true;
            continue;
        }
        if (is_numeric($value)) {
            if ((float) $value > 0) return true;
            continue;
        }
        $value = strtolower(trim((string) $value));
        if ($value !== '' && !in_array($value, ['0', 'false', 'no', 'none', 'null'], true)) {
            return true;
        }
    }

    return false;
}

function getDocumentVaultUrl(array $listing): string {
    $url = rnlp_first_nonempty_url($listing, [
        'DealRoomUrl',
        'DealRoomURL',
        'DocumentVaultUrl',
        'DocumentVaultURL',
        'DocumentsUrl',
        'DocumentsURL',
        'DocumentUrl',
        'DocumentURL',
        'VaultUrl',
        'VaultURL',
    ]);
    if ($url) {
        return $url;
    }

    foreach ((array)($listing['Attachments'] ?? []) as $attachment) {
        $file = (string)($attachment['FileName'] ?? '');
        if (!$file || !filter_var($file, FILTER_VALIDATE_URL)) {
            continue;
        }

        $type = strtolower((string)($attachment['AttachmentType'] ?? ''));
        $name = strtolower($file . ' ' . ($attachment['Name'] ?? '') . ' ' . ($attachment['Description'] ?? ''));
        if (
            $type === 'document' ||
            str_contains($name, 'dealroom') ||
            str_contains($name, 'deal room') ||
            str_contains($name, 'document vault') ||
            str_contains($name, 'vault') ||
            str_contains($name, 'documents')
        ) {
            return esc_url_raw($file);
        }
    }

    return '';
}

function hasDocumentVault(array $listing): bool {
    return getDocumentVaultUrl($listing) !== '' || rnlp_truthy_field($listing, [
        'DealRoom',
        'HasDealRoom',
        'DocumentVault',
        'HasDocumentVault',
        'Documents',
        'HasDocuments',
    ]);
}

function getVirtualTourUrl(array $listing): string {
    $url = rnlp_first_nonempty_url($listing, [
        'VirtualTourUrl',
        'VirtualTourURL',
        'VirtualTour',
        'Tour3DUrl',
        'Tour3DURL',
        'Tour3D',
        'MatterportUrl',
        'MatterportURL',
        'VideoUrl',
        'VideoURL',
        'TourUrl',
        'TourURL',
    ]);
    if ($url) {
        return $url;
    }

    foreach ((array)($listing['Attachments'] ?? []) as $attachment) {
        $file = (string)($attachment['FileName'] ?? '');
        if (!$file || !filter_var($file, FILTER_VALIDATE_URL)) {
            continue;
        }

        $type = strtolower((string)($attachment['AttachmentType'] ?? ''));
        $name = strtolower($file . ' ' . ($attachment['Name'] ?? '') . ' ' . ($attachment['Description'] ?? ''));
        if (
            $type === 'tour' ||
            $type === 'video' ||
            str_contains($name, 'tour') ||
            str_contains($name, '3d') ||
            str_contains($name, 'virtual') ||
            str_contains($name, 'matterport') ||
            str_contains($name, 'video')
        ) {
            return esc_url_raw($file);
        }
    }

    return '';
}

function hasVirtualTour(array $listing): bool {
    return getVirtualTourUrl($listing) !== '' || rnlp_truthy_field($listing, [
        'VirtualTour',
        'HasVirtualTour',
        'Tour3D',
        'HasTour3D',
        'Matterport',
        'HasMatterport',
        'Video',
        'HasVideo',
    ]);
}

// ─── Page Asset Routing ──────────────────────────────────────────────────────

function rnlp_enqueue_page_assets(): void {
    $v        = date( 'Ymd' );
    $settings = get_option( 'api_settings', [] );
    $mapType = $settings['select_mapType_field'] ?? 'googlemap';

    if (is_page('single-property')) {
        wp_enqueue_style('rnlp-single-css', plugin_dir_url(__FILE__) . 'assets/css/rnlp-single.css', [], $v);
        wp_enqueue_style('leaflet-css',     'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css');
        wp_enqueue_script('leafletjs',      'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet-src.min.js');
        wp_enqueue_script('single-property', plugin_dir_url(__FILE__) . 'js/single-property.js', ['jquery'], $v, false);
        wp_enqueue_script('share.js',         plugin_dir_url(__FILE__) . 'js/sharer.js/sharer.min.js', ['jquery'], $v, false);
    } else {
        wp_enqueue_script('filter-events', plugin_dir_url(__FILE__) . '/js/filter-events-handler.js', ['jquery'], $v, true);
        wp_enqueue_script('api-widget-js', plugin_dir_url(__FILE__) . 'js/api-widget.js', ['jquery'], $v, false);

        if (($settings['detail_behavior'] ?? 'popup') === 'popup') {
            wp_enqueue_style('rnlp-single-css', plugin_dir_url(__FILE__) . 'assets/css/rnlp-single.css', [], $v);
            wp_enqueue_script('single-property', plugin_dir_url(__FILE__) . 'js/single-property.js', ['jquery'], $v, false);
            wp_enqueue_script('rnlp-detail-popup', plugin_dir_url(__FILE__) . 'js/rnlp-detail-popup.js', ['jquery', 'single-property'], $v, true);
        }

        if ($mapType === 'googlemap') {
            wp_enqueue_script('markerclusterer', 'https://cdnjs.cloudflare.com/ajax/libs/gmaps-marker-clusterer/1.2.2/markerclusterer.min.js', null, null, true);
            wp_enqueue_script('google-maps',     plugin_dir_url(__FILE__) . '/js/google-maps.js', ['jquery'], $v, true);
        } else {
            wp_enqueue_style('leaflet-css',                  'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css');
            wp_enqueue_script('leafletjs',                   'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet-src.min.js');
            wp_enqueue_style('leaflet.markercluster-css',    'https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/MarkerCluster.min.css');
            wp_enqueue_style('leaflet.markercluster-def-css','https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/MarkerCluster.Default.min.css');
            wp_enqueue_script('leafletjs.markercluster',     'https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/leaflet.markercluster.min.js');
            wp_enqueue_script('openstreet-map',              plugin_dir_url(__FILE__) . '/js/openstreet-map.js', ['jquery'], $v, true);
        }
    }
}

function setNexMapConfig(): void {
    $settings     = get_option( 'api_settings', [] );
    $maps_api_key = $settings['apiKey_field']            ?? '';
    $mapType      = $settings['select_mapType_field']    ?? 'openstreetmap';
    if ( $mapType === 'googlemap' || $maps_api_key ) {
        printf( '<script>window.GOOGLE_MAPS_API_KEY="%s"</script>', esc_js( $maps_api_key ) );
    }
    printf( '<script>window.NEX_MAP_ID="%s"</script>', esc_js( $mapType ) );
}

// ─── Legacy Utilities ────────────────────────────────────────────────────────

function get_youtube_id_from_url( string $url ): string {
    preg_match( '/(http(s|):|)\\/\\/(www\\.|)yout(.*?)\\/(embed\\/|watch.*?v=|)([a-z_A-Z0-9\\-]{11})/i', $url, $matches );
    return $matches[6] ?? '';
}

function num_format( $val ): string {
    return number_format( $val, 2, '.', ',' );
}

function formatPhoneNumber( string $phoneNumber ): string {
    $digits = preg_replace( '/[^0-9]/', '', $phoneNumber );
    $len    = strlen( $digits );
    if ( $len > 10 ) {
        return '(' . substr( $digits, -10, 3 ) . ') ' . substr( $digits, -7, 3 ) . '-' . substr( $digits, -4 );
    }
    if ( $len === 10 ) {
        return '(' . substr( $digits, 0, 3 ) . ') ' . substr( $digits, 3, 3 ) . '-' . substr( $digits, 6 );
    }
    if ( $len === 7 ) {
        return substr( $digits, 0, 3 ) . '-' . substr( $digits, 3 );
    }
    return $phoneNumber;
}

function hex2rgba( string $color, float $opacity ): string {
    [ $r, $g, $b ] = sscanf( $color, '#%02x%02x%02x' );
    return "rgba($r, $g, $b, $opacity)";
}

function currentUrl(): string {
    $scheme = ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ) ? 'https' : 'http';
    return $scheme . '://' . ( $_SERVER['HTTP_HOST'] ?? '' ) . ( $_SERVER['REQUEST_URI'] ?? '' );
}

function array_minimum_one_exist( array $array ): bool {
    foreach ( $array as $item ) {
        if ( ! empty( $item ) ) return true;
    }
    return false;
}

require_once __DIR__ . '/_functions/seo.php';

// ─── Shortcodes ──────────────────────────────────────────────────────────────

function rnlp_featured_shortcode( $atts ): string {
    $serial = get_option('api_settings', [])['rnlp_serial'] ?? '';
    if (empty($serial)) return '';

    $response = rnlp_listings_request([
        'startIndex'  => 0,
        'NoOfRecords' => 6,
        'SortBy'      => 'updated',
        'SortHow'     => 'desc',
        'IsFeatured'  => true,
        'SearchType'  => '',
    ]);
    $listings = $response[0] ?? [];
    if (empty($listings)) return '';

    ob_start();
    include(plugin_dir_path(__FILE__) . 'templates/featured-widget.php');
    return ob_get_clean();
}
add_shortcode('property-featured', 'rnlp_featured_shortcode');

function rnlp_reduced_shortcode( $atts ): string {
    $serial = get_option('api_settings', [])['rnlp_serial'] ?? '';
    if (empty($serial)) return '';

    $response = rnlp_listings_request([
        'startIndex'      => 0,
        'NoOfRecords'     => 10000,
        'SortBy'          => 'updated',
        'SortHow'         => 'desc',
        'SearchType'      => '',
    ]);
    $listings = $response[0] ?? [];

    ob_start();
    include(plugin_dir_path(__FILE__) . 'templates/reduced-widget.php');
    return ob_get_clean();
}
add_shortcode('property-reduced', 'rnlp_reduced_shortcode');

// ── Single property page title ────────────────────────────────────────────
// PHP sets a generic placeholder; single-property-tpl.php injects a <script>
// that replaces document.title with the actual property name after the data loads.
add_filter( 'document_title_parts', function( array $title ): array {
    $has_listing = ! empty( $_GET['listing_id'] )
                || ! empty( $_GET['id'] )
                || ! empty( $_GET['prop-id'] );
    if ( $has_listing ) {
        $title['title'] = 'Property Details';
    }
    return $title;
} );

// ── Enqueue widget CSS ────────────────────────────────────────────────────

add_action('wp_enqueue_scripts', 'rnlp_widget_assets');
function rnlp_widget_assets() {
    wp_enqueue_style('rnlp-widget-css', plugin_dir_url(__FILE__) . 'assets/css/rnlp-widget.css', [], date('Ymd'));
}
