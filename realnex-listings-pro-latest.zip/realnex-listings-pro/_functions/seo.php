<?php 

if( isset($_GET['prop-id']) ){
    
        
    $data_property = json_encode(array(
        "PropertyId"  => $_GET['prop-id']
    ));
    $PropertyDetail = api_request_single($data_property);
    $PropertyDetail = json_decode($PropertyDetail["PropertyDetail"], true);
    $pr_source = $PropertyDetail["hits"]["hits"][0]["_source"];
   
    $title = $pr_source["property_name"].' | '.$pr_source["listing_type"];
    $description = $pr_source["full_address"];
    $actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    $img_url=[];

    foreach ($pr_source["attachments"] as $key => $att){
        if(pathinfo($att["file_name"] ,PATHINFO_EXTENSION) == 'jpg' || pathinfo($att["file_name"] ,PATHINFO_EXTENSION) == 'png' ){
            $img_url[] = $att['file_name'];   
        }
    }

    if(!empty($img_url)){
        $img_path =  $img_url[0];
    }else{
        $img_path = plugin_dir_url( __FILE__ ) . 'img/no-image.png';
    }

   
    if (is_plugin_active('wordpress-seo/wp-seo.php')) {

        /** Modify the Yoast SEO schema graph. **/
      
        add_filter( 'wpseo_canonical', function() use ($actual_link) {
            return $actual_link;
        }, );

        add_filter('wpseo_title', function() use ($title) {
            return $title;
        }, );

        add_filter( 'wpseo_metadesc', function() use ($description) {
            return $description;
        }, );

        add_filter( 'wpseo_opengraph_title' , function() use ($title) {
            return $title;
        }, );

        add_filter( 'wpseo_opengraph_url' , function() use ($actual_link) {
            return $actual_link;
        }, );

        add_filter( 'wpseo_opengraph_desc' , function() use ($description) {
            return $description;
        }, );

        add_filter( 'wpseo_opengraph_image' , function() use ($img_path) {
            return $img_path;
        }, );

        add_action( 'wp_head', function() use ($img_path, $actual_link, $title, $description) {
            echo '<meta property="og:image" content="' . $img_path . '"/>';
        },  );
        
    } else {

        add_filter('document_title_parts', function($title_parts) use ($title) {
            $title_parts['title'] = $title;
            return $title_parts;
        });

        add_action( 'wp_head', function() use ($img_path, $actual_link, $title, $description) {
            echo '<meta property="og:type" content="article"/>';
            echo '<meta property="og:title" content="'. $title .'"/>';
            echo '<meta property="og:description" content="'. $description .'"/>';
            echo '<meta property="og:url" content="'. $actual_link .'"/>';
            echo '<meta property="og:image" content="' . $img_path . '"/>';
            
            echo '<meta property="twitter:card" content="summary_large_image"/>';
            echo '<meta property="twitter:domain" content="'. home_url() .'"/>';
            echo '<meta property="twitter:url" content="'. $actual_link .'"/>';
            echo '<meta property="twitter:title" content="'. $title .'"/>';
            echo '<meta property="twitter:description" content="'. $description .'"/>';
            echo '<meta property="twitter:image" content="' . $img_path . '"/>';
        },  );

    }
}