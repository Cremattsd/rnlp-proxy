=== RealNex Listings Pro ===
Contributors: initial3development
Tags: real estate, commercial real estate, realnex, property listings, CRE
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 3.6.0
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Professional CRE listing pages powered by RealNex. Full-width grid, 4 themes, lead capture to RealNex CRM.

== Description ==

**RealNex Listings Pro** turns your WordPress site into a professional commercial real estate listing portal powered by the RealNex platform.

**Features:**

* 🏢 Full-width property grid with live filtering, sorting, and pagination
* 🎨 4 polished themes — Classic, Dark Pro, Steel Blue, Ember
* 🗺️ Collapsible map panel (Google Maps or OpenStreetMap)
* 📬 Lead capture form that creates contacts directly in RealNex CRM via the SyncAPI
* 🔑 Serial-based licensing — company ID never exposed on the client
* 🌟 Featured listings widget (`[property-featured]`) — horizontal scroll row
* 💲 Price reduced listings widget (`[property-reduced]`) — with diagonal ribbon badge
* 👥 Agent roster page template with listing counts
* 🔎 Advanced filters: availability checkboxes, property type groups (MP Direct style), size & price ranges
* 📱 Fully responsive — grid → 2-col → 1-col

**Available Shortcodes:**

* `[company]` — All listings for your account
* `[company id=12345]` — Listings for a specific company ID
* `[company types=OFC,IND]` — Filter by property type
* `[company avail=1,2]` — Filter by availability
* `[broker id=12345]` — Listings for a specific broker/agent
* `[property id=12345]` — Single property detail page
* `[property-widget id=12345]` — Compact property sidebar widget
* `[property-featured]` — Featured listings carousel
* `[property-reduced]` — Price-reduced listings with ribbon badge

== Installation ==

1. Upload the `realnex-listings-pro` folder to `/wp-content/plugins/`
2. Activate the plugin through **Plugins** in WordPress admin
3. Go to **RealNex Listings Pro → Settings → License & Setup**
4. Enter your serial number and click **Save Settings** — the plugin activates against the licensing server
5. Add the `[company]` or `[broker id=XXXX]` shortcode to any page
6. *(Optional)* Configure CRM Lead Capture in **Settings → CRM & Leads**

== Frequently Asked Questions ==

= Where do I get a serial number? =

Serial numbers are issued by Initial3 Development. Contact [initial3development.com](https://www.initial3development.com/).

= Does this plugin work without a RealNex account? =

No — a valid RealNex subscription with active listings is required.

= Which map providers are supported? =

Google Maps (API key required) and OpenStreetMap (free, no key needed).

= How does lead capture work? =

When a visitor clicks "Inquire" on a property card, the form submission creates a Contact in your RealNex CRM via the SyncAPI, links it to any associated Projects, and creates a History event for the audit trail. You also receive an email notification.

= Can I customize the colors and fonts? =

Yes. Use the Primary Color picker in **Settings → Display**. For custom fonts, paste the Google Fonts import and `--rnlp-font` override into **Appearance → Additional CSS**.

= Is the company ID secure? =

Yes. The company ID is stored encrypted in WordPress options and is never exposed in the admin UI or transmitted to the browser. All API requests route through the RNLP proxy server which injects the company ID server-side.

== Screenshots ==

1. Full-width property grid with availability checkboxes and MP Direct type groups
2. Single property detail page with photo gallery and lead capture form
3. Settings page — License & Setup tab
4. Settings page — Display tab with theme picker
5. Featured properties widget (`[property-featured]`)
6. Price reduced widget with diagonal ribbon (`[property-reduced]`)

== External Services ==

This plugin connects to the following external services:

= Initial3 Development Proxy API =
* URL: https://api.initial3development.com
* Purpose: Validates serial numbers and retrieves property listings from RealNex. Your serial number is sent to verify your subscription. No personal data is transmitted.
* Privacy Policy: https://initial3development.com/privacy
* Terms of Service: https://initial3development.com/terms

= RealNex Search API =
* URL: https://searchv2.realnex.com
* Purpose: Source of commercial real estate listing data. Accessed server-side only through the proxy. Never contacted directly from the browser.
* Privacy Policy: https://www.realnex.com/privacy

= OpenStreetMap / Leaflet =
* URL: https://tile.openstreetmap.org
* Purpose: Map tiles for property location display.
* Privacy Policy: https://wiki.osmfoundation.org/wiki/Privacy_Policy

= U.S. Census Bureau API =
* URL: https://api.census.gov
* Purpose: Free demographic data for property location context. No personal data sent — only ZIP code.
* Privacy Policy: https://www.census.gov/about/policies/privacy.html

= Nominatim (OpenStreetMap) =
* URL: https://nominatim.openstreetmap.org
* Purpose: Reverse geocoding to display neighborhood names. Latitude/longitude coordinates are sent.
* Privacy Policy: https://wiki.osmfoundation.org/wiki/Privacy_Policy

= Overpass API (OpenStreetMap) =
* URL: https://overpass-api.de
* Purpose: Fetches nearby amenities (restaurants, banks, etc.) within 500m of a property. Latitude/longitude coordinates are sent.
* Privacy Policy: https://wiki.osmfoundation.org/wiki/Privacy_Policy

== Privacy Policy ==

This plugin sends your serial number to the Initial3 Development proxy server for validation. No personal user data is collected or stored by this plugin. Lead inquiry data submitted through property contact forms is sent to RealNex CRM as configured by the site administrator.

== Changelog ==

= 3.6.0 =
* Feature: Adds private one-click WordPress admin updates through the Initial3 proxy update endpoint.

= 3.5.9 =
* Fix: Single property pages now honor listing_id, id, and listing query parameters and fetch the matching listing from the proxy.
* Fix: Single property photo carousel renders all available listing photos and initializes prev/next, thumbnail, counter, and lightbox behavior.
* Fix: Area Intelligence renders N/A fallbacks when enrichment or EPA EJScreen data is unavailable.

= 3.5.7 =
* Fix: Map marker images in admin Display tab now display correctly — ?? operator replaced with !empty() check so empty-string DB values fall back to bundled SVGs
* Fix: Front-end map marker fallback in custom-styles.php resolves plugin root URL correctly from templates/ subdirectory

= 3.5.1 =
* Fix: Map JS — null guards on querySelector and safety wrap around setMapState / notifyMapUpdated calls
* Fix: Listing card photo extraction now scans Attachments for AttachmentType=photo before falling back
* Fix: Removed "Wanted" availability filter chip from listing template
* Fix: ACCESS REALNEX VAULT button now appears on every property detail page when a valid listing Id is present
* Fix: Property detail JSON-LD schema confirmed in script tag (not nested in H1)
* Fix: Removed Gravatar broker img tags — initials avatar is the canonical display
* Fix: Removed debug microtime echo from company-listing.php and broker-listing.php
* Fix: Price Reduced shortcode now filters all listings by name containing PRICE/REDUCED/SPECIAL/SALE and shows a friendly message when none are found
* Feature: Photo carousel on single property detail page — hero image with prev/next arrows, photo counter, thumbnail strip, and arrow-key navigation

= 3.5.0 =
* Feature: 4 layout options in Admin — Grid+Map, Full Grid, Hero+Grid, List View
* Feature: Brand color picker with 6 presets (Navy, Gold, Forest, Charcoal, Burgundy, Slate)
* Feature: Dark/Light background mode toggle
* Feature: Font selector — Modern (DM Sans), Classic (Playfair Display), Bold (Montserrat)
* Feature: Popup vs Full Page property detail behavior setting
* Fix: Listings rendering in all demo files — try/catch around render, proper array check
* Fix: Layout selector (Grid/List/Compact/Wide) replaces sort dropdown in demo files
* Fix: All demos confirmed on RNLP-MDL-001 serial

= 3.2.0 =
* Security: Domain locking — serial is bound to the activation domain on first use
* Security: Weekly phone-home re-validation against proxy (fail open on network error)
* Security: Anti-tamper file integrity check — reports hash mismatches to proxy
* Security: Proxy URL obfuscated via base64 decode — no plain-text URL in source
* Security: Dev/debug output gated behind RNLP_DEV_KEY constant
* Feature: /report endpoint on proxy server for tamper/anomaly event logging
* Feature: /reports admin endpoint on proxy for reviewing security events
* Feature: domain column added to serials table in proxy DB
* Feature: Private distribution packaging script (package-rnlp.sh)
* Feature: LICENSED-TO.php client license file included in each distribution build
* Fix: New activation now saves registered domain, last-check timestamp, and integrity hashes

= 3.1.0 =
* Security: Company ID fully abstracted behind proxy — never exposed to browser
* Security: ABSPATH checks on all PHP files
* Feature: Configurable property type filters with specialty presets
* Feature: Full layout toggle controls (show/hide map, filters, sections etc)
* Feature: Multi-company ID support — comma-separated in Supabase
* Feature: Client-side demographics, neighborhood, amenities on property pages
* Feature: Deal Room button conditional on active listings only
* Fix: Property type dropdown closes on outside click / Escape key
* Fix: Map marker images path corrected
* WP.org: External services disclosure added to readme.txt
* WP.org: Plugin header updated (Author, URI, Domain Path)
* WP.org: Tested up to 6.7

= 3.0.0 =
* Proxy architecture — all listing requests route through api.initial3development.com
* Serial-based licensing replaces Company ID / Broker ID settings
* Tabbed settings page (License, Display, Agents, CRM & Leads)
* New shortcodes: `[property-featured]` and `[property-reduced]`
* Agent roster page template with listing counts and "View listings" filter
* Widget CSS (`rnlp-widget.css`) — horizontal scroll row + 3-col grid + price reduced ribbon
* Proper `uninstall.php` for WP.org compliance
* Plugin header updated for WP.org directory submission

= 2.1.0 =
* Correct RealNex SyncAPI v1 endpoints for lead capture
* Availability checkboxes replace select dropdown
* Status badge SVG icons (key, dollar, checkmark, search, handshake)
* MP Direct property type groups in dropdown
* RealNex navy (#013161) as polished default accent

= 2.0.0 =
* Full-width grid layout
* Collapsible map panel
* Sort select (price high/low, building size)
* 4 selectable themes
* Font CSS custom properties

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 3.0.0 =
Breaking change: Company ID and Broker ID have been removed from settings. Enter your serial number in **Settings → License & Setup** to re-activate. Existing shortcodes continue to work unchanged.
