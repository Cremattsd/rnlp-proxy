<?php
if (!defined('ABSPATH')) exit;
/**
 * RealNex Listings Pro — License Certificate
 *
 * Client : {CLIENT_NAME}
 * Domain : {CLIENT_DOMAIN}
 * Serial : {SERIAL}
 * Issued : {ISSUED_DATE}
 *
 * This copy is licensed exclusively to the client and domain listed above.
 * Redistribution, resale, or use on any other domain is prohibited.
 * Support: https://initial3development.com/
 */
