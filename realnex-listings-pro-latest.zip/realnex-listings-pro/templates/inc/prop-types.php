<?php
$prop_types_json = '{"AG":"Agricultural","AG-AGB":"Agribusiness","AG-AGR":"Agricultural","AG-PAST":"Pasture\/Ranch","AG-TIMB":"Timberland","BO":"Business Opportunities","HC":"Health Care","IND":"Industrial","IND-AUTO":"Industrial Automotive","IND-BP":"Industrial Business Park","IND-DIST":"Distribution Warehouse","IND-FLEX":"Flex Space","IND-FRIG":"Refrigerated\/Cold Storage","IND-MFG":"Manufacturing","IND-OFC":"Office Showroom","IND-RD":"Research and Development","IND-STOR":"Self-Storage Facility","IND-THT":"Truck Terminal\/Hub\/Transit Facility","IND-WHSE":"Warehouse","LH":"Lodging and Hospitality","LH-EC":"Economy\/Limited Service","LH-FULL":"Full Service","MF":"Multi-Family","MF-ASSIST":"Senior Housing - Assisted Living","MF-CONG":"Senior Housing - Congregate","MF-GARD":"Garden\/Low Rise","MF-GOV":"Government Subsidized","MF-MH":"Mobile Home Community","MF-MID":"Mid\/High-Rise","MF-SH":"Senior Housing","OFC":"Office","OFC-BLDG":"Office Building","OFC-BP":"Business Park","OFC-LOFT":"Creative Loft","OFC-MED":"Medical Office","OFC-RD":"Research and Development","OFC-WHSE":"Warehouse","SCR":"Shopping Center \/ Retail","SCR-AUTO":"Retail - Automotive","SCR-COM":"Retail - Commercial\/Other","SCR-COMM":"Shopping Center - Community Center","SCR-CON":"Shopping Center - Strip Center","SCR-DAY":"Retail - Day Care Facility","SCR-FASH":"Shopping Center - Fashion Center","SCR-FREE":"Retail - Free Standing","SCR-OUT":"Shopping Center - Outlet Center","SCR-PAD":"Retail - Retail Pad","SCR-POW":"Shopping Center - Power Center","SCR-REG":"Shopping Center - Regional Center\/Mall","SCR-REST":"Shopping Center - Restaurant","SCR-STREET":"Retail - Street","SCR-SUP":"Shopping Center - Super Regional Center","SCR-SVC":"Retail - Service\/Gas Station","SCR-VEH":"Retail - Vehicle","SPEC":"Special Purpose \/ Other","SPEC-MAR":"Marina","SPEC-OTH":"Special Purpose\/Other","SPORT":"Sports and Entertainment","SPORT-GOLF":"Golf Related","SPORT-TH":"Theatre\/Performing Arts","V":"Vacant Land","V-AUTO":"Vacant Land - Automotive","V-COM":"Vacant Land - Commercial","V-IND":"Vacant Land - Industrial","V-MULTI":"Vacant Land - Multi-Family","V-OFC":"Vacant Land - Office","V-OTH":"Vacant Land - Other","V-PAD":"Vacant Land - Pad","V-RES":"Vacant Land - Residential","V-RET":"Vacant Land - Retail","BO-OTH":"Business Opportunities (Other)","HC-HOSP":"Hospital","RES":"Residential - Income","LH-BB":"Bed & Breakfast","OFC-RET":"Office Retail","MU":"Mixed Use"}';

$prop_types = json_decode($prop_types_json, true);

//html for settings page
$list_prop_types_html = '<ul style="columns: 4;">';
foreach($prop_types as $key=>$value){
    $list_prop_types_html .= "<li style='break-inside: avoid;'>$value -> $key</li>";
}
$list_prop_types_html .= "</ul>";
 

//  $arr = array();
//  foreach($PropertyDetail["lstPropertyType"] as $prop){
//      $arr[$prop['PType']]=$prop['PTypeName'];
//  }

//  echo "<pre>";
//  var_dump(json_encode($arr));
//  echo "</pre>";