<div class="share mb-2 flex flex-row">
    <span class="!text-base capitalize text-black font-bold min-w-[50%] flex items-center">
        Share on :
    </span>

    <div class="flex flex-row gap-4" >
        <a href="#" class="social" alt="Share On Facebook" title="Share On Facebook" data-sharer="facebook" 
        data-hashtag="<?php echo str_replace( 'for ', '', strtolower($pr_source['listing_type'])) ?>" 
        data-url="<?php echo currentUrl(); ?>">
            <svg
                xmlns="http://www.w3.org/2000/svg"
                class=""
                fill="<?php echo $icons_color ?>"
                viewBox="0 0 24 24">
                <path
                d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
            </svg>
        </a>
        
        <a href="#" class="social" alt="Share On X (Formerly Twitter)" title="Share On X (Formerly Twitter)" data-sharer="twitter" 
        data-title="<?php echo ucwords(strtolower($pr_source["property_name"]))?>" 
        data-hashtags="<?php echo str_replace( ' ', '_', strtolower($pr_source['property_name'])).','.str_replace( 'for ', '', strtolower($pr_source['listing_type'])) ?>" 
        data-url="<?php echo currentUrl(); ?>">
            <svg 
            width="1200" 
            height="1227" 
            viewBox="0 0 1200 1227" 
            fill="<?php echo $icons_color ?>" xmlns="http://www.w3.org/2000/svg">
            <path d="M714.163 519.284L1160.89 0H1055.03L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.491 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.165 687.828L521.697 619.934L144.011 79.6944H306.615L611.412 515.685L658.88 583.579L1055.08 1150.3H892.476L569.165 687.854V687.828Z" />
            </svg>
        </a>
        
        <a href="#" class="social" alt="Share On Linkedin" title="Share On Linkedin" data-sharer="linkedin" data-url="<?php echo currentUrl(); ?>">
            <svg
                xmlns="http://www.w3.org/2000/svg"
                class=""
                fill="<?php echo $icons_color ?>"
                viewBox="0 0 24 24">
                <path
                d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z" />
            </svg>
        </a>
    </div>

</div>