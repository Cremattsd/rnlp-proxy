<?php
/**
 * The template for displaying all single propertie details
 */
?>

<?php if($pr_source["full_address"] && !$pr_source['undisclosed_loc']): ?>
    <p><span class="!text-base font-color font-bold">Full Address: </span><?php echo($pr_source["full_address"]) ?></p>
<?php endif;?>

<?php if($pr_source["listing_type"]): ?>
    <p><span class="!text-base font-color font-bold">Listing Type: </span><?php echo($pr_source["listing_type"]) ?></p>
<?php endif;?>

<?php if($pr_source["status"]): ?>
    <p><span class="!text-base font-color font-bold">Status: </span><?php echo($pr_source["status"]) ?></p>
<?php endif;?>

<?php if($pr_source["occupancy_rate"]): ?>
    <p><span class="!text-base font-color font-bold">Occupancy Rate: </span><?php echo($pr_source["occupancy_rate"]) ?></p>
<?php endif;?>

<?php if($pr_source["building_class"]): ?>
    <p><span class="!text-base font-color font-bold">Building Class: </span><?php echo($pr_source["building_class"]) ?></p>
<?php endif;?>

<?php if($pr_source["zoning"]): ?>
    <p><span class="!text-base font-color font-bold">Zoning: </span><?php echo($pr_source["zoning"]) ?></p>
<?php endif;?>

<?php if(!empty($pr_source["region"])): ?>
    <p><span class="!text-base font-color font-bold">Region: </span>
    <?php foreach ($pr_source["region"] as $key => $att):?>
            <?php echo($att) ?>&nbsp;
    <?php endforeach; ?>
    </p>
<?php endif;?>

<?php if($pr_source["county"]): ?>
    <p><span class="!text-base font-color font-bold">County: </span><?php echo($pr_source["county"]) ?></p>
<?php endif;?>

<?php if($pr_source["cross_streets"]): ?>
    <p><span class="!text-base font-color font-bold">Closest Cross Streets: </span><?php echo ($pr_source["cross_streets"]) ?></p>
<?php endif;?>

<?php if($pr_source["use_type"]): ?>
    <p><span class="!text-base font-color font-bold">Use Type: </span><?php echo ($pr_source["use_type"]) ?></p>
<?php endif;?>

<?php if($pr_source["business_type"]): ?>
    <p><span class="!text-base font-color font-bold">Business Type: </span><?php echo ($pr_source["business_type"]) ?></p>
<?php endif;?>

<p><span class="!text-base font-color font-bold">Property ID: </span><?php echo($pr_source["untouched_id"]) ?></p>



<?php if(!empty($pr_source["amenities"]) && array_minimum_one_exist($pr_source["amenities"])): ?>
    <div class="my-125">
        <span class="!text-base font-bold border-b block mb-3">Amenities</span>
        <div class="d-flex-row-wrap">
            <?php foreach ($pr_source["amenities"] as $key => $att):?>
                <?php if( $att && $att !=='' ): ?>
                    <p class="width-as-table"><span class="!text-base font-color font-bold"><?php echo ucwords(str_replace("_", " ", $key)) ?>: </span><?php echo $att?"Yes":"No" ?></p>
                <?php endif;?>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif;?>



<?php if($pr_source["availability"]): ?>
    <p><span class="!text-base font-color font-bold">Data Available: </span><?php echo($pr_source["availability"]) ?></p>
<?php endif;?>

<?php if($pr_source["taxes"]): ?>
    <p><span class="!text-base font-color font-bold">Taxes: </span><?php echo '$ '.number_format(intval($pr_source['taxes']), 0, '.', ',') ?></p>
<?php endif;?>

<?php if($pr_source["traffic_count"]): ?>
    <p><span class="!text-base font-color font-bold">Traffic Count: </span><?php echo $pr_source["traffic_count"].' VPD' ?></p>
<?php endif;?>

<?php if($pr_source["clearance_height"]): ?>
    <p><span class="!text-base font-color font-bold">Clearance Height: </span><?php echo($pr_source["clearance_height"]) ?></p>
<?php endif;?>

<?php if($pr_source["max_contiguous"]): ?>
    <p><span class="!text-base font-color font-bold">Max Contiguous: </span><?php echo($pr_source["max_contiguous"]) ?></p>
<?php endif;?>

<?php if($pr_source["building_construction"]): ?>
    <p><span class="!text-base font-color font-bold">Building Construction: </span><?php echo($pr_source["building_construction"]) ?></p>
<?php endif;?>

<?php if($pr_source["roof"]): ?>
    <p><span class="!text-base font-color font-bold">Roof: </span><?php echo($pr_source["roof"]) ?></p>
<?php endif;?>

<?php if($pr_source["building_sf"]): ?>
    <p><span class="!text-base font-color font-bold">Building Sf: </span><?php echo($pr_source["building_sf"]) ?></p>
<?php endif;?>

<?php if($pr_source["warehouse_percent"]): ?>
    <p><span class="!text-base font-color font-bold">Warehouse Percent: </span><?php echo($pr_source["warehouse_percent"]) ?></p>
<?php endif;?>

<?php if($pr_source["parcel_num"]): ?>
    <p><span class="!text-base font-color font-bold">Parcel Num: </span><?php echo($pr_source["parcel_num"]) ?></p>
<?php endif;?>

<?php if($pr_source["number_units"]): ?>
    <p><span class="!text-base font-color font-bold">Number Units: </span><?php echo($pr_source["number_units"]) ?></p>
<?php endif;?>

<?php if($pr_source["number_buildings"]): ?>
    <p><span class="!text-base font-color font-bold">Number Buildings: </span><?php echo($pr_source["number_buildings"]) ?></p>
<?php endif;?>

<?php if($pr_source["section"]): ?>
    <p><span class="!text-base font-color font-bold">Section: </span><?php echo($pr_source["section"]) ?></p>
<?php endif;?>

<?php if($pr_source["financial_terms"]): ?>
    <p><span class="!text-base font-color font-bold">Financial Terms: </span><?php echo($pr_source["financial_terms"]) ?></p>
<?php endif;?>

<?php if($pr_source["year_built"]): ?>
    <p><span class="!text-base font-color font-bold">Year Built: </span><?php echo($pr_source["year_built"]) ?></p>
<?php endif;?>

<?php if($pr_source["year_reno"]): ?>
    <p><span class="!text-base font-color font-bold">Year Renovation: </span><?php echo($pr_source["year_reno"]) ?></p>
<?php endif;?>

<?php if($pr_source["free_standing"]): ?>
    <p><span class="!text-base font-color font-bold">Free Standing: </span>Yes</p>
<?php endif;?>
    
<?php if($pr_source["number_parking_spaces"]): ?>
    <p><span class="!text-base font-color font-bold">Number Parking Spaces: </span><?php echo($pr_source["number_parking_spaces"]) ?></p>
<?php endif;?>

<?php if($pr_source["commission_comments"]): ?>
    <p><span class="!text-base font-color font-bold">Commission Comments: </span><?php echo($pr_source["commission_comments"]) ?></p>
<?php endif;?>

<?php if($pr_source["cap_rate"]): ?>
    <p><span class="!text-base font-color font-bold">Cap Rate: </span><?php echo($pr_source["cap_rate"]) ?></p>
<?php endif;?>

<?php if($pr_source["tenancy_type"]): ?>
    <p><span class="!text-base font-color font-bold">Tenancy Type: </span><?php echo($pr_source["tenancy_type"]) ?></p>
<?php endif;?>







<?php if(!empty($pr_source["features"]) && array_minimum_one_exist($pr_source["features"])): ?>
    <div class="my-125">
        <span class="!text-base font-bold border-b block mb-3">Features</span>
        <?php foreach ($pr_source["features"] as $key => $att):?>
            <p><span class="!text-base font-color font-bold"><?php echo($att) ?></p>
        <?php endforeach; ?>
    </div>
<?php endif;?>

<?php if(!empty($pr_source["mixes"]) && array_minimum_one_exist($pr_source["mixes"])): ?>
    <div class="my-125">
        <span class="!text-base font-bold border-b block mb-3">Mixes</span>
        <?php foreach ($pr_source["mixes"] as $key => $att):?>
            <p><span class="!text-base font-color font-bold"><?php echo ucwords(str_replace("_", " ", 'average_monthly_rent')) .' - '. $att["description"] ?>: </span><?php echo($att["average_monthly_rent"]) ?></p>
        <?php endforeach; ?>
    </div>
<?php endif;?>


<?php if(!empty($pr_source["financial"]) && array_minimum_one_exist($pr_source["financial"])): ?>
    <div class="my-125">
        <span class="!text-base font-bold border-b block mb-3">Financial</span>
        <div class="d-flex-row-wrap">
            <?php foreach ($pr_source["financial"] as $key => $att):?>
                <?php if($att): ?>
                    <p class="width-as-table-50-100"><span class="!text-base font-color font-bold"><?php echo ucwords(str_replace("_", " ", $key)) ?>: </span><?php echo($att) ?></p>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif;?>

<?php if(!empty($pr_source["tenants"])) : ?>
    <span class="!text-base font-bold border-b block mb-3">Tenants</span>
    <?php foreach ($pr_source["tenants"] as $key => $att):?>
        <?php if( isset($att) ): ?>
            <p>
            <span class="!text-base font-color font-bold"><?php echo $key+1 ?>: </span><?php echo($att['tenant_name']) ?>
            <span class="!text-base font-color font-bold">Occupied:</span> <?php echo($att['sf_occupied']) ?> SF
            <span class="!text-base font-color font-bold"> Lease Expiration:</span> <?php echo($att['lease_expiration']) ?>
            </p>
        <?php endif;?>
    <?php endforeach; ?>
<?php endif;?>


<?php if($pr_source['num_space_available'] > 0):?>
<?php 
// echo '<pre>';
// var_dump($pr_source["space"]) ;
// echo '</pre>';
    ?>
    <?php foreach ($pr_source["space"] as $key => $att):?>
        <div class="space">
            <div class="header">

                <div><span class="!text-base font-color font-bold"><?php echo $att["addr_suite"] ? $att["addr_suite"] : 'Space #'.($key+1) ?></span></div>
                <div><span class="!text-base font-color font-bold">Upd: </span> <span title="<?php echo $att["updated"] ?>"><?php echo date('m/d/y', strtotime($att["updated"])) ?></span></div>

            </div>

            <div class="rest-details">
                
                <div class="prop"><span class="!text-base font-color font-bold">Lease Type: </span><?php echo($att["lease_type"]) ?></div>
                <div class="prop"><span class="!text-base font-color font-bold">Space Available: </span><?php echo number_format($att["space_available"], 0, '.', ',') ?> SF</div>


                <?php if(!$att["rate_undisclosed"]): ?>
                        <div class="prop-rate">

                           
                            <?php if($att["lease_rate_sf_high"]): ?>
                                <div class="rate"><span class="!text-base font-color font-bold">Rate/SF/Year: </span><?php echo '$'. num_format($att["lease_rate_sf_high"]) ?></div>
                            <?php endif; ?>
                        </div>
                <?php else: ?>
                        <div class="prop"><span class="!text-base font-color font-bold">Rate/SF/Year: </span>Negotiable</div>
                <?php endif;?>


                <?php if($att["max_contiguous"]): ?>
                    <div class="prop"><span class="!text-base font-color font-bold">Max Contiguous SF: </span><?php echo number_format($att["max_contiguous"], 0, '.', ',') .' SF' ?></div>
                <?php endif;?>
    
                <?php if($att["min_divisible"]): ?>
                    <div class="prop"><span class="!text-base font-color font-bold">Min Divisible SF: </span><?php echo number_format($att["min_divisible"], 0, '.', ',').' SF' ?></div>
                <?php endif;?>
    
                <?php if($att["sublease_expiration"]): ?>
                    <div class="prop"><span class="!text-base font-color font-bold">Sublease Expiration Date: </span><?php echo($att["sublease_expiration"]) ?></div>
                <?php endif;?>
    
                <?php if($att["ti"]): ?>
                    <div class="prop"><span class="!text-base font-color font-bold">TI Allowance: </span><?php echo '$ '.num_format($att["ti"]) ?></div>
                <?php endif;?>
    
                <?php if($att["office_sf"]): ?>
                    <div class="prop"><span class="!text-base font-color font-bold">Office SF: </span><?php echo number_format($att["office_sf"], 0, '.', ',') .' SF' ?></div>
                <?php endif;?>
                
                <?php if($att["lease_term"]): ?>
                    <div class="prop"><span class="!text-base font-color font-bold">Lease Term: </span><?php echo($att["lease_term"]) ?></div>
                <?php endif;?>
    
                <?php if($att["date_available"]): ?>
                    <div class="prop"><span class="!text-base font-color font-bold">Date Available: </span><?php echo date('m/d/Y',strtotime($att["date_available"])) ?></div>
                <?php endif;?>
    
            </div>
            
            <?php if($att["space_description"]): ?>
                <div class="footer">
                    <div class="prop"><span class="!text-base font-color font-bold">Space Description: <br> </span><span class="space-desc"><?php echo($att["space_description"]) ?></span></div>
                </div>
            <?php endif;?>

        </div>

    <?php endforeach; ?>

<?php endif;?>