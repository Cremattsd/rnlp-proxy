<?php 

$property_id = $atts['id'];

$data = json_encode(array(
    "PropertyId"  => $property_id
));
$PropertyDetail = api_request_single($data);
$PropertyDetail = json_decode($PropertyDetail["PropertyDetail"], true);
$pr_source = $PropertyDetail["hits"]["hits"][0]["_source"];

if($property_id){
    include('property-widget-tpl.php');
}else{
    echo "Please add correct Property ID";
}