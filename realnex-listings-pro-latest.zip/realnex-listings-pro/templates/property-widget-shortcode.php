<?php
if (!defined("ABSPATH")) exit;

function property_widget_shortcode($atts) { 
      
    // return $atts['id'];
    ob_start();
    require('property-widget.php');
    return ob_get_clean();

}
add_shortcode('property-widget', 'property_widget_shortcode');