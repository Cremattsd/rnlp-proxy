<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Featured Properties Widget
 * Shortcode: [property-featured]
 * $listings — array of listing objects (set by rnlp_featured_shortcode)
 */

if (empty($listings)) return;

include_once(dirname(__FILE__) . '/inc/prop-types.php');

$show_inquire  = get_option('api_settings', [])['rnlp_show_inquire'] ?? '';
?>
<div class="rnlp-widget rnlp-widget--featured" aria-label="Featured Listings">
    <div class="rnlp-widget-scroll">
        <?php foreach (array_slice($listings, 0, 6) as $val):
            $img_src = isset($val['Attachments'][0]['FileName'])
                ? $val['Attachments'][0]['FileName'] . '?h=400&mode=max&404=default&autorotate=true'
                : plugin_dir_url(__FILE__) . 'img/no-image.png';

            $is_sold  = strtoupper($val['Status'] ?? '') === 'SOLD';
            $badge    = $is_sold ? 'SOLD' : ($val['ListingType'] ?? '');
            $badge_slug = strtolower(str_replace(' ', '-', $badge));

            $price = '';
            if (!empty($val['PriceDisclosed']) && !empty($val['ListPrice'])) {
                $price = '$' . number_format((int) $val['ListPrice'], 0, '.', ',');
                if (($val['ListingType'] ?? '') === 'For Lease' && !empty($val['PriceUnits'])) {
                    $price .= ' / SF ' . strtoupper($val['PriceUnits']);
                }
            }

            $prop_id  = function_exists('rnlp_listing_id') ? rnlp_listing_id($val) : sanitize_text_field($val['Id'] ?? '');
            $prop_url = function_exists('rnlp_property_detail_url')
                ? rnlp_property_detail_url($val)
                : home_url('/property/') . sanitize_title($val['PropertyName'] ?? '') . '/?listing_id=' . rawurlencode($prop_id);

            $w_users  = (array)($val['UserList'] ?? (isset($val['User']) ? [$val['User']] : []));
            $w_broker = $w_users[0] ?? [];
            $w_broker_name  = trim(($w_broker['FirstName'] ?? '') . ' ' . ($w_broker['LastName'] ?? ''));
            $w_broker_phone = $w_broker['Phone'] ?? '';
        ?>
        <article class="rnlp-widget-card">
            <a href="<?php echo esc_url($prop_url); ?>" class="rnlp-widget-card-link" aria-label="View <?php echo esc_attr($val['PropertyName'] ?? ''); ?>"></a>
            <div class="rnlp-widget-img">
                <img src="<?php echo esc_url($img_src); ?>"
                     alt="<?php echo esc_attr($val['PropertyName'] ?? ''); ?>"
                     loading="lazy">
                <?php if ($badge): ?>
                <span class="rnlp-badge rnlp-badge--<?php echo esc_attr($badge_slug); ?>">
                    <?php echo esc_html($badge); ?>
                </span>
                <?php endif; ?>
                <?php if ($price): ?>
                <span class="rnlp-price-tag"><?php echo esc_html($price); ?></span>
                <?php endif; ?>
            </div>
            <div class="rnlp-widget-body">
                <div class="rnlp-widget-name"><?php echo esc_html(ucwords(strtolower($val['PropertyName'] ?? ''))); ?></div>
                <div class="rnlp-widget-addr"><?php echo esc_html(($val['Street'] ?? '') . ', ' . ($val['City'] ?? '') . ', ' . ($val['State'] ?? '')); ?></div>
                <?php if ($w_broker_name): ?>
                <div class="rnlp-widget-broker">
                    <span class="rnlp-widget-broker-name"><?php echo esc_html($w_broker_name); ?></span>
                    <?php if ($w_broker_phone): ?>
                    <a class="rnlp-widget-broker-phone" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $w_broker_phone)); ?>"><?php echo esc_html(formatPhoneNumber($w_broker_phone)); ?></a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <?php if ($show_inquire): ?>
                <button class="rnlp-inquire-btn"
                    data-prop-name="<?php echo esc_attr(ucwords(strtolower($val['PropertyName'] ?? '')) . ' — ' . ($val['Street'] ?? '') . ', ' . ($val['City'] ?? '')); ?>"
                    data-prop-id="<?php echo esc_attr($prop_id); ?>"
                    type="button">Inquire</button>
                <?php endif; ?>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
</div>
