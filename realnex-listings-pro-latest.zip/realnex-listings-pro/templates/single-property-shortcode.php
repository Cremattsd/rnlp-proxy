<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Single Property shortcode
 *
 * Usage: [property] — reads ?listing_id=, ?property_id=, ?prop-id=, or legacy ?id= from URL
 *        [property id="GUID"] — explicit ID via shortcode attribute
 */

function rnlp_single_property_shortcode( $atts ): string {
    $atts    = shortcode_atts( [ 'id' => 0 ], $atts );
    $prop_id = trim( (string) $atts['id'] );
    if ( $prop_id === '0' ) {
        $prop_id = '';
    }

    $listing_id = sanitize_text_field(
        wp_unslash( $_GET['listing_id'] ?? $_GET['id'] ?? $_GET['listing'] ?? '' )
    );
    if ( $listing_id !== '' ) {
        $prop_id = $listing_id;
    }

    if ( ! $prop_id && function_exists( 'rnlp_current_listing_id' ) ) {
        $prop_id = rnlp_current_listing_id();
    }
    if ( ! $prop_id ) {
        foreach ( [ 'listing_id', 'id', 'listing', 'property_id', 'prop-id' ] as $key ) {
            if ( isset( $_GET[ $key ] ) && $_GET[ $key ] !== '' ) {
                $prop_id = sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
                break;
            }
        }
    }
    // Regex fallback — catches legacy query params anywhere in the raw request URI.
    if ( ! $prop_id && preg_match( '/[?&](?:listing_id|id|listing|property_id|prop-id)=([^&#]+)/i', $_SERVER['REQUEST_URI'] ?? '', $m ) ) {
        $prop_id = sanitize_text_field( rawurldecode( $m[1] ) );
    }

    if ( ! $prop_id ) {
        return '<div class="rnlp-not-found-wrap">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="#94a3b8" width="48" height="48"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/></svg>
            <h2>Property Not Found</h2>
            <p>No property ID was provided in the URL.</p>
            <a href="' . esc_url( home_url() ) . '" class="rnlp-not-found-btn">&larr; Back to Listings</a>
        </div>';
    }

    $serial = get_option( 'api_settings', [] )['rnlp_serial'] ?? '';
    if ( empty( $serial ) ) {
        return '';
    }

    $response = function_exists( 'rnlp_single_listing_request' )
        ? rnlp_single_listing_request( $prop_id )
        : rnlp_proxy_request( '/property', [
            'serial'      => $serial,
            'property_id' => $prop_id,
            'listing_id'  => $prop_id,
        ] );

    if ( empty( $response ) || ! is_array( $response ) || empty( $response['property'] ) ) {
        return '<div class="rnlp-not-found-wrap">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="#94a3b8" width="48" height="48"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"/></svg>
            <h2>Property Unavailable</h2>
            <p>This property may have been removed or is no longer available.</p>
            <a href="' . esc_url( home_url() ) . '" class="rnlp-not-found-btn">&larr; Browse Listings</a>
        </div>';
    }

    $prop         = $response['property'];
    $demographics = $response['demographics'] ?? null;

    $name      = $prop['PropertyName'] ?? '';
    $canonical = function_exists( 'rnlp_property_detail_url' )
        ? rnlp_property_detail_url( $prop )
        : home_url( '/property/' ) . sanitize_title( $name ) . '/?listing_id=' . rawurlencode( $prop_id );

    ob_start();
    include __DIR__ . '/single-property-tpl.php';
    return ob_get_clean();
}
add_shortcode( 'property', 'rnlp_single_property_shortcode' );
