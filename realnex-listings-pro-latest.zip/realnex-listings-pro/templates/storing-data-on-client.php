<?php
if (!defined("ABSPATH")) exit;
$transformedResponseForClient = array_map(function($item) {
		include('inc/prop-types.php');
		$LandSize = $item['LandSize'] ? $item['LandSize'] : 0;
		$photos = function_exists('rnlp_photo_attachments') ? rnlp_photo_attachments($item) : (array)($item['Attachments'] ?? []);
		$img_src = isset($photos[0]["FileName"]) ? $photos[0]["FileName"] : plugin_dir_url( __FILE__ ) . 'img/no-image.png';
        $listing_id = function_exists('rnlp_listing_id') ? rnlp_listing_id($item) : sanitize_text_field($item['Id'] ?? '');
        $available_values = [];
        $space_min = function_exists('rnlp_parse_area_value') ? rnlp_parse_area_value($item['SpaceAvailMin'] ?? 0) : (float)($item['SpaceAvailMin'] ?? 0);
        $space_max = function_exists('rnlp_parse_area_value') ? rnlp_parse_area_value($item['SpaceAvailMax'] ?? 0) : (float)($item['SpaceAvailMax'] ?? 0);
        if ($space_min > 0) $available_values[] = $space_min;
        if ($space_max > 0) $available_values[] = $space_max;
        foreach ((array)($item['Space'] ?? $item['Spaces'] ?? []) as $space) {
            $space_value = $space['SpaceAvailable']
                ?? $space['space_available']
                ?? $space['AvailSf']
                ?? $space['AvailableSf']
                ?? $space['SpaceAvailSf']
                ?? null;
            $space_value = function_exists('rnlp_parse_area_value') ? rnlp_parse_area_value($space_value) : (float)$space_value;
            if ($space_value > 0) $available_values[] = $space_value;
        }
        $broker_emails = [];
        $broker_sources = [];
        if (!empty($item['User']) && is_array($item['User'])) {
            $broker_sources[] = $item['User'];
        }
        foreach ((array)($item['UserList'] ?? []) as $user) {
            if (is_array($user)) {
                $broker_sources[] = $user;
            }
        }
        foreach ($broker_sources as $user) {
            $email = strtolower(sanitize_email($user['Email'] ?? ''));
            if ($email && !in_array($email, $broker_emails, true)) {
                $broker_emails[] = $email;
            }
        }
		$readableTypes = [];
		foreach ($item['PropertyTypes'] as $type) {
				$name = array_key_exists($type, $prop_types) ? $prop_types[$type] : $type;
				array_push($readableTypes, $name);
		}
		$addressParts = array($item['PropertyName'], $item['Street'], $item['City'], $item['State'], $item['Zip']);
        $addressParts = array_filter($addressParts);
        $fullAdress = implode(', ', $addressParts);
        $address = array( $item['Street'], $item['City'], $item['State'], $item['Zip']);
        $address = array_filter($address);
        $address = implode(', ', $address);
    return array(
        'listingType' => strtoupper($item['Status']) == 'SOLD' 
													? strtoupper($item['Status']) 
													: str_replace(" ", "_", $item['ListingType']),
        'id' => $listing_id,
        'domId' => 'rnlp-listing-' . sanitize_html_class($listing_id),
        'propertyType' => $item['PropertyTypes'],
        'readableTypes' => $readableTypes,
        'brokerEmails' => $broker_emails,
        'fullAddress' => $fullAdress,
        'address' => $address,
        'name' => $item['PropertyName'],
        'buildingSize' => $item['BuildingSf'] ? $item['BuildingSf'] : 0,
				'availableSpace' => array(
            'min' => $available_values ? min($available_values) : 0,
            'max' => $available_values ? max($available_values) : 0
        ),
				'buildingPrice' => $item['ListPrice'] ? intval($item['ListPrice']) : 0,
				'geo' => array(
					'lat' => isset($item['GeoPoint']) ? $item['GeoPoint']['Lat'] : null,
					'lng' => isset($item['GeoPoint']) ? $item['GeoPoint']['Lon'] : null
				),
				'img' => $img_src,
				'url' => function_exists('rnlp_property_detail_url')
                    ? rnlp_property_detail_url($item)
                    : home_url('/property/') . sanitize_title($item['PropertyName'] ?? '') . '/?listing_id=' . rawurlencode($listing_id)
    );
}, $response);
$data = json_encode($transformedResponseForClient);

echo "<script>";
echo "window.nexFilterPlugin = {data: $data};";
$_rnlp_map_opts = get_option('api_settings', []);
$_map_zip  = esc_js($_rnlp_map_opts['map_default_zip']  ?? '');
$_map_zoom = (int)($_rnlp_map_opts['map_default_zoom']  ?? 10);
echo "window.RNLP_MAP_CONFIG = " . json_encode(['defaultZip' => $_rnlp_map_opts['map_default_zip'] ?? '', 'defaultZoom' => $_map_zoom]) . ";";
echo "</script>";
?>
