<?php
if (!defined("ABSPATH")) exit;
/**
 * The template for displaying property widget
 */

    include('custom-styles.php');

    include('inc/prop-types.php');
    
    $unique_types = $pr_source['property_types'];

    $property_type_list = "";
    foreach ($unique_types as $i => $type) {
        if ($i !== array_key_last($pr_source["property_types"])){
            $property_type_list .= array_key_exists($type, $prop_types) ? $prop_types[$type] .', ' : $type .', '  ;
        }else{
            $property_type_list .= array_key_exists($type, $prop_types) ? $prop_types[$type] : $type ;
        }
    }

?>

    <div class="nex !max-w-screen-xl m-auto p-0" >

        <div class="preloader">
        <img class="prl" src="
        data:image/svg+xml;charset=UTF-8,%3csvg class='svg' width='100px' height='100px' version='1.1' id='L7' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 100 100' enable-background='new 0 0 100 100' xml:space='preserve'%3e%3cpath 
        fill='<?php echo $prel_one ?>' d='M31.6,3.5C5.9,13.6-6.6,42.7,3.5,68.4c10.1,25.7,39.2,38.3,64.9,28.1l-3.1-7.9c-21.3,8.4-45.4-2-53.8-23.3 c-8.4-21.3,2-45.4,23.3-53.8L31.6,3.5z'%3e%3canimateTransform attributeName='transform' attributeType='XML' type='rotate' dur='2s' from='0 50 50' to='360 50 50' repeatCount='indefinite' /%3e%3c/path%3e%3cpath 
        fill='<?php echo $prel_one ?>' d='M42.3,39.6c5.7-4.3,13.9-3.1,18.1,2.7c4.3,5.7,3.1,13.9-2.7,18.1l4.1,5.5c8.8-6.5,10.6-19,4.1-27.7 c-6.5-8.8-19-10.6-27.7-4.1L42.3,39.6z'%3e%3canimateTransform attributeName='transform' attributeType='XML' type='rotate' dur='1s' from='0 50 50' to='-360 50 50' repeatCount='indefinite' /%3e%3c/path%3e%3cpath 
        fill='<?php echo $prel_one ?>' d='M82,35.7C74.1,18,53.4,10.1,35.7,18S10.1,46.6,18,64.3l7.6-3.4c-6-13.5,0-29.3,13.5-35.3s29.3,0,35.3,13.5 L82,35.7z'%3e%3canimateTransform attributeName='transform' attributeType='XML' type='rotate' dur='2s' from='0 50 50' to='360 50 50' repeatCount='indefinite' /%3e%3c/path%3e%3c/svg%3e 
        " /></div>

                <div class="card nex-item w-full p-0">
                    
                    <div class="card-wrapper aspect-[4/3] relative ">

                        <a class="absolute top-0 w-full h-full z-10" href="<?php echo home_url().'/single-property?location-address='.str_replace(",", "",str_replace(" ", "-", trim($pr_source['full_address']))).'&type='.str_replace(" ", "-", trim($pr_source['listing_type'])).'&prop-id='.$pr_source["untouched_id"] ?>"></a>

                        <div class="photo-bg" style="background-image: url('<?php echo plugin_dir_url( __FILE__ ) . 'img/no-image.png' ?>')"> 
                            

                                <img decoding="async" src="<?php echo $img_path ?>" loading="lazy" alt="<?php echo ucwords(strtolower($pr_source["property_name"]))?>">


                            <span class="type uppercase !text-lg"><?php echo strtolower($pr_source['listing_type']) ?></span>

                            <?php if($pr_source['list_price']):?>
                                <div class="price"><span class="!text-base"><?php echo '$'.number_format($pr_source["list_price"], 0, '.', ',') ?></span></div>
                            <?php endif;?>

                            <div class="property-name ">
                                <div class="name !text-base">
                                <?php echo ucwords(strtolower($pr_source["property_name"]))?></div>

                                <div class="description flex flex-col pt-1 !text-xs md:!text-sm">

                                    <p><?php echo $pr_source['full_address'];?></p>

                                    <p><?php echo  $property_type_list ?></p>
                                    
                                    <?php if($pr_source["building_sf"]):?>
                                        <p><b>Building Size: </b> <?php echo number_format($pr_source["building_sf"], 0, '.', ',') ?> SF<br></p>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>

                            <div style="border-bottom: 5px solid <?php echo $primary_color ?>;position: absolute;bottom: 0;width: 100%;"></div>

                        </div>
                    
                    </div>

                </div>


    </div>