<?php
if (!defined("ABSPATH")) exit;

function company_shortcode($atts) {
    if (isset($_GET['prop-id'])) {
        ob_start();
        require('company-listing.php');
        return ob_get_clean();
    }

    // atts may be empty — proxy handles company_id from serial
    if (!$atts) $atts = [];

    ob_start();
    require('company-listing.php');
    return ob_get_clean();
}
add_shortcode('company', 'company_shortcode');
