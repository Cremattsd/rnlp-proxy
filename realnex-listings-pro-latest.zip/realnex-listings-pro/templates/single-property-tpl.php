<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Single Property Detail Template (v3.1)
 *
 * Available variables (set by single-property-shortcode.php):
 *   $prop       — full property array from /property proxy endpoint
 *   $prop_id    — property GUID string
 *   $canonical  — canonical URL for this property page
 */

if ( ! isset( $prop ) || empty( $prop ) ) {
    return;
}

// ── Detail page display toggles (from settings) ───────────────────────────
$_sp_s = get_option( 'api_settings', [] );
$sp_show_map        = ( $_sp_s['show_property_map']  ?? '1' ) === '1';
$sp_show_demographics = ( $_sp_s['show_demographics']  ?? '1' ) === '1';
$sp_show_neighborhood = ( $_sp_s['show_neighborhood']  ?? '1' ) === '1';
$sp_show_amenities  = ( $_sp_s['show_amenities']     ?? '1' ) === '1';
$sp_show_deal_room  = ( $_sp_s['show_deal_room']     ?? '1' ) === '1';
$sp_show_brochure   = ( $_sp_s['show_brochure_btn']  ?? '1' ) === '1';
$sp_show_share      = ( $_sp_s['show_share_btn']     ?? '1' ) === '1';
$sp_show_more       = ( $_sp_s['show_more_listings'] ?? '1' ) === '1';
$sp_show_spaces     = ( $_sp_s['show_space_table']   ?? '1' ) === '1';
$sp_show_area_intel = ( $_sp_s['show_area_intel']    ?? '1' ) === '1';

// ── Field helpers ─────────────────────────────────────────────────────────
$name        = esc_html( ucwords( strtolower( $prop['PropertyName'] ?? '' ) ) );
$status      = strtoupper( $prop['Status'] ?? 'Active' );
$listing_type = $prop['ListingType'] ?? '';
$is_sold     = $status === 'SOLD';
$badge       = $is_sold ? 'SOLD' : $listing_type;

$price_str   = '';
if ( ! empty( $prop['PriceDisclosed'] ) && ! empty( $prop['ListPrice'] ) ) {
    $price_str = '$' . number_format( (int) $prop['ListPrice'], 0, '.', ',' );
    if ( $listing_type === 'For Lease' && ! empty( $prop['PriceUnits'] ) ) {
        $price_str .= ' / SF ' . strtoupper( $prop['PriceUnits'] );
    }
}

$bldg_sf    = function_exists( 'rnlp_format_area_sf' ) ? rnlp_format_area_sf( $prop['BuildingSf'] ?? 0 ) : ( ! empty( $prop['BuildingSf'] ) ? number_format( $prop['BuildingSf'], 0, '.', ',' ) . ' SF' : '' );
$avail_sf   = function_exists( 'rnlp_available_sf_display' ) ? rnlp_available_sf_display( $prop ) : '';
$year_built   = $prop['YearBuilt']     ?? '';
$bldg_class   = $prop['BuildingClass'] ?? '';
$stories      = $prop['Stories']       ?? '';
$land_size    = function_exists( 'rnlp_lot_size_display' ) ? rnlp_lot_size_display( $prop ) : ( ! empty( $prop['LandSize'] ) ? $prop['LandSize'] . ' ' . strtoupper( $prop['LandSizeType'] ?? 'AC' ) : '' );
$prop_types   = implode( ', ', array_map( 'strtoupper', (array) ( $prop['PropertyTypes'] ?? [] ) ) );
$detail_prop_id = function_exists( 'rnlp_listing_id' ) ? rnlp_listing_id( $prop ) : sanitize_text_field( $prop['Id'] ?? $prop_id );

$lat          = floatval( $prop['AddrLatitude']  ?? 0 );
$lng          = floatval( $prop['AddrLongitude'] ?? 0 );
$has_map      = $lat && $lng;

$description = '';
foreach ( [ 'PropertyDescription', 'Description', 'Remarks', 'PublicRemarks', 'MarketingRemarks', 'Comments', 'Notes' ] as $desc_key ) {
    if ( ! empty( $prop[ $desc_key ] ) ) {
        $description = $prop[ $desc_key ];
        break;
    }
}
$desc         = wp_kses_post( $description );
$brochure_url = esc_url( $prop['BrochureUrl'] ?? '' );
$document_vault_url = function_exists( 'getDocumentVaultUrl' ) ? getDocumentVaultUrl( $prop ) : '';
$has_document_vault = function_exists( 'hasDocumentVault' ) ? hasDocumentVault( $prop ) : false;
$virtual_tour_url   = function_exists( 'getVirtualTourUrl' ) ? getVirtualTourUrl( $prop ) : '';

// Attachment type detection — scan all attachments for tours, aerial, brochure PDF
$att_aerial   = '';
$att_brochure = $brochure_url; // fall back to BrochureUrl field
foreach ( (array)( $prop['Attachments'] ?? [] ) as $_att ) {
    $_fname = strtolower( $_att['FileName'] ?? '' );
    $_atype = strtolower( $_att['AttachmentType'] ?? '' );
    $_ext   = pathinfo( $_fname, PATHINFO_EXTENSION );
    if ( ! $att_aerial && (
        strpos( $_fname, 'aerial' ) !== false || strpos( $_fname, 'drone' ) !== false
    ) ) {
        $att_aerial = esc_url( $_att['FileName'] );
    } elseif ( ! $att_brochure && ( $_ext === 'pdf' || $_atype === 'document' ) ) {
        $att_brochure = esc_url( $_att['FileName'] );
    }
    if ( $att_aerial && $att_brochure ) break;
}

$photos = function_exists( 'rnlp_photo_attachments' )
    ? rnlp_photo_attachments( $prop )
    : array_values( array_filter( array_merge( (array) ( $prop['Photos'] ?? [] ), (array) ( $prop['Attachments'] ?? [] ), (array) ( $prop['Images'] ?? [] ) ), function( $a ) {
        return is_array( $a ) && ( ! empty( $a['FileName'] ) || ! empty( $a['Url'] ) || ! empty( $a['PhotoUrl'] ) || ! empty( $a['Id'] ) || ! empty( $a['AttachmentId'] ) );
    } ) );
$hero_img = function_exists( 'rnlp_first_photo_url' ) ? rnlp_first_photo_url( $prop ) : '';
$_sp_listing_id = $prop['Id'] ?? $prop['ListingId'] ?? $prop['PropertyId'] ?? '';

// Primary broker
$users       = [];
if ( ! empty( $prop['User'] ) && is_array( $prop['User'] ) ) {
    $users[] = $prop['User'];
}
foreach ( (array) ( $prop['UserList'] ?? [] ) as $user_item ) {
    if ( is_array( $user_item ) ) {
        $users[] = $user_item;
    }
}
$broker      = $users[0] ?? [];
$broker_name = trim( ( $broker['FirstName'] ?? '' ) . ' ' . ( $broker['LastName'] ?? '' ) );
$broker_phone = formatPhoneNumber( $broker['Phone'] ?? '' );
$broker_email = sanitize_email( $broker['Email'] ?? '' );
$broker_initials    = strtoupper( substr( $broker['FirstName'] ?? 'B', 0, 1 ) . substr( $broker['LastName'] ?? 'R', 0, 1 ) );
$broker_id          = $broker['Id'] ?? $broker['UserId'] ?? $broker['AgentId'] ?? '';
$broker_listing_url = $broker_id ? esc_url( home_url( '/agent-listing/?broker_id=' . rawurlencode( $broker_id ) ) ) : '';

// Spaces table
$spaces = array_values( array_filter( (array) ( $prop['Space'] ?? $prop['Spaces'] ?? [] ), function( $space ) {
    if ( ! is_array( $space ) ) {
        return false;
    }
    $space_avail = $space['SpaceAvailable'] ?? $space['space_available'] ?? $space['AvailSf'] ?? $space['AvailableSf'] ?? $space['SpaceAvailSf'] ?? '';
    return ( function_exists( 'rnlp_parse_area_value' ) ? rnlp_parse_area_value( $space_avail ) : (float) $space_avail ) > 0
        || ! empty( $space['LeaseType'] )
        || ! empty( $space['DateAvailable'] )
        || ! empty( $space['AvailDate'] );
} ) );

// Deal Room URL
$deal_room_url = 'https://realnex.com/listings/client/1/' . rawurlencode( $detail_prop_id ) . '/' . rawurlencode( $detail_prop_id );

// Badge slug for CSS
$badge_slug = strtolower( str_replace( ' ', '-', $badge ) );

// Plan check for Area Intelligence pro features
$is_pro = in_array( get_option( 'rnlp_serial_meta', [] )['plan'] ?? 'basic', [ 'pro', 'enterprise' ] );

// Enrich call — walk score, traffic, environment, solar, amenities, demographics
$enrich = [
    'walk_score'   => null,
    'traffic'      => null,
    'environment'  => null,
    'solar'        => null,
    'amenities'    => null,
    'demographics' => null,
];
if ( $sp_show_area_intel && $lat && $lng ) {
    $serial_tmp = get_option( 'api_settings', [] )['rnlp_serial'] ?? '';
    if ( $serial_tmp ) {
        try {
            $enrich_response = rnlp_proxy_request( '/enrich', [
                'serial'  => $serial_tmp,
                'lat'     => $lat,
                'lon'     => $lng,
                'zip'     => $prop['Zip'] ?? '',
                'address' => trim( ( $prop['Street'] ?? '' ) . ' ' . ( $prop['City'] ?? '' ) . ' ' . ( $prop['State'] ?? '' ) ),
                'plan'    => get_option( 'rnlp_serial_meta', [] )['plan'] ?? 'basic',
            ] );
            if ( is_array( $enrich_response ) ) {
                $enrich = array_merge( $enrich, $enrich_response );
            }
        } catch ( Throwable $e ) {
            $enrich['environment'] = [ 'air_quality_pct' => null, 'flood_risk_pct' => null, 'badge' => '' ];
            $enrich['solar']       = [ 'annual_ghi_kwh' => null ];
        }
    }
}

// More from broker — same serial, limit 3, exclude current
$serial  = get_option( 'api_settings', [] )['rnlp_serial'] ?? '';
$more_listings = [];
if ( $serial && $broker_email ) {
    $all = rnlp_listings_request( [
        'startIndex'  => 0,
        'NoOfRecords' => 10000,
        'SortBy'      => 'updated',
        'SortHow'     => 'desc',
        'SearchType'  => '',
    ] );
    if ( is_array( $all[0] ?? null ) ) {
        foreach ( $all[0] as $lp ) {
            if ( ( function_exists( 'rnlp_listing_id' ) ? rnlp_listing_id( $lp ) : ( $lp['Id'] ?? '' ) ) === $detail_prop_id ) continue;
            $lp_users = [];
            if ( ! empty( $lp['User'] ) && is_array( $lp['User'] ) ) {
                $lp_users[] = $lp['User'];
            }
            foreach ( (array) ( $lp['UserList'] ?? [] ) as $lu_item ) {
                if ( is_array( $lu_item ) ) {
                    $lp_users[] = $lu_item;
                }
            }
            foreach ( $lp_users as $lu ) {
                if ( strtolower( $lu['Email'] ?? '' ) === strtolower( $broker_email ) ) {
                    $more_listings[] = $lp;
                    break;
                }
            }
            if ( count( $more_listings ) >= 3 ) break;
        }
    }
}
?>
<?php
// ── JSON-LD for this property (valid in <body> per spec) ─────────────────
$schema_image = '';
foreach ( (array)($prop['Attachments'] ?? []) as $sa ) {
    if ( ($sa['AttachmentType'] ?? '') === 'photo' && !empty($sa['FileName']) ) {
        $schema_image = $sa['FileName'] . '?h=800&mode=max';
        break;
    }
}
$schema = [
    '@context'    => 'https://schema.org',
    '@type'       => 'RealEstateListing',
    'name'        => $prop['PropertyName'] ?? '',
    'description' => !empty($prop['PropertyDescription'])
                        ? $prop['PropertyDescription']
                        : ($prop['PropertyName'] ?? '') . ' located at ' . ($prop['Street'] ?? ''),
    'url'         => $canonical,
    'image'       => $schema_image,
    'address'     => [
        '@type'           => 'PostalAddress',
        'streetAddress'   => $prop['Street']  ?? '',
        'addressLocality' => $prop['City']    ?? '',
        'addressRegion'   => $prop['State']   ?? '',
        'postalCode'      => $prop['Zip']     ?? '',
        'addressCountry'  => 'US',
    ],
    'geo'         => [
        '@type'     => 'GeoCoordinates',
        'latitude'  => floatval($prop['AddrLatitude']  ?? 0),
        'longitude' => floatval($prop['AddrLongitude'] ?? 0),
    ],
    'offers'      => [
        '@type'        => 'Offer',
        'price'        => $prop['ListPrice'] ?? $prop['LeaseRateMin'] ?? null,
        'priceCurrency' => 'USD',
        'availability' => 'https://schema.org/InStock',
    ],
];
echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
?>
<div class="rnlp-sp-wrap">

    <!-- ── HERO ──────────────────────────────────────────────────────── -->
    <div class="rnlp-sp-hero"<?php if ( $hero_img ) echo ' style="background-image:url(' . $hero_img . ')"'; ?>>
        <div class="rnlp-sp-hero-overlay"></div>

        <span class="rnlp-sp-badge rnlp-sp-badge--<?php echo esc_attr( $badge_slug ); ?>">
            <?php echo esc_html( $badge ); ?>
        </span>

        <?php if ( $price_str ): ?>
        <span class="rnlp-sp-price"><?php echo esc_html( $price_str ); ?></span>
        <?php endif; ?>

        <div class="rnlp-sp-hero-content">
            <h1 class="rnlp-sp-hero-title"><?php echo $name; ?></h1>
            <?php
            $addr_parts = array_filter( [
                $prop['Street'] ?? '',
                $prop['City']   ?? '',
                $prop['State']  ?? '',
                $prop['Zip']    ?? '',
            ] );
            if ( $addr_parts ) echo '<p class="rnlp-sp-hero-addr">' . esc_html( implode( ', ', $addr_parts ) ) . '</p>';
            ?>
        </div>
    </div>

    <?php if ( ! empty( $photos ) ): ?>
    <div class="rnlp-sp-carousel" data-total="<?php echo count( $photos ); ?>">
        <div class="rnlp-carousel-track">
            <?php foreach ( $photos as $i => $photo ):
                $_att_id  = $photo['Id'] ?? $photo['AttachmentId'] ?? $photo['id'] ?? '';
                $_file_url = $photo['FileName'] ?? $photo['Url'] ?? $photo['url'] ?? $photo['PhotoUrl'] ?? '';
                $_slide_url = ( $_att_id && $_sp_listing_id )
                    ? 'https://realnex.com/s3/realnex.production/ListingAttachment/' . rawurlencode( (string) $_sp_listing_id ) . '/' . rawurlencode( (string) $_att_id ) . '.jpg?h=800&mode=max'
                    : ( $_file_url ? rnlp_attachment_image_url( $_file_url, 'h=800&mode=max&404=default&autorotate=true' ) : '' );
                $_full_url = ( $_att_id && $_sp_listing_id )
                    ? 'https://realnex.com/s3/realnex.production/ListingAttachment/' . rawurlencode( (string) $_sp_listing_id ) . '/' . rawurlencode( (string) $_att_id ) . '.jpg'
                    : $_file_url;
            ?>
            <div class="rnlp-carousel-slide">
                <img src="<?php echo esc_url( $_slide_url ); ?>"
                     data-fullsrc="<?php echo esc_url( $_full_url ); ?>"
                     alt="<?php echo esc_attr( ( $prop['PropertyName'] ?? '' ) . ' photo ' . ( $i + 1 ) ); ?>"
                     class="rnlp-carousel-img">
            </div>
            <?php endforeach; ?>
        </div>

        <?php if ( count( $photos ) > 1 ): ?>
        <button class="rnlp-carousel-btn rnlp-carousel-prev" type="button" aria-label="Previous photo">‹</button>
        <button class="rnlp-carousel-btn rnlp-carousel-next" type="button" aria-label="Next photo">›</button>
        <div class="rnlp-carousel-counter">
            <span class="rnlp-photo-current">1</span> / <span class="rnlp-photo-total"><?php echo count( $photos ); ?></span>
        </div>
        <?php endif; ?>
    </div>

    <?php if ( count( $photos ) > 1 ): ?>
    <div class="rnlp-thumb-strip">
        <?php foreach ( $photos as $i => $photo ):
            $_att_id    = $photo['Id'] ?? $photo['AttachmentId'] ?? $photo['id'] ?? '';
            $_file_url = $photo['FileName'] ?? $photo['Url'] ?? $photo['url'] ?? $photo['PhotoUrl'] ?? '';
            $_thumb_url = ( $_att_id && $_sp_listing_id )
                ? 'https://realnex.com/s3/realnex.production/ListingAttachment/' . rawurlencode( (string) $_sp_listing_id ) . '/' . rawurlencode( (string) $_att_id ) . '.jpg?h=200&mode=max'
                : ( $_file_url ? rnlp_attachment_image_url( $_file_url, 'h=200&mode=max&404=default&autorotate=true' ) : '' );
        ?>
        <img class="rnlp-thumb<?php echo $i === 0 ? ' active' : ''; ?>"
             src="<?php echo esc_url( $_thumb_url ); ?>"
             data-index="<?php echo (int) $i; ?>"
             alt="Photo <?php echo (int) $i + 1; ?>">
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <!-- ── FACTS BAR ─────────────────────────────────────────────────── -->
    <div class="rnlp-sp-facts-bar">
        <?php if ( $bldg_sf ):  ?><div class="rnlp-sp-fact"><span class="rnlp-sp-fact-label">Building SF</span><span class="rnlp-sp-fact-val"><?php echo esc_html( $bldg_sf ); ?></span></div><?php endif; ?>
        <?php if ( $avail_sf ): ?><div class="rnlp-sp-fact"><span class="rnlp-sp-fact-label">Available SF</span><span class="rnlp-sp-fact-val"><?php echo esc_html( $avail_sf ); ?></span></div><?php endif; ?>
        <?php if ( $year_built ): ?><div class="rnlp-sp-fact"><span class="rnlp-sp-fact-label">Year Built</span><span class="rnlp-sp-fact-val"><?php echo esc_html( $year_built ); ?></span></div><?php endif; ?>
        <?php if ( $bldg_class ): ?><div class="rnlp-sp-fact"><span class="rnlp-sp-fact-label">Building Class</span><span class="rnlp-sp-fact-val"><?php echo esc_html( $bldg_class ); ?></span></div><?php endif; ?>
        <?php if ( $stories ): ?><div class="rnlp-sp-fact"><span class="rnlp-sp-fact-label">Stories</span><span class="rnlp-sp-fact-val"><?php echo esc_html( $stories ); ?></span></div><?php endif; ?>
        <?php if ( $land_size ): ?><div class="rnlp-sp-fact"><span class="rnlp-sp-fact-label">Lot Size</span><span class="rnlp-sp-fact-val"><?php echo esc_html( $land_size ); ?></span></div><?php endif; ?>
        <?php if ( $prop_types ): ?><div class="rnlp-sp-fact"><span class="rnlp-sp-fact-label">Property Type</span><span class="rnlp-sp-fact-val"><?php echo esc_html( $prop_types ); ?></span></div><?php endif; ?>
    </div>

    <!-- ── TWO COLUMN BODY ───────────────────────────────────────────── -->
    <div class="rnlp-sp-body">

        <!-- LEFT ─────────────────────────────────────────────────────── -->
        <div class="rnlp-sp-left">

            <section class="rnlp-sp-section">
                <h2 class="rnlp-sp-section-title">Property Description</h2>
                <div class="rnlp-sp-desc">
                    <?php if ( $desc ): ?>
                        <?php echo $desc; ?>
                    <?php else: ?>
                        <p class="rnlp-sp-desc-placeholder">Contact us for more information about this property.</p>
                    <?php endif; ?>
                </div>
            </section>

            <!-- Space Available Table -->
            <?php if ( $sp_show_spaces && ! empty( $spaces ) ): ?>
            <section class="rnlp-sp-section">
                <h2 class="rnlp-sp-section-title">Space Available</h2>
                <div class="rnlp-sp-table-wrap">
                    <table class="rnlp-sp-table">
                        <thead>
                            <tr>
                                <th>Space #</th>
                                <th>Available SF</th>
                                <th>Lease Type</th>
                                <th>Rate/SF</th>
                                <th>Date Available</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ( $spaces as $sp ): ?>
                            <tr>
                                <td><?php echo esc_html( $sp['SpaceNumber'] ?? $sp['Name'] ?? '' ); ?></td>
                                <td><?php
                                    $sp_avail = $sp['SpaceAvailable'] ?? $sp['space_available'] ?? $sp['AvailSf'] ?? $sp['AvailableSf'] ?? $sp['SpaceAvailSf'] ?? '';
                                    echo esc_html( function_exists( 'rnlp_format_area_sf' ) ? rnlp_format_area_sf( $sp_avail ) : ( $sp_avail ? number_format( (float) $sp_avail, 0, '.', ',' ) . ' SF' : '' ) );
                                ?></td>
                                <td><?php echo esc_html( $sp['LeaseType'] ?? '' ); ?></td>
                                <td><?php
                                    $rate = $sp['LeaseRate'] ?? $sp['RateSf'] ?? $sp['RateMin'] ?? null;
                                    echo $rate ? esc_html( '$' . number_format( (float) $rate, 2 ) ) : '';
                                ?></td>
                                <td><?php echo esc_html( $sp['DateAvailable'] ?? $sp['AvailDate'] ?? '' ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
            <?php endif; // show_space_table ?>

            <!-- Demographics -->
            <?php if ( $sp_show_demographics ): ?>
            <div id="rnlp-demo-section" class="rnlp-sp-section" style="display:none">
                <h2 class="rnlp-sp-section-title">Area Demographics &middot; <?php echo esc_html( $prop['Zip'] ?? '' ); ?></h2>
                <div id="rnlp-demographics" class="rnlp-location-stats"></div>
            </div>

            <?php endif; // show_demographics ?>

            <!-- Neighborhood -->
            <?php if ( $sp_show_neighborhood ): ?>
            <div id="rnlp-neighborhood-section" class="rnlp-sp-section" style="display:none">
                <h2 class="rnlp-sp-section-title">Neighborhood</h2>
                <div id="rnlp-neighborhood" class="rnlp-neighborhood-card">
                    <svg viewBox="0 0 24 24" style="width:14px;height:14px;stroke:var(--rnlp-accent,#013161);fill:none;stroke-width:2;margin-right:6px;flex-shrink:0"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                </div>
            </div>

            <?php endif; // show_neighborhood ?>

            <!-- Nearby Amenities -->
            <?php if ( $sp_show_amenities ): ?>
            <div id="rnlp-amenities-section" class="rnlp-sp-section" style="display:none">
                <h2 class="rnlp-sp-section-title">Nearby Amenities <span style="font-size:10px;font-weight:400;color:var(--rnlp-meta-text,#94a3b8)">(within 500m)</span></h2>
                <div id="rnlp-amenities" class="rnlp-amenities-row"></div>
            </div>

            <?php endif; // show_amenities ?>

            <!-- Environmental (hidden by default, enable later) -->
            <div id="rnlp-env-section" style="display:none">
                <div id="rnlp-environmental"></div>
            </div>

            <!-- Map -->
            <?php if ( $sp_show_map && $has_map ): ?>
            <section class="rnlp-sp-section">
                <h2 class="rnlp-sp-section-title">Location</h2>
                <div class="rnlp-sp-map-container"
                     id="rnlp-sp-map"
                     data-lat="<?php echo esc_attr( $lat ); ?>"
                     data-lng="<?php echo esc_attr( $lng ); ?>"
                     data-title="<?php echo esc_attr( $name ); ?>">
                </div>
            </section>
            <?php endif; ?>

            <!-- Area Intelligence -->
            <?php if ( $sp_show_area_intel ): ?>
            <section class="rnlp-sp-section rnlp-intel-section">
                <h2 class="rnlp-sp-section-title">
                    Area Intelligence
                    <?php if ( ! $is_pro ): ?>
                    <span class="rnlp-intel-pro-badge">Pro</span>
                    <?php endif; ?>
                </h2>

                <div class="rnlp-intel-grid<?php echo $is_pro ? '' : ' rnlp-intel-locked'; ?>">

                    <?php
                    // Walk Score card
                    $ws = $enrich['walk_score'] ?? null;
                    $ws_score = $ws['walkscore'] ?? null;
                    $ws_desc  = $ws['description'] ?? 'Walk Score';
                    ?>
                    <div class="rnlp-intel-card">
                        <div class="rnlp-intel-card-label">Walk Score</div>
                        <?php if ( $ws_score !== null ): ?>
                        <div class="rnlp-intel-gauge">
                            <svg viewBox="0 0 120 80" width="120" height="80">
                                <path d="M10,70 A60,60 0 0,1 110,70" fill="none" stroke="#e2e8f0" stroke-width="12" stroke-linecap="round"/>
                                <?php
                                $pct = min( 100, max( 0, (int) $ws_score ) ) / 100;
                                $arc_len = 188.5; // half-circle circumference for r=60
                                $dash = $pct * $arc_len;
                                $color = $ws_score >= 70 ? '#059669' : ( $ws_score >= 50 ? '#d97706' : '#dc2626' );
                                ?>
                                <path d="M10,70 A60,60 0 0,1 110,70" fill="none" stroke="<?php echo $color; ?>" stroke-width="12" stroke-linecap="round"
                                      stroke-dasharray="<?php echo $dash; ?> <?php echo $arc_len; ?>" stroke-dashoffset="0"/>
                                <text x="60" y="68" text-anchor="middle" font-size="24" font-weight="700" fill="<?php echo $color; ?>"><?php echo (int) $ws_score; ?></text>
                            </svg>
                        </div>
                        <div class="rnlp-intel-card-sub"><?php echo esc_html( $ws_desc ); ?></div>
                        <?php else: ?>
                        <div class="rnlp-intel-card-na">N/A</div>
                        <?php endif; ?>
                    </div>

                    <?php
                    // Traffic card
                    $traffic = $enrich['traffic'] ?? null;
                    $traffic_est = $traffic['daily_estimate'] ?? null;
                    $traffic_label = $traffic['level'] ?? '';
                    ?>
                    <div class="rnlp-intel-card<?php echo ( ! $is_pro ) ? ' rnlp-intel-blur' : ''; ?>">
                        <div class="rnlp-intel-card-label">Nearby Traffic</div>
                        <?php if ( $traffic_est !== null ): ?>
                        <div class="rnlp-intel-bar-wrap">
                            <?php
                            $t_pct = min( 100, round( $traffic_est / 500 ) );
                            $t_color = $t_pct > 66 ? '#dc2626' : ( $t_pct > 33 ? '#d97706' : '#059669' );
                            ?>
                            <div class="rnlp-intel-bar-bg">
                                <div class="rnlp-intel-bar-fill" style="width:<?php echo $t_pct; ?>%;background:<?php echo $t_color; ?>"></div>
                            </div>
                        </div>
                        <div class="rnlp-intel-card-val"><?php echo number_format( (int) $traffic_est ); ?> vehicles/day est.</div>
                        <div class="rnlp-intel-card-sub"><?php echo esc_html( $traffic_label ); ?></div>
                        <?php else: ?>
                        <div class="rnlp-intel-card-na">N/A</div>
                        <?php endif; ?>
                        <?php if ( ! $is_pro ): ?><div class="rnlp-intel-pro-lock">Pro</div><?php endif; ?>
                    </div>

                    <?php
                    // Environment card
                    $env = $enrich['environment'] ?? null;
                    $air_pct = $env['air_quality_pct'] ?? null;
                    $flood_pct = $env['flood_risk_pct'] ?? null;
                    $env_badge = $env['badge'] ?? '';
                    ?>
                    <div class="rnlp-intel-card<?php echo ( ! $is_pro ) ? ' rnlp-intel-blur' : ''; ?>">
                        <div class="rnlp-intel-card-label">Environment</div>
                        <?php if ( $air_pct !== null || $env_badge ): ?>
                        <div class="rnlp-intel-env-badge rnlp-env-<?php echo esc_attr( strtolower( str_replace( ' ', '-', $env_badge ) ) ); ?>">
                            <?php echo esc_html( $env_badge ?: 'Average' ); ?>
                        </div>
                        <?php if ( $air_pct !== null ): ?>
                        <div class="rnlp-intel-card-sub">Air quality: <?php echo (int) $air_pct; ?>th percentile</div>
                        <?php endif; ?>
                        <?php if ( $flood_pct !== null ): ?>
                        <div class="rnlp-intel-card-sub">Flood risk: <?php echo (int) $flood_pct; ?>th percentile</div>
                        <?php endif; ?>
                        <?php else: ?>
                        <div class="rnlp-intel-card-na">N/A</div>
                        <?php endif; ?>
                        <?php if ( ! $is_pro ): ?><div class="rnlp-intel-pro-lock">Pro</div><?php endif; ?>
                    </div>

                    <?php
                    // Solar card
                    $solar = $enrich['solar'] ?? null;
                    $solar_ghi = $solar['annual_ghi_kwh'] ?? null;
                    ?>
                    <div class="rnlp-intel-card<?php echo ( ! $is_pro ) ? ' rnlp-intel-blur' : ''; ?>">
                        <div class="rnlp-intel-card-label">Solar Potential</div>
                        <?php if ( $solar_ghi !== null ): ?>
                        <?php
                        $s_pct = min( 100, round( $solar_ghi / 8 ) );
                        $s_color = $s_pct > 66 ? '#d97706' : ( $s_pct > 33 ? '#f59e0b' : '#94a3b8' );
                        ?>
                        <div class="rnlp-intel-bar-wrap">
                            <div class="rnlp-intel-bar-bg">
                                <div class="rnlp-intel-bar-fill" style="width:<?php echo $s_pct; ?>%;background:<?php echo $s_color; ?>"></div>
                            </div>
                        </div>
                        <div class="rnlp-intel-card-val"><?php echo number_format( (float) $solar_ghi, 1 ); ?> kWh/m²/day</div>
                        <div class="rnlp-intel-card-sub">Annual avg solar resource</div>
                        <?php else: ?>
                        <div class="rnlp-intel-card-na">N/A</div>
                        <?php endif; ?>
                        <?php if ( ! $is_pro ): ?><div class="rnlp-intel-pro-lock">Pro</div><?php endif; ?>
                    </div>

                    <?php
                    // Demographics card
                    $demo = $enrich['demographics'] ?? null;
                    ?>
                    <?php if ( $demo ): ?>
                    <div class="rnlp-intel-card rnlp-intel-card--wide<?php echo ( ! $is_pro ) ? ' rnlp-intel-blur' : ''; ?>">
                        <div class="rnlp-intel-card-label">Demographics</div>
                        <div class="rnlp-intel-demo-grid">
                            <?php if ( ! empty( $demo['population'] ) ): ?>
                            <div class="rnlp-intel-demo-item">
                                <div class="rnlp-intel-demo-val"><?php echo number_format( (int) $demo['population'] ); ?></div>
                                <div class="rnlp-intel-demo-label">Population</div>
                            </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $demo['median_income'] ) ): ?>
                            <div class="rnlp-intel-demo-item">
                                <div class="rnlp-intel-demo-val">$<?php echo number_format( (int) $demo['median_income'] ); ?></div>
                                <div class="rnlp-intel-demo-label">Median Income</div>
                            </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $demo['median_home_value'] ) ): ?>
                            <div class="rnlp-intel-demo-item">
                                <div class="rnlp-intel-demo-val">$<?php echo number_format( (int) $demo['median_home_value'] ); ?></div>
                                <div class="rnlp-intel-demo-label">Median Home Value</div>
                            </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $demo['unemployment'] ) ): ?>
                            <div class="rnlp-intel-demo-item">
                                <div class="rnlp-intel-demo-val"><?php echo number_format( (int) $demo['unemployment'] ); ?></div>
                                <div class="rnlp-intel-demo-label">Unemployed</div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php if ( ! $is_pro ): ?><div class="rnlp-intel-pro-lock">Pro</div><?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php
                    // Amenities card
                    $amenities = $enrich['amenities'] ?? null;
                    ?>
                    <?php if ( ! empty( $amenities ) ): ?>
                    <div class="rnlp-intel-card rnlp-intel-card--wide<?php echo ( ! $is_pro ) ? ' rnlp-intel-blur' : ''; ?>">
                        <div class="rnlp-intel-card-label">Nearby Amenities <span style="font-weight:400;color:#94a3b8">(800m)</span></div>
                        <div class="rnlp-intel-amenity-pills">
                            <?php
                            $amenity_icons = [
                                'restaurant' => '🍽️', 'cafe' => '☕', 'bank' => '🏦',
                                'pharmacy'   => '💊', 'hospital' => '🏥', 'parking' => '🅿️',
                                'supermarket' => '🛒',
                            ];
                            foreach ( $amenities as $type => $count ):
                            ?>
                            <div class="rnlp-intel-amenity-pill">
                                <?php echo $amenity_icons[ $type ] ?? '📍'; ?>
                                <?php echo (int) $count; ?> <?php echo esc_html( $type ); ?><?php echo $count > 1 ? 's' : ''; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php if ( ! $is_pro ): ?><div class="rnlp-intel-pro-lock">Pro</div><?php endif; ?>
                    </div>
                    <?php endif; ?>

                </div><!-- /.rnlp-intel-grid -->

                <?php if ( ! $is_pro ): ?>
                <div class="rnlp-intel-upgrade-notice">
                    Upgrade to <strong>Pro</strong> to unlock traffic, environment, solar, demographics, and amenity data.
                    <a href="https://realnex.com" target="_blank" rel="noopener">Learn more &rarr;</a>
                </div>
                <?php endif; ?>

            </section>
            <?php endif; // show_area_intel ?>

        </div>

        <!-- RIGHT ────────────────────────────────────────────────────── -->
        <div class="rnlp-sp-right">
            <div class="rnlp-sp-sidebar">

                <!-- Broker card -->
                <?php if ( $broker_name ): ?>
                <div class="rnlp-sp-broker-card">
                    <div class="rnlp-sp-broker-avatar"><?php echo esc_html( $broker_initials ); ?></div>
                    <div class="rnlp-sp-broker-info">
                        <?php if ( $broker_listing_url ): ?>
                        <a class="rnlp-sp-broker-name rnlp-sp-broker-name--link" href="<?php echo $broker_listing_url; ?>"><?php echo esc_html( $broker_name ); ?></a>
                        <?php else: ?>
                        <div class="rnlp-sp-broker-name"><?php echo esc_html( $broker_name ); ?></div>
                        <?php endif; ?>
                        <?php if ( $broker_phone ): ?>
                        <div class="rnlp-sp-broker-phone">
                            <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $broker['Phone'] ) ); ?>"><?php echo esc_html( $broker_phone ); ?></a>
                        </div>
                        <?php endif; ?>
                        <?php if ( $broker_email ): ?>
                        <div class="rnlp-sp-broker-email">
                            <a href="mailto:<?php echo esc_attr( antispambot( $broker_email ) ); ?>"><?php echo esc_html( antispambot( $broker_email ) ); ?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php if ( $broker_phone || $broker_email ): ?>
                    <div class="rnlp-sp-broker-actions">
                        <?php if ( $broker_phone ): ?>
                        <a class="rnlp-sp-btn rnlp-sp-btn--outline" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $broker['Phone'] ) ); ?>">Call</a>
                        <?php endif; ?>
                        <?php if ( $broker_email ): ?>
                        <a class="rnlp-sp-btn rnlp-sp-btn--outline" href="mailto:<?php echo esc_attr( antispambot( $broker_email ) ); ?>">Email</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Primary detail actions -->
                <button class="rnlp-sp-btn rnlp-sp-btn--inquire rnlp-inquire-btn"
                    data-prop-name="<?php echo esc_attr( $name ); ?>"
                    data-prop-id="<?php echo esc_attr( $detail_prop_id ); ?>"
                    data-broker-email="<?php echo esc_attr( $broker_email ); ?>"
                    type="button">
                    Inquire About This Property
                </button>

                <?php if ( ! empty( $prop['Id'] ) ): ?>
                <a class="rnlp-sp-btn rnlp-sp-btn--outline"
                   href="https://realnex.com/listings/client/1/<?php echo intval( $prop['Id'] ); ?>/<?php echo intval( $prop['Id'] ); ?>"
                   target="_blank" rel="noopener">
                    ACCESS REALNEX VAULT
                </a>
                <?php endif; ?>

                <?php if ( $virtual_tour_url ): ?>
                <a class="rnlp-sp-btn rnlp-sp-btn--outline"
                   href="<?php echo esc_url( $virtual_tour_url ); ?>"
                   target="_blank" rel="noopener noreferrer">
                    Virtual Tour
                </a>
                <?php endif; ?>

                <!-- Share (always) -->
                <?php if ( $sp_show_share ): ?>
                <button class="rnlp-sp-btn rnlp-sp-btn--outline rnlp-sp-copy-url" type="button"
                        data-url="<?php echo esc_attr( $canonical ); ?>">
                    Share Property
                </button>
                <?php endif; ?>

            </div>
        </div>

    </div><!-- /.rnlp-sp-body -->

    <!-- ── MORE FROM THIS BROKER ─────────────────────────────────────── -->
    <?php if ( $sp_show_more && ! empty( $more_listings ) ): ?>
    <section class="rnlp-sp-more">
        <h2 class="rnlp-sp-more-title">More from <?php echo esc_html( $broker_name ); ?></h2>
        <div class="rnlp-sp-more-grid">
            <?php
            include_once __DIR__ . '/inc/prop-types.php';
            foreach ( $more_listings as $ml ):
                $ml_img = '';
                $ml_photos = function_exists( 'rnlp_photo_attachments' ) ? rnlp_photo_attachments( $ml ) : (array) ( $ml['Attachments'] ?? [] );
                if ( ! empty( $ml_photos[0]['FileName'] ) ) {
                    $ml_img = function_exists( 'rnlp_attachment_image_url' )
                        ? rnlp_attachment_image_url( $ml_photos[0]['FileName'], 'h=400&mode=max&404=default&autorotate=true' )
                        : esc_url( $ml_photos[0]['FileName'] );
                }
                $ml_url   = function_exists( 'rnlp_property_detail_url' )
                    ? rnlp_property_detail_url( $ml )
                    : home_url( '/property/' ) . sanitize_title( $ml['PropertyName'] ?? '' ) . '/?listing_id=' . rawurlencode( $ml['Id'] ?? '' );
                $ml_price = '';
                if ( ! empty( $ml['PriceDisclosed'] ) && ! empty( $ml['ListPrice'] ) ) {
                    $ml_price = '$' . number_format( (int) $ml['ListPrice'], 0, '.', ',' );
                }
                $ml_badge = strtoupper( $ml['Status'] ?? '' ) === 'SOLD' ? 'SOLD' : ( $ml['ListingType'] ?? '' );
            ?>
            <a class="rnlp-sp-more-card" href="<?php echo esc_url( $ml_url ); ?>">
                <div class="rnlp-sp-more-img"<?php if ( $ml_img ) echo ' style="background-image:url(' . $ml_img . ')"'; ?>></div>
                <div class="rnlp-sp-more-body">
                    <div class="rnlp-sp-more-badge"><?php echo esc_html( $ml_badge ); ?></div>
                    <div class="rnlp-sp-more-name"><?php echo esc_html( ucwords( strtolower( $ml['PropertyName'] ?? '' ) ) ); ?></div>
                    <div class="rnlp-sp-more-addr"><?php echo esc_html( ( $ml['Street'] ?? '' ) . ', ' . ( $ml['City'] ?? '' ) . ', ' . ( $ml['State'] ?? '' ) ); ?></div>
                    <?php if ( $ml_price ): ?><div class="rnlp-sp-more-price"><?php echo esc_html( $ml_price ); ?></div><?php endif; ?>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

</div><!-- /.rnlp-sp-wrap -->

<!-- ── Map init script ───────────────────────────────────────────────── -->
<?php if ( $has_map ): ?>
<script>
(function() {
    function initMap() {
        if (typeof L === 'undefined') { setTimeout(initMap, 200); return; }
        var el = document.getElementById('rnlp-sp-map');
        if (!el) return;
        var lat = parseFloat(el.dataset.lat);
        var lng = parseFloat(el.dataset.lng);
        var map = L.map('rnlp-sp-map').setView([lat, lng], 15);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19
        }).addTo(map);
        L.marker([lat, lng]).addTo(map)
            .bindPopup(el.dataset.title || '<?php echo esc_js( $name ); ?>');
    }
    initMap();
})();
</script>
<?php endif; ?>

<!-- ── Free API data: Census, Nominatim, Overpass, EPA ───────────────── -->
<script>
(function() {
    var lat  = <?php echo floatval( $prop['AddrLatitude']  ?? 0 ); ?>;
    var lon  = <?php echo floatval( $prop['AddrLongitude'] ?? 0 ); ?>;
    var zip  = <?php echo json_encode( $prop['Zip'] ?? '' ); ?>;

    // ── Census Demographics ──────────────────────────────────────────
    if (zip) {
        fetch('https://api.census.gov/data/2022/acs/acs5?get=B01003_001E,B19013_001E,B25077_001E,B23025_005E&for=zip%20code%20tabulation%20area:' + zip)
        .then(function(r) { if (!r.ok) throw new Error('Census unavailable'); return r.json(); })
        .then(function(data) {
            if (!data || data.length < 2) return;
            var h   = data[0];
            var v   = data[1];
            var pop   = parseInt(v[h.indexOf('B01003_001E')]);
            var inc   = parseInt(v[h.indexOf('B19013_001E')]);
            var home  = parseInt(v[h.indexOf('B25077_001E')]);
            var unemp = parseInt(v[h.indexOf('B23025_005E')]);
            var el = document.getElementById('rnlp-demographics');
            if (el && pop > 0) {
                el.innerHTML =
                    '<div class="rnlp-sp-stat"><div class="rnlp-sp-stat-val">' + pop.toLocaleString() + '</div><div class="rnlp-sp-stat-label">Population</div></div>' +
                    (inc  > 0 ? '<div class="rnlp-sp-stat"><div class="rnlp-sp-stat-val">$' + inc.toLocaleString()  + '</div><div class="rnlp-sp-stat-label">Median Income</div></div>'     : '') +
                    (home > 0 ? '<div class="rnlp-sp-stat"><div class="rnlp-sp-stat-val">$' + home.toLocaleString() + '</div><div class="rnlp-sp-stat-label">Median Home Value</div></div>' : '') +
                    (unemp > 0 ? '<div class="rnlp-sp-stat"><div class="rnlp-sp-stat-val">' + unemp.toLocaleString() + '</div><div class="rnlp-sp-stat-label">Unemployed</div></div>'       : '');
                document.getElementById('rnlp-demo-section').style.display = 'block';
            }
        }).catch(function(){});
    }

    // ── Nominatim Neighborhood ───────────────────────────────────────
    if (lat && lon) {
        fetch('https://nominatim.openstreetmap.org/reverse?lat=' + lat + '&lon=' + lon + '&format=json&addressdetails=1', {
            headers: { 'User-Agent': 'RealNexListingsPro/1.0' }
        })
        .then(function(r) { if (!r.ok) throw new Error('Nominatim unavailable'); return r.json(); })
        .then(function(data) {
            var a            = data.address || {};
            var neighborhood = a.neighbourhood || a.suburb || a.quarter || a.district || '';
            var county       = a.county || '';
            var el           = document.getElementById('rnlp-neighborhood');
            if (el && neighborhood) {
                el.innerHTML =
                    '<svg viewBox="0 0 24 24" style="width:14px;height:14px;stroke:var(--rnlp-accent,#013161);fill:none;stroke-width:2;margin-right:6px;flex-shrink:0"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>' +
                    '<span class="rnlp-nbhd-name">' + neighborhood + '</span>' +
                    (county ? '<span class="rnlp-nbhd-county"> &middot; ' + county + '</span>' : '');
                document.getElementById('rnlp-neighborhood-section').style.display = 'block';
            }
        }).catch(function(){});
    }

    // ── Overpass — Nearby Amenities ──────────────────────────────────
    if (lat && lon) {
        var overpassUrl = 'https://overpass-api.de/api/interpreter?data=[out:json][timeout:10];(node["amenity"~"restaurant|cafe|bank|pharmacy|hospital|parking"](around:500,' + lat + ',' + lon + '););out body 10;';
        fetch(overpassUrl)
        .then(function(r) { if (!r.ok) throw new Error('Overpass unavailable'); return r.json(); })
        .then(function(data) {
            if (!data || !data.elements || !data.elements.length) return;
            var counts = {};
            data.elements.forEach(function(el) {
                var t = el.tags && el.tags.amenity;
                if (t) counts[t] = (counts[t] || 0) + 1;
            });
            var el = document.getElementById('rnlp-amenities');
            if (el) {
                var icons = { restaurant:'🍽️', cafe:'☕', bank:'🏦', pharmacy:'💊', hospital:'🏥', parking:'🅿️' };
                var html  = Object.keys(counts).map(function(type) {
                    return '<div class="rnlp-amenity-pill">' + (icons[type] || '📍') + ' ' + counts[type] + ' ' + type + (counts[type] > 1 ? 's' : '') + '</div>';
                }).join('');
                if (html) {
                    el.innerHTML = html;
                    document.getElementById('rnlp-amenities-section').style.display = 'block';
                }
            }
        }).catch(function(){});
    }

    // ── EPA EJScreen (hidden by default) ─────────────────────────────
    if (lat && lon) {
        fetch('https://ejscreen.epa.gov/mapper/ejscreenRESTbroker.aspx?namestr=&geometry={"x":' + lon + ',"y":' + lat + '}&distance=1&unit=9035&areatype=&areaid=&f=pjson')
        .then(function(r) { if (!r.ok) throw new Error('EPA unavailable'); return r.json(); })
        .then(function(data) {
            if (!data || !data.data || !data.data.variables) return;
            var vars = data.data.variables;
            var el   = document.getElementById('rnlp-environmental');
            if (el) {
                var html = '';
                if (vars.P_PM25)          html += '<div class="rnlp-env-item"><span class="rnlp-env-label">Air Quality Percentile</span><span class="rnlp-env-val">' + Math.round(vars.P_PM25) + '%</span></div>';
                if (vars.P_TRAFFIC_SCORE) html += '<div class="rnlp-env-item"><span class="rnlp-env-label">Traffic Proximity</span><span class="rnlp-env-val">' + Math.round(vars.P_TRAFFIC_SCORE) + '%</span></div>';
                if (html) el.innerHTML = html;
                // env section stays hidden — enable later via style change
            }
        }).catch(function(){
            var el = document.getElementById('rnlp-environmental');
            if (el) {
                el.innerHTML = '<div class="rnlp-env-item"><span class="rnlp-env-label">Air Quality Percentile</span><span class="rnlp-env-val">N/A</span></div>' +
                    '<div class="rnlp-env-item"><span class="rnlp-env-label">Traffic Proximity</span><span class="rnlp-env-val">N/A</span></div>';
            }
        });
    }
})();
</script>

<!-- Carousel initialized by rnlpInitSingleProperty in single-property.js -->
<?php if ( $name ): ?>
<script>
(function() {
    var propName = <?php echo wp_json_encode( html_entity_decode( $name, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ); ?>;
    if ( propName ) {
        var parts = document.title.split( ' | ' );
        document.title = propName + ( parts.length > 1 ? ' | ' + parts[ parts.length - 1 ] : '' );
    }
})();
</script>
<?php endif; ?>
