<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Main listing template (full-width grid)
 */
include_once('custom-styles.php');
include_once('inc/prop-types.php');
include_once('storing-data-on-client.php');

$_rnlp_settings  = get_option('api_settings', []);
$active_theme    = $_rnlp_settings['rnlp_theme']            ?? 'classic';
$items_per_page  = (int)($_rnlp_settings['rnlp_items_per_page'] ?? 12);
$show_inquire    = $_rnlp_settings['rnlp_show_inquire']      ?? '';
$show_type_filter = !empty($_rnlp_settings['show_type_filter'] ?? '1');
$enabled_parent_types = $_rnlp_settings['property_type_filters']
    ?? ['OFC','IND','SCR','V','MF','HC','LH','SPEC','SPORT','AG','BO','MU','RES'];

// Layout & display toggles (default ON unless noted)
$lp_show_map          = ($_rnlp_settings['show_map']           ?? '1') === '1';
$lp_show_search       = ($_rnlp_settings['show_search']        ?? '1') === '1';
$lp_show_avail_filter = ($_rnlp_settings['show_avail_filter']  ?? '1') === '1';
$lp_show_sort         = ($_rnlp_settings['show_sort']          ?? '1') === '1';
$lp_show_list_toggle  = ($_rnlp_settings['show_list_toggle']   ?? '1') === '1';
$lp_show_results_count= ($_rnlp_settings['show_results_count'] ?? '1') === '1';
$lp_show_inquire_btn  = ($_rnlp_settings['show_inquire_btn']   ?? '1') === '1';
$lp_show_price        = ($_rnlp_settings['show_price_on_card'] ?? '1') === '1';
$lp_show_badges       = ($_rnlp_settings['show_badges']        ?? '1') === '1';
$lp_show_broker_card  = ($_rnlp_settings['show_broker_on_card'] ?? '') === '1';
$lp_grid_cols         = $_rnlp_settings['grid_cols']           ?? '3';
$lp_default_view      = $_rnlp_settings['default_view']        ?? 'grid';

// Customizer settings
$lp_layout          = $_rnlp_settings['layout']          ?? 'grid-map';
$lp_primary_color   = sanitize_hex_color( $_rnlp_settings['custom_color'] ?? '#013161' ) ?: '#013161';
$lp_bg_style        = $_rnlp_settings['bg_style']        ?? 'light';
$lp_font_style      = $_rnlp_settings['font_style']      ?? 'modern';
$lp_detail_behavior = $_rnlp_settings['detail_behavior'] ?? 'popup';
$_font_map = [
    'modern'  => "'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif",
    'classic' => "'Playfair Display', Georgia, serif",
    'bold'    => "'Montserrat', -apple-system, sans-serif",
];
$lp_font_family = $_font_map[ $lp_font_style ] ?? $_font_map['modern'];
?>
<style>
.rnlp-wrapper {
    --rnlp-accent: <?php echo esc_attr( $lp_primary_color ); ?>;
    --rnlp-font: <?php echo esc_attr( $lp_font_family ); ?>;
}
<?php if ( $lp_bg_style === 'dark' ): ?>
.rnlp-wrapper {
    --rnlp-bg: #0d1117;
    --rnlp-card-bg: #161b22;
    --rnlp-text: #e6edf3;
    --rnlp-card-text: #e6edf3;
    --rnlp-border: #30363d;
    --rnlp-filter-bg: #21262d;
    --rnlp-input-bg: #161b22;
    --rnlp-meta-text: #8b949e;
    background: #0d1117;
    color: #e6edf3;
}
<?php endif; ?>
</style>
<script>window.RNLP_DETAIL_MODE = '<?php echo esc_js( $lp_detail_behavior ); ?>';</script>

<div class="rnlp-wrapper rnlp-theme-<?php echo esc_attr($active_theme); ?> rnlp-layout-<?php echo esc_attr( $lp_layout ); ?>" id="rnlp-wrapper">

    <?php if ($dev_mode): ?>
    <div class="rnlp-dev-bar">
        <b>Total:</b> <?php echo $total_records; ?> records &nbsp;|&nbsp;
        <?php if (!empty($AgentIDs)) echo '<b>Brokers:</b> ' . implode(', ', array_map('esc_html', $AgentIDs)) . ' &nbsp;|&nbsp;'; ?>
        <b>Theme:</b> <?php echo esc_html($active_theme); ?>
    </div>
    <?php endif; ?>

    <div id="rnlp-broker-active-filter" class="rnlp-broker-active-filter" style="display:none">
        <h2 id="rnlp-broker-active-title" class="rnlp-broker-active-title"></h2>
        <button id="rnlp-broker-filter-reset" class="rnlp-btn rnlp-btn-outline" type="button">View All Listings</button>
    </div>

    <!-- ── Filter bar ──────────────────────────────────────────────────── -->
    <div class="rnlp-filter-bar">
        <div class="rnlp-filter-primary">

            <!-- Search -->
            <?php if ($lp_show_search): ?>
            <div class="rnlp-search-wrap">
                <svg class="rnlp-search-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><circle cx="11" cy="11" r="8"/><path stroke-linecap="round" stroke-linejoin="round" d="m21 21-4.35-4.35"/></svg>
                <input type="text" id="nex-text-search"
                    class="rnlp-input nex-input-value is--search"
                    placeholder="Address, city, state or zip…" autocomplete="off"/>
            </div>
            <?php endif; // show_search ?>

            <!-- Property type dropdown -->
            <?php if ($show_type_filter): ?>
            <div class="nex-dropdown" id="nex-properties">
                <div class="rnlp-dropdown-wrap all-prop-types relative">
                    <button class="rnlp-select-btn btn is--type-select rnlp-type-trigger" type="button">
                        <span class="nex-input-value">All property types</span>
                        <svg class="rnlp-chevron arrow" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5"/></svg>
                    </button>
                    <?php
                    $unique_types = [];
                    foreach ($response as $val) {
                        $unique_types = array_unique(array_merge($unique_types, $val['PropertyTypes']));
                    }
                    // MP Direct group definitions — only show groups with at least one listing
                    $mp_direct_groups = [
                        'Office'          => ['OFC','OFC-BLDG','OFC-BP','OFC-LOFT','OFC-MED','OFC-RD','OFC-WHSE','OFC-RET'],
                        'Industrial'      => ['IND','IND-AUTO','IND-BP','IND-DIST','IND-FLEX','IND-FRIG','IND-MFG','IND-OFC','IND-RD','IND-STOR','IND-THT','IND-WHSE'],
                        'Retail'          => ['SCR','SCR-AUTO','SCR-COM','SCR-COMM','SCR-CON','SCR-DAY','SCR-FASH','SCR-FREE','SCR-OUT','SCR-PAD','SCR-POW','SCR-REG','SCR-REST','SCR-STREET','SCR-SUP','SCR-SVC','SCR-VEH'],
                        'Land'            => ['V','V-AUTO','V-COM','V-IND','V-MULTI','V-OFC','V-OTH','V-PAD','V-RES','V-RET'],
                        'Multi-Family'    => ['MF','MF-ASSIST','MF-CONG','MF-GARD','MF-GOV','MF-MH','MF-MID','MF-SH'],
                        'Health Care'     => ['HC','HC-HOSP'],
                        'Hospitality'     => ['LH','LH-EC','LH-FULL','LH-BB'],
                        'Special Purpose' => ['SPEC','SPEC-MAR','SPEC-OTH'],
                        'Sports &amp; Ent.' => ['SPORT','SPORT-GOLF','SPORT-TH'],
                        'Agricultural'    => ['AG','AG-AGB','AG-AGR','AG-PAST','AG-TIMB'],
                        'Business Opp.'   => ['BO','BO-OTH'],
                        'Mixed Use'       => ['MU'],
                        'Residential'     => ['RES'],
                    ];
                    ?>
                    <div class="rnlp-dropdown-list nex-dropdown-list rnlp-type-dropdown">
                        <label class="rnlp-dropdown-item nex-dropdown-list-item">
                            <input class="nex-dropdown-list-item__check" type="checkbox" value="ALL"> <span>Select all</span>
                        </label>
                        <?php
                        // Map group label → parent type code for settings filter
                        $group_parent_map = [
                            'Office'=>'OFC','Industrial'=>'IND','Retail'=>'SCR',
                            'Land'=>'V','Multi-Family'=>'MF','Health Care'=>'HC',
                            'Hospitality'=>'LH','Special Purpose'=>'SPEC',
                            "Sports &amp; Ent."=>'SPORT','Agricultural'=>'AG',
                            'Business Opp.'=>'BO','Mixed Use'=>'MU','Residential'=>'RES',
                        ];
                        foreach ($mp_direct_groups as $group_label => $group_codes):
                            // Skip groups disabled in settings
                            $parent_code = $group_parent_map[$group_label] ?? '';
                            if ($parent_code && !in_array($parent_code, $enabled_parent_types)) continue;
                            $active_codes = array_values(array_intersect($group_codes, $unique_types));
                            if (empty($active_codes)) continue;
                        ?>
                        <?php if (count($active_codes) === 1): ?>
                            <label class="rnlp-dropdown-item nex-dropdown-list-item">
                                <input class="nex-dropdown-list-item__check" type="checkbox" value="<?php echo esc_attr($active_codes[0]); ?>">
                                <span><?php echo esc_html($prop_types[$active_codes[0]] ?? $active_codes[0]); ?></span>
                            </label>
                        <?php else: ?>
                            <div class="nex-dropdown-group rnlp-dropdown-group">
                                <label class="nex-dropdown-group-title rnlp-dropdown-group-title">
                                    <input class="nex-dropdown-group-title__check" type="checkbox" value="<?php echo esc_attr(implode(',', $active_codes)); ?>">
                                    <span><?php echo $group_label; ?></span>
                                    <span class="nex-dropdown-arrow rnlp-dropdown-arrow">›</span>
                                </label>
                                <div class="nex-dropdown-group-items rnlp-dropdown-sub">
                                    <?php foreach ($active_codes as $code): ?>
                                    <label class="rnlp-dropdown-item nex-dropdown-list-item">
                                        <input class="nex-dropdown-list-item__check" type="checkbox" value="<?php echo esc_attr($code); ?>">
                                        <span><?php echo esc_html($prop_types[$code] ?? $code); ?></span>
                                    </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; // show_type_filter ?>

            <!-- Availability checkboxes -->
            <?php if ($lp_show_avail_filter): ?>
            <div class="rnlp-avail-checks" id="nex-avail-checks">
                <label class="rnlp-check-label">
                    <input type="checkbox" class="rnlp-avail-check nex-input-value" value="For_Lease" checked>
                    <span class="rnlp-check-box"></span>
                    <span class="rnlp-check-icon rnlp-icon-lease"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"/><path d="M21 2l-9.6 9.6"/><path d="M15.5 7.5l3 3L22 7l-3-3"/></svg></span>
                    For Lease
                </label>
                <label class="rnlp-check-label">
                    <input type="checkbox" class="rnlp-avail-check nex-input-value" value="For_Sale" checked>
                    <span class="rnlp-check-box"></span>
                    <span class="rnlp-check-icon rnlp-icon-sale"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v12"/><path d="M9.5 9.5c0-1.1.9-2 2-2h1.5a2 2 0 0 1 0 4H12a2 2 0 0 0 0 4h1.5a2 2 0 0 0 1.9-1.4"/></svg></span>
                    For Sale
                </label>
                <label class="rnlp-check-label">
                    <input type="checkbox" class="rnlp-avail-check nex-input-value" value="SOLD">
                    <span class="rnlp-check-box"></span>
                    <span class="rnlp-check-icon rnlp-icon-sold"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg></span>
                    Sold
                </label>
            </div>
            <?php endif; // show_avail_filter ?>

            <!-- More filters -->
            <button class="rnlp-btn rnlp-btn-outline" id="nex-advanced-btn" type="button">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="14" height="14"><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75"/></svg>
                More filters
            </button>
            <button class="rnlp-btn rnlp-btn-ghost" id="nex-reset-btn" type="button">Reset</button>
        </div>

        <!-- Advanced panel -->
        <div id="nex-advanced-container" class="rnlp-advanced-panel nex-advanced-container" style="display:none">
            <?php
            $Price = $BuildingSf = $AvailableSpace = [];
            foreach ($response as $val) {
                $Price[]          = $val['ListPrice'] ? intval($val['ListPrice']) : 0;
                $BuildingSf[]     = $val['BuildingSf'] ? $val['BuildingSf'] : 0;
                $space_values     = [];
                $space_min        = function_exists('rnlp_parse_area_value') ? rnlp_parse_area_value($val['SpaceAvailMin'] ?? 0) : (float)($val['SpaceAvailMin'] ?? 0);
                $space_max        = function_exists('rnlp_parse_area_value') ? rnlp_parse_area_value($val['SpaceAvailMax'] ?? 0) : (float)($val['SpaceAvailMax'] ?? 0);
                if ($space_min > 0) $space_values[] = $space_min;
                if ($space_max > 0) $space_values[] = $space_max;
                foreach ((array)($val['Space'] ?? $val['Spaces'] ?? []) as $space) {
                    $space_value = $space['SpaceAvailable']
                        ?? $space['space_available']
                        ?? $space['AvailSf']
                        ?? $space['AvailableSf']
                        ?? $space['SpaceAvailSf']
                        ?? 0;
                    $space_value = function_exists('rnlp_parse_area_value') ? rnlp_parse_area_value($space_value) : (float)$space_value;
                    if ($space_value > 0) $space_values[] = $space_value;
                }
                $AvailableSpace[] = $space_values ? max($space_values) : 0;
            }
            ?>
            <div class="rnlp-advanced-inner">
                <?php if (max($AvailableSpace) > 0): ?>
                <div class="rnlp-range-group">
                    <label>Space available (SF)</label>
                    <div class="rnlp-range-inputs">
                        <input type="number" id="building-available-space-min" class="rnlp-input nex-input-value type--numer" placeholder="Min">
                        <span>—</span>
                        <input type="number" id="building-available-space-max" class="rnlp-input nex-input-value type--numer" placeholder="Max">
                    </div>
                </div>
                <?php endif; ?>
                <?php if (max($BuildingSf) > 0): ?>
                <div class="rnlp-range-group">
                    <label>Building size (SF)</label>
                    <div class="rnlp-range-inputs">
                        <input type="number" id="building-size-min" class="rnlp-input nex-input-value type--numer" placeholder="Min">
                        <span>—</span>
                        <input type="number" id="building-size-max" class="rnlp-input nex-input-value type--numer" placeholder="Max">
                    </div>
                </div>
                <?php endif; ?>
                <?php if (max($Price) > 0): ?>
                <div class="rnlp-range-group">
                    <label>Price ($)</label>
                    <div class="rnlp-range-inputs">
                        <input type="number" id="building-price-min" class="rnlp-input nex-input-value type--numer" placeholder="Min">
                        <span>—</span>
                        <input type="number" id="building-price-max" class="rnlp-input nex-input-value type--numer" placeholder="Max">
                    </div>
                </div>
                <?php endif; ?>
                <button class="rnlp-btn rnlp-btn-primary" id="nex-advanced-filters-apply-btn" type="button">Apply filters</button>
            </div>
        </div>
    </div>

    <!-- ── Results bar ────────────────────────────────────────────────── -->
    <div class="rnlp-results-bar">
        <?php if ($lp_show_results_count): ?>
        <span class="rnlp-results-count" id="rnlp-results-count"><?php echo $total_records; ?> listings</span>
        <?php else: ?>
        <span id="rnlp-results-count" style="display:none"></span>
        <?php endif; ?>
        <div class="rnlp-results-right">
            <?php if ($lp_show_sort): ?>
            <select class="rnlp-sort-select" id="rnlp-sort">
                <option value="default">Sort: Default</option>
                <option value="price-desc">Sort: Price (high)</option>
                <option value="price-asc">Sort: Price (low)</option>
                <option value="size-desc">Sort: Largest building</option>
                <option value="size-asc">Sort: Smallest building</option>
            </select>
            <?php else: ?>
            <select id="rnlp-sort" style="display:none"><option value="default">Default</option></select>
            <?php endif; ?>
            <?php if ($lp_show_map): ?>
            <button class="rnlp-map-toggle" id="rnlp-map-toggle" type="button">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="13" height="13"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg>
                Show map
            </button>
            <?php else: ?>
            <button id="rnlp-map-toggle" style="display:none" type="button"></button>
            <?php endif; ?>
            <?php if ($lp_show_list_toggle): ?>
            <div class="rnlp-view-btns">
                <button class="rnlp-vb<?php echo $lp_default_view === 'grid' ? ' active' : ''; ?>" id="rnlp-grid-view" title="Grid" type="button">
                    <svg viewBox="0 0 16 16" fill="currentColor"><rect x="1" y="1" width="6" height="6" rx="1"/><rect x="9" y="1" width="6" height="6" rx="1"/><rect x="1" y="9" width="6" height="6" rx="1"/><rect x="9" y="9" width="6" height="6" rx="1"/></svg>
                </button>
                <button class="rnlp-vb<?php echo $lp_default_view === 'list' ? ' active' : ''; ?>" id="rnlp-list-view" title="List" type="button">
                    <svg viewBox="0 0 16 16" fill="currentColor"><rect x="1" y="2" width="14" height="3" rx="1"/><rect x="1" y="7" width="14" height="3" rx="1"/><rect x="1" y="12" width="14" height="3" rx="1"/></svg>
                </button>
            </div>
            <?php else: ?>
            <div style="display:none"><button id="rnlp-grid-view" type="button"></button><button id="rnlp-list-view" type="button"></button></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ── Map panel (collapsible) ───────────────────────────────────── -->
    <?php if ($lp_show_map): ?>
    <div class="rnlp-map-panel" id="rnlp-map-panel">
        <img id="marker"
            data-color="<?php echo esc_attr($primary_color); ?>"
            class="d-none"
            data-src="<?php echo esc_url($marker_path); ?>"
            data-src-sold="<?php echo esc_url($sold_marker_path); ?>"
            src="<?php echo esc_url($marker_path); ?>">
        <div id="map" class="rnlp-map map"></div>
    </div>
    <?php else: ?>
    <div id="rnlp-map-panel" style="display:none"><div id="map"></div></div>
    <?php endif; // show_map ?>

    <!-- ── Card grid ─────────────────────────────────────────────────── -->
    <div class="rnlp-grid rnlp-grid-mode rnlp-grid-cols-<?php echo esc_attr($lp_grid_cols); ?> nex-items-container" id="nex-items-container">
        <?php
        $i = 0;
        foreach ($response as $val):
            $photos  = function_exists('rnlp_photo_attachments') ? rnlp_photo_attachments($val) : (array)($val['Attachments'] ?? []);

            $img_url = '';
            if (!empty($val['Attachments']) && is_array($val['Attachments'])) {
                foreach ($val['Attachments'] as $att) {
                    if ((($att['AttachmentType'] ?? '') === 'photo') && !empty($att['FileName'])) {
                        $img_url = $att['FileName'];
                        break;
                    }
                }
                if (empty($img_url) && !empty($val['Attachments'][0]['FileName'])) {
                    $img_url = $val['Attachments'][0]['FileName'];
                }
            }
            if (empty($img_url) && !empty($photos[0]['FileName'])) {
                $img_url = $photos[0]['FileName'];
            }
            $img_src = $img_url
                ? (function_exists('rnlp_attachment_image_url')
                    ? rnlp_attachment_image_url($img_url, 'h=500&mode=max&404=default&autorotate=true')
                    : $img_url . '?h=500&mode=max&404=default&autorotate=true')
                : plugin_dir_url(__FILE__) . 'img/no-image.png';

            $prop_id = function_exists('rnlp_listing_id') ? rnlp_listing_id($val) : sanitize_text_field($val['Id'] ?? '');
            $card_dom_id = 'rnlp-listing-' . sanitize_html_class($prop_id ?: (string)($i + 1));

            $is_sold  = strtoupper($val['Status']) === 'SOLD';
            $badge    = $is_sold ? 'SOLD' : $val['ListingType'];

            $price    = '';
            if ($val['PriceDisclosed'] && $val['ListPrice']) {
                $price = '$' . number_format(intval($val['ListPrice']), 0, '.', ',');
                if ($val['ListingType'] === 'For Lease' && $val['PriceUnits']) {
                    $price .= ' / SF ' . strtoupper($val['PriceUnits']);
                }
            }

            $prop_url = function_exists('rnlp_property_detail_url')
                ? rnlp_property_detail_url($val)
                : home_url('/property/') . sanitize_title($val['PropertyName']) . '/?listing_id=' . rawurlencode($prop_id);

            $type_names = [];
            foreach ($val['PropertyTypes'] as $ptype) {
                $type_names[] = $prop_types[$ptype] ?? $ptype;
            }

            $bldg_sf  = function_exists('rnlp_format_area_sf') ? rnlp_format_area_sf($val['BuildingSf'] ?? 0) : (!empty($val['BuildingSf']) ? number_format($val['BuildingSf'], 0, '.', ',') . ' SF' : '');
            $avail_sf = function_exists('rnlp_available_sf_display') ? rnlp_available_sf_display($val) : '';
            $lot_size = function_exists('rnlp_lot_size_display') ? rnlp_lot_size_display($val) : (!empty($val['LandSize']) ? $val['LandSize'] . ' ' . ($val['LandSizeType'] ?? 'AC') : '');

            $i++;
            $_badge_slug  = strtolower(str_replace(' ', '-', $badge));
            $_badge_icons = [
                'for-sale'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v12"/><path d="M9.5 9.5c0-1.1.9-2 2-2h1.5a2 2 0 0 1 0 4H12a2 2 0 0 0 0 4h1.5a2 2 0 0 0 1.9-1.4"/></svg>',
                'for-lease' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="5.5"/><path d="M21 2l-9.6 9.6"/><path d="M15.5 7.5l3 3L22 7l-3-3"/></svg>',
                'sold'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>',
                'wanted'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>',
                'leased'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 11V6a2 2 0 0 0-2-2 2 2 0 0 0-2 2v0"/><path d="M14 10V4a2 2 0 0 0-2-2 2 2 0 0 0-2 2v10"/><path d="M10 10.5a2 2 0 0 0-2-2 2 2 0 0 0-2 2V17a6 6 0 0 0 6 6 6 6 0 0 0 6-6v-5a2 2 0 0 0-2-2 2 2 0 0 0-2 2"/></svg>',
            ];
        ?>
        <article
            id="<?php echo esc_attr($card_dom_id); ?>"
            class="rnlp-card nex-item card"
            data-index="<?php echo $i; ?>"
            data-listing-id="<?php echo esc_attr($prop_id); ?>"
            data-price="<?php echo esc_attr($val['ListPrice'] ?? 0); ?>"
            data-bldgsf="<?php echo esc_attr($val['BuildingSf'] ?? 0); ?>">

            <a href="<?php echo esc_url($prop_url); ?>" class="rnlp-card-link card-link" aria-label="View <?php echo esc_attr($val['PropertyName']); ?>"></a>

            <div class="rnlp-card-img">
                <img
                    src="<?php echo esc_url( rnlp_first_photo_url( $val ) ); ?>"
                    class="rnlp-img nex-item-img"
                    alt="<?php echo esc_attr($val['PropertyName']); ?>"
                    loading="lazy">

                <span class="rnlp-badge rnlp-badge--<?php echo esc_attr($_badge_slug); ?> type">
                    <?php echo $_badge_icons[$_badge_slug] ?? ''; ?>
                    <?php echo esc_html($badge); ?>
                </span>

                <?php if ($price): ?>
                <span class="rnlp-price-tag price"><?php echo esc_html($price); ?></span>
                <?php endif; ?>
            </div>

            <div class="rnlp-card-body">
                <div class="rnlp-card-name name description">
                    <?php echo esc_html(ucwords(strtolower($val['PropertyName']))); ?>
                </div>
                <div class="rnlp-card-addr span-p">
                    <?php echo esc_html($val['Street'] . ', ' . $val['City'] . ', ' . $val['State'] . ' ' . $val['Zip']); ?>
                </div>
                <?php if ($type_names): ?>
                <div class="rnlp-card-pills">
                    <?php foreach (array_slice($type_names, 0, 3) as $t): ?>
                    <span class="rnlp-pill"><?php echo esc_html($t); ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if ($bldg_sf || $avail_sf || $lot_size): ?>
                <div class="rnlp-card-stats">
                    <?php if ($bldg_sf): ?>
                    <div class="rnlp-stat">
                        <span class="rnlp-stat-label">Building SF</span>
                        <span class="rnlp-stat-val"><?php echo esc_html($bldg_sf); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($avail_sf): ?>
                    <div class="rnlp-stat">
                        <span class="rnlp-stat-label">Available SF</span>
                        <span class="rnlp-stat-val"><?php echo esc_html($avail_sf); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($lot_size): ?>
                    <div class="rnlp-stat">
                        <span class="rnlp-stat-label">Lot Size</span>
                        <span class="rnlp-stat-val"><?php echo esc_html($lot_size); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <?php if ($show_inquire): ?>
            <div class="rnlp-card-inquire">
                <button
                    class="rnlp-inquire-btn"
                    data-prop-name="<?php echo esc_attr(ucwords(strtolower($val['PropertyName'])) . ' — ' . $val['Street'] . ', ' . $val['City']); ?>"
                    data-prop-id="<?php echo esc_attr($prop_id); ?>"
                    type="button">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="13" height="13"><path stroke-linecap="round" stroke-linejoin="round" d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    Inquire
                </button>
            </div>
            <?php endif; ?>
        </article>
        <?php endforeach; ?>
    </div>

    <!-- ── Pagination ─────────────────────────────────────────────────── -->
    <div class="rnlp-pagination" id="rnlp-pagination">
        <button class="rnlp-page-btn" id="rnlp-prev" disabled type="button">
            <svg fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="14" height="14"><path stroke-linecap="round" stroke-linejoin="round" d="M15 18l-6-6 6-6"/></svg>
            Prev
        </button>
        <div class="rnlp-page-numbers" id="rnlp-page-numbers"></div>
        <button class="rnlp-page-btn" id="rnlp-next" type="button">
            Next
            <svg fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="14" height="14"><path stroke-linecap="round" stroke-linejoin="round" d="M9 18l6-6-6-6"/></svg>
        </button>
    </div>

    <a class="rnlp-branding branding" target="_blank" href="https://www.realnex.com/commercial-real-estate-software/services">
        <img decoding="async" alt="Powered by RealNex" src="<?php echo esc_url(plugin_dir_url(__FILE__)); ?>img/mp-premier-realnex.webp">
    </a>

    <?php if ($dev_mode): ?>
    <details class="rnlp-dev-dump"><summary>Raw API response</summary><pre><?php var_dump($response); ?></pre></details>
    <?php endif; ?>
</div>

<script>
(function(){
    var ITEMS_PER_PAGE = <?php echo (int)$items_per_page; ?>;
    var currentPage   = 1;

    var container = document.getElementById('nex-items-container');
    var prevBtn   = document.getElementById('rnlp-prev');
    var nextBtn   = document.getElementById('rnlp-next');
    var pageNums  = document.getElementById('rnlp-page-numbers');
    var countEl   = document.getElementById('rnlp-results-count');
    var mapToggle = document.getElementById('rnlp-map-toggle');
    var mapPanel  = document.getElementById('rnlp-map-panel');
    var sortSel   = document.getElementById('rnlp-sort');
    var gridBtn   = document.getElementById('rnlp-grid-view');
    var listBtn   = document.getElementById('rnlp-list-view');

    // ── Map toggle ──────────────────────────────────────────────────────
    var mapOpen = false;
    mapToggle.addEventListener('click', function(){
        mapOpen = !mapOpen;
        mapPanel.classList.toggle('rnlp-map-open', mapOpen);
        mapToggle.classList.toggle('rnlp-map-toggle--active', mapOpen);
        mapToggle.querySelector('span') && (mapToggle.querySelector('span').textContent = mapOpen ? 'Hide map' : 'Show map');
        // Re-build text node — toggle button has text node + svg
        mapToggle.childNodes.forEach(function(n){
            if(n.nodeType === 3) n.textContent = mapOpen ? ' Hide map' : ' Show map';
        });
    });

    // ── Sort ────────────────────────────────────────────────────────────
    sortSel.addEventListener('change', function(){
        const cards = Array.from(container.querySelectorAll('.rnlp-card'));
        const val   = this.value;
        cards.sort(function(a, b){
            const ap = parseFloat(a.dataset.price)  || 0;
            const bp = parseFloat(b.dataset.price)  || 0;
            const as = parseFloat(a.dataset.bldgsf) || 0;
            const bs = parseFloat(b.dataset.bldgsf) || 0;
            if(val === 'price-desc') return bp - ap;
            if(val === 'price-asc')  return ap - bp;
            if(val === 'size-desc')  return bs - as;
            if(val === 'size-asc')   return as - bs;
            return parseInt(a.dataset.index) - parseInt(b.dataset.index);
        });
        cards.forEach(function(c){ container.appendChild(c); });
        currentPage = 1;
        renderPage();
    });

    // ── View toggle ─────────────────────────────────────────────────────
    gridBtn.addEventListener('click', function(){
        container.classList.remove('rnlp-list-mode');
        container.classList.add('rnlp-grid-mode');
        gridBtn.classList.add('active');
        listBtn.classList.remove('active');
    });
    listBtn.addEventListener('click', function(){
        container.classList.remove('rnlp-grid-mode');
        container.classList.add('rnlp-list-mode');
        listBtn.classList.add('active');
        gridBtn.classList.remove('active');
    });

    // ── Pagination ──────────────────────────────────────────────────────
    function getVisible(){
        return Array.from(container.querySelectorAll('.rnlp-card')).filter(function(c){
            // Check inline style AND computed style (catches both rnlp-paged-out CSS class
            // and filter-hidden cards set via style.display = 'none')
            return c.style.display !== 'none' && !c.classList.contains('rnlp-paged-out');
        });
    }

    function renderPage(){
        const cards      = getVisible();
        const total      = cards.length;
        const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));
        if(currentPage > totalPages) currentPage = totalPages;
        const start = (currentPage - 1) * ITEMS_PER_PAGE;
        const end   = start + ITEMS_PER_PAGE;

        cards.forEach(function(c, i){
            c.classList.toggle('rnlp-paged-out', !(i >= start && i < end));
        });

        if(countEl) countEl.textContent = total + ' listing' + (total !== 1 ? 's' : '');
        prevBtn.disabled = currentPage <= 1;
        nextBtn.disabled = currentPage >= totalPages;

        pageNums.innerHTML = '';
        buildRange(currentPage, totalPages).forEach(function(p){
            if(p === '…'){
                var s = document.createElement('span');
                s.className = 'rnlp-page-ellipsis';
                s.textContent = '…';
                pageNums.appendChild(s);
            } else {
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'rnlp-page-num' + (p === currentPage ? ' active' : '');
                b.textContent = p;
                b.addEventListener('click', function(){ currentPage = p; renderPage(); scrollTop(); });
                pageNums.appendChild(b);
            }
        });

        document.getElementById('rnlp-pagination').style.display = totalPages <= 1 ? 'none' : 'flex';
    }

    function buildRange(cur, total){
        if(total <= 7) return Array.from({length:total}, function(_,i){ return i+1; });
        var r = [1];
        if(cur > 3) r.push('…');
        for(let i = Math.max(2, cur-1); i <= Math.min(total-1, cur+1); i++) r.push(i);
        if(cur < total-2) r.push('…');
        r.push(total);
        return r;
    }

    function scrollTop(){
        var el = document.getElementById('rnlp-wrapper');
        if(el) el.scrollIntoView({behavior:'smooth', block:'start'});
    }

    prevBtn.addEventListener('click', function(){ if(currentPage>1){ currentPage--; renderPage(); scrollTop(); } });
    nextBtn.addEventListener('click', function(){
        var tp = Math.ceil(getVisible().length / ITEMS_PER_PAGE);
        if(currentPage<tp){ currentPage++; renderPage(); scrollTop(); }
    });

    // Observe style changes — filter-events-handler.js sets style.display on cards.
    // Debounce to avoid rapid re-renders when many cards change at once.
    var _filterTimer;
    var obs = new MutationObserver(function(){
        clearTimeout(_filterTimer);
        _filterTimer = setTimeout(function(){ currentPage = 1; renderPage(); }, 50);
    });
    obs.observe(container, {childList:false, attributes:true, subtree:true, attributeFilter:['style']});

    // Lazy-load images
    if('IntersectionObserver' in window){
        var io = new IntersectionObserver(function(entries){
            entries.forEach(function(e){
                if(e.isIntersecting){
                    var img = e.target;
                    if(img.dataset.src){ img.src = img.dataset.src; delete img.dataset.src; }
                    io.unobserve(img);
                }
            });
        }, {rootMargin:'200px'});
        document.querySelectorAll('.rnlp-img[data-src]').forEach(function(img){ io.observe(img); });
    }

    // Dropdown toggle
    var typeBtn  = document.querySelector('.rnlp-type-trigger');
    var typeMenu = document.querySelector('.rnlp-type-dropdown');

    if (typeBtn && typeMenu) {
        typeBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            var isOpen = typeMenu.classList.contains('open');
            typeMenu.classList.toggle('open');
            typeMenu.style.display = isOpen ? 'none' : 'block';
        });

        // Close on ANY click outside
        document.addEventListener('click', function(e) {
            if (!typeBtn.contains(e.target) && !typeMenu.contains(e.target)) {
                typeMenu.classList.remove('open');
                typeMenu.style.display = 'none';
            }
        });

        // Close on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                typeMenu.classList.remove('open');
                typeMenu.style.display = 'none';
            }
        });
    }

    // Init — apply default view from settings
    var defaultView = '<?php echo esc_js($lp_default_view); ?>';
    if (defaultView === 'list') {
        container.classList.remove('rnlp-grid-mode');
        container.classList.add('rnlp-list-mode');
        if (listBtn) { listBtn.classList.add('active'); gridBtn && gridBtn.classList.remove('active'); }
    } else {
        container.classList.add('rnlp-grid-mode');
    }
    // Expose renderPage for filter-events-handler.js to call after filtering
    window.rnlpRenderPage = renderPage;

    renderPage();
})();
</script>
