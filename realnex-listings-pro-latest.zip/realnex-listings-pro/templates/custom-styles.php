<?php
if (!defined("ABSPATH")) exit;
$dev_mode    = isset(get_option('api_settings')['select_devMode_field'])
    ? (get_option('api_settings')['select_devMode_field'] == 'yes')
    : false;

$mbg_color     = isset($mbg_color)     ? $mbg_color     : 'rgb(226 228 228 / 25%)';
$fbg_color     = isset($fbg_color)     ? $fbg_color     : '#fff';
$primary_color = get_option('api_settings')['custom_color']  ?? '#013161';
$icons_color   = get_option('api_settings')['icons_color']   ?? '#013161';
$font_color    = get_option('api_settings')['font_color']    ?? '#ffffff';
$prel_one      = hex2rgba($primary_color, 1);

$_api_opts        = get_option('api_settings', []);
$_rnlp_root_file  = dirname( dirname( __FILE__ ) ) . '/RealNexListingsPro.php';
$marker_path      = !empty($_api_opts['marker_id'])      ? $_api_opts['marker_id']      : plugins_url('assets/images/marker-active.svg', $_rnlp_root_file);
$sold_marker_path = !empty($_api_opts['sold_marker_id']) ? $_api_opts['sold_marker_id'] : plugins_url('assets/images/marker-sold.svg',   $_rnlp_root_file);

$mapType     = get_option('api_settings')['select_mapType_field']     ?? 'googlemap';
$mapPosition = get_option('api_settings')['select_mapPosition_field'] ?? 'left';
$showBtn     = get_option('api_settings')['select_btnRight_field']    ?? 'no';

$classPosition = ($mapPosition == 'left') ? 'flex-row-reverse' : 'flex-row';

// Single property background image
$img_path = '';
if (isset($pr_source['attachments'])) {
    $img_url = [];
    foreach ($pr_source['attachments'] as $att) {
        if ($att['attachment_type'] == 'photo') {
            $img_url[] = $att['file_name'];
        }
    }
    $img_path = !empty($img_url) ? $img_url[0] : plugin_dir_url(__FILE__) . 'img/no-image.png';
}
?>
<style>
    .rnlp-wrapper { --rnlp-accent: <?php echo esc_attr($primary_color); ?>; }
    .mbg-color  { background-color: <?php echo esc_attr($mbg_color); ?> !important; }
    .cbg-color  { background-color: <?php echo esc_attr($primary_color); ?> !important; color: <?php echo esc_attr($font_color); ?> !important; }
    .fbg-color  { background-color: <?php echo esc_attr($fbg_color); ?> !important; }
    .rnlp-accent-bar { background: <?php echo esc_attr($primary_color); ?> !important; }
    .rnlp-badge { background: <?php echo esc_attr($primary_color); ?> !important; }
    .rnlp-page-num.active { background: <?php echo esc_attr($primary_color); ?> !important; color: #fff !important; }
    a.social { border: 1px solid <?php echo esc_attr($icons_color); ?> !important; }
    a.social:hover { background-color: <?php echo esc_attr($icons_color); ?> !important; }
    a.social:hover svg { fill: #fff !important; }
    <?php if ($img_path): ?>
    .single_prop_bg {
        background: linear-gradient(rgba(255,255,255,.95), rgba(255,255,255,.95)), url('<?php echo esc_url($img_path); ?>');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
    }
    <?php endif; ?>
</style>
