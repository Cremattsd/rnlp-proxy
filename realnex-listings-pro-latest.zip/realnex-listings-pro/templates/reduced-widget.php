<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Price Reduced Properties Widget
 * Shortcode: [property-reduced]
 * $listings — array of listing objects (set by rnlp_reduced_shortcode)
 */

include_once(dirname(__FILE__) . '/inc/prop-types.php');

$show_inquire  = get_option('api_settings', [])['rnlp_show_inquire'] ?? '';

// Filter listings by name containing PRICE / REDUCED / SPECIAL / SALE (case-insensitive)
$rnlp_reduced_keywords = ['PRICE', 'REDUCED', 'SPECIAL', 'SALE'];
$filtered_listings = [];
foreach ((array) $listings as $_l) {
    $_name_upper = strtoupper((string) ($_l['PropertyName'] ?? ''));
    foreach ($rnlp_reduced_keywords as $_kw) {
        if ($_name_upper !== '' && strpos($_name_upper, $_kw) !== false) {
            $filtered_listings[] = $_l;
            break;
        }
    }
}

if (empty($filtered_listings)) {
    echo '<p class="rnlp-no-results">No price reduced listings at this time. <a href="/listings/">View all listings &rarr;</a></p>';
    return;
}
?>
<div class="rnlp-widget rnlp-widget--reduced" aria-label="Price Reduced Listings">
    <div class="rnlp-widget-scroll">
        <?php foreach (array_slice($filtered_listings, 0, 6) as $val):
            $img_src = isset($val['Attachments'][0]['FileName'])
                ? $val['Attachments'][0]['FileName'] . '?h=400&mode=max&404=default&autorotate=true'
                : plugin_dir_url(__FILE__) . 'img/no-image.png';

            $is_sold    = strtoupper($val['Status'] ?? '') === 'SOLD';
            $badge      = $is_sold ? 'SOLD' : ($val['ListingType'] ?? '');
            $badge_slug = strtolower(str_replace(' ', '-', $badge));

            $price = '';
            if (!empty($val['PriceDisclosed']) && !empty($val['ListPrice'])) {
                $price = '$' . number_format((int) $val['ListPrice'], 0, '.', ',');
                if (($val['ListingType'] ?? '') === 'For Lease' && !empty($val['PriceUnits'])) {
                    $price .= ' / SF ' . strtoupper($val['PriceUnits']);
                }
            }

            $prop_id  = function_exists('rnlp_listing_id') ? rnlp_listing_id($val) : sanitize_text_field($val['Id'] ?? '');
            $prop_url = function_exists('rnlp_property_detail_url')
                ? rnlp_property_detail_url($val)
                : home_url('/property/') . sanitize_title($val['PropertyName'] ?? '') . '/?listing_id=' . rawurlencode($prop_id);
        ?>
        <article class="rnlp-widget-card rnlp-widget-card--reduced">
            <a href="<?php echo esc_url($prop_url); ?>" class="rnlp-widget-card-link" aria-label="View <?php echo esc_attr($val['PropertyName'] ?? ''); ?>"></a>
            <div class="rnlp-widget-img">
                <img src="<?php echo esc_url($img_src); ?>"
                     alt="<?php echo esc_attr($val['PropertyName'] ?? ''); ?>"
                     loading="lazy">
                <!-- Price Reduced diagonal ribbon -->
                <div class="rnlp-ribbon">Price Reduced</div>
                <?php if ($badge): ?>
                <span class="rnlp-badge rnlp-badge--<?php echo esc_attr($badge_slug); ?>">
                    <?php echo esc_html($badge); ?>
                </span>
                <?php endif; ?>
                <?php if ($price): ?>
                <span class="rnlp-price-tag"><?php echo esc_html($price); ?></span>
                <?php endif; ?>
            </div>
            <div class="rnlp-widget-body">
                <div class="rnlp-widget-name"><?php echo esc_html(ucwords(strtolower($val['PropertyName'] ?? ''))); ?></div>
                <div class="rnlp-widget-addr"><?php echo esc_html(($val['Street'] ?? '') . ', ' . ($val['City'] ?? '') . ', ' . ($val['State'] ?? '')); ?></div>
                <?php if ($show_inquire): ?>
                <button class="rnlp-inquire-btn"
                    data-prop-name="<?php echo esc_attr(ucwords(strtolower($val['PropertyName'] ?? '')) . ' — ' . ($val['Street'] ?? '') . ', ' . ($val['City'] ?? '')); ?>"
                    data-prop-id="<?php echo esc_attr($prop_id); ?>"
                    type="button">Inquire</button>
                <?php endif; ?>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
</div>
