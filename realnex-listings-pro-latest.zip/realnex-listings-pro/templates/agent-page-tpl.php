<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Agent / Broker Page Template
 * Rendered by the [broker] shortcode when "Show agent roster" is enabled in Settings > Agents.
 *
 * Expects:
 *   $response       — array of property listing objects from the proxy
 *   $active_theme   — CSS theme slug (set in broker-shortcode / listing template)
 */

$settings     = get_option('api_settings', []);
$show_agents  = !empty($settings['rnlp_show_agents']);
$agent_style  = $settings['rnlp_agent_style'] ?? 'card';
$active_theme = $settings['rnlp_theme'] ?? 'classic';

if (!$show_agents) return;

// Build unique agent list from the listings response
$agents = [];
foreach ((array) $response as $listing) {
    $agent_id = $listing['AgentId'] ?? $listing['agentId'] ?? null;
    if (!$agent_id || isset($agents[$agent_id])) continue;

    $name  = trim(($listing['AgentFirstName'] ?? '') . ' ' . ($listing['AgentLastName'] ?? ''));
    $email = $listing['AgentEmail'] ?? '';
    $phone = $listing['AgentPhone'] ?? '';
    $title = $listing['AgentTitle'] ?? 'Agent';

    $agents[$agent_id] = [
        'id'            => $agent_id,
        'name'          => $name ?: 'Agent',
        'initials'      => rnlp_agent_initials($name),
        'title'         => $title,
        'phone'         => $phone ? formatPhoneNumber($phone) : '',
        'email'         => $email,
        'listing_count' => 0,
    ];
}

// Count listings per agent
foreach ((array) $response as $listing) {
    $agent_id = $listing['AgentId'] ?? $listing['agentId'] ?? null;
    if ($agent_id && isset($agents[$agent_id])) {
        $agents[$agent_id]['listing_count']++;
    }
}

if (empty($agents)) return;

$style_class = 'rnlp-agents--' . esc_attr($agent_style);
?>
<div class="rnlp-wrapper rnlp-theme-<?php echo esc_attr($active_theme); ?>">
    <div class="rnlp-agents <?php echo $style_class; ?>">
        <?php foreach ($agents as $agent): ?>
        <div class="rnlp-agent-card" data-agent-id="<?php echo esc_attr($agent['id']); ?>">

            <!-- Avatar — initials fallback -->
            <div class="rnlp-agent-avatar" aria-hidden="true">
                <?php echo esc_html($agent['initials']); ?>
            </div>

            <div class="rnlp-agent-info">
                <div class="rnlp-agent-name"><?php echo esc_html($agent['name']); ?></div>
                <div class="rnlp-agent-title"><?php echo esc_html($agent['title']); ?></div>

                <?php if ($agent['phone']): ?>
                <a class="rnlp-agent-contact" href="tel:<?php echo esc_attr(preg_replace('/\D/', '', $agent['phone'])); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="13" height="13"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.59 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                    <?php echo esc_html($agent['phone']); ?>
                </a>
                <?php endif; ?>

                <?php if ($agent['email']): ?>
                <a class="rnlp-agent-contact" href="mailto:<?php echo esc_attr($agent['email']); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="13" height="13"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                    <?php echo esc_html($agent['email']); ?>
                </a>
                <?php endif; ?>

                <div class="rnlp-agent-count"><?php echo (int) $agent['listing_count']; ?> listing<?php echo $agent['listing_count'] !== 1 ? 's' : ''; ?></div>
            </div>

            <!-- Filter the main grid to this agent -->
            <button class="rnlp-agent-filter-btn"
                data-agent-id="<?php echo esc_attr($agent['id']); ?>"
                type="button">
                View listings
            </button>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
.rnlp-agents { display: flex; flex-wrap: wrap; gap: 16px; margin: 20px 0; }
.rnlp-agent-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    padding: 20px 16px 16px;
    background: var(--rnlp-card-bg, #fff);
    border: 1px solid var(--rnlp-border, #e2e8f0);
    border-radius: 10px;
    box-shadow: var(--rnlp-shadow, 0 1px 4px rgba(0,0,0,.06));
    text-align: center;
    width: 200px;
    flex-shrink: 0;
    position: relative;
}
.rnlp-agents--list .rnlp-agent-card {
    flex-direction: row;
    width: 100%;
    text-align: left;
    align-items: center;
}
.rnlp-agents--minimal .rnlp-agent-card {
    padding: 10px 12px;
    flex-direction: row;
    width: 100%;
    border: none;
    border-bottom: 1px solid var(--rnlp-border, #e2e8f0);
    border-radius: 0;
    box-shadow: none;
}
.rnlp-agent-avatar {
    width: 56px; height: 56px;
    border-radius: 50%;
    background: var(--rnlp-accent, #013161);
    color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: 20px; font-weight: 700;
    flex-shrink: 0;
}
.rnlp-agent-name { font-weight: 600; font-size: 14px; color: var(--rnlp-card-text, #0f172a); }
.rnlp-agent-title { font-size: 12px; color: var(--rnlp-meta-text, #64748b); margin-top: 2px; }
.rnlp-agent-contact {
    display: flex; align-items: center; gap: 5px;
    font-size: 12px; color: var(--rnlp-meta-text, #64748b);
    text-decoration: none; margin-top: 4px;
}
.rnlp-agent-contact:hover { color: var(--rnlp-accent, #013161); }
.rnlp-agent-count { font-size: 11px; color: var(--rnlp-meta-text, #94a3b8); margin-top: 4px; }
.rnlp-agent-filter-btn {
    margin-top: 8px;
    padding: 6px 14px;
    font-size: 12px; font-weight: 500;
    border: 1px solid var(--rnlp-accent, #013161);
    border-radius: 20px;
    background: transparent;
    color: var(--rnlp-accent, #013161);
    cursor: pointer;
    transition: background .15s, color .15s;
}
.rnlp-agent-filter-btn:hover {
    background: var(--rnlp-accent, #013161);
    color: #fff;
}
@media (max-width: 680px) {
    .rnlp-agents { flex-direction: column; }
    .rnlp-agent-card { width: 100%; }
}
</style>

<script>
(function(){
    document.querySelectorAll('.rnlp-agent-filter-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var agentId = this.dataset.agentId;
            // Filter the main grid if it exists on this page
            var cards = document.querySelectorAll('#nex-items-container .rnlp-card');
            if (!cards.length) return;
            cards.forEach(function(card) {
                var match = card.id === agentId || card.dataset.agentId === agentId;
                card.style.display = match ? '' : 'none';
            });
            // Scroll to listings
            var grid = document.getElementById('rnlp-wrapper') || document.getElementById('nex-items-container');
            if (grid) grid.scrollIntoView({behavior: 'smooth', block: 'start'});
        });
    });
})();
</script>
<?php

function rnlp_agent_initials($name) {
    $parts    = array_filter(explode(' ', trim($name)));
    $initials = '';
    foreach (array_slice($parts, 0, 2) as $part) {
        $initials .= strtoupper(mb_substr($part, 0, 1));
    }
    return $initials ?: '?';
}
