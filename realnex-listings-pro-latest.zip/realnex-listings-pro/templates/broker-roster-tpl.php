<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Broker Roster Template
 * $brokers — keyed array of broker data, each with: name, email, phone, initials, listing_count
 */

if (empty($brokers)) return;
?>
<div class="rnlp-roster-wrap">
    <div class="rnlp-roster-grid">
        <?php foreach ($brokers as $broker): ?>
        <div class="rnlp-roster-card"
             role="button"
             tabindex="0"
             data-broker-email="<?php echo esc_attr($broker['email']); ?>"
             data-broker-name="<?php echo esc_attr($broker['name']); ?>">
            <div class="rnlp-roster-avatar"><?php echo esc_html($broker['initials']); ?></div>
            <div class="rnlp-roster-name"><?php echo esc_html($broker['name']); ?></div>
            <?php if ($broker['phone']): ?>
            <a class="rnlp-roster-contact" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $broker['phone'])); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="13" height="13"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"/></svg>
                <?php echo esc_html(formatPhoneNumber($broker['phone'])); ?>
            </a>
            <?php endif; ?>
            <a class="rnlp-roster-contact" href="mailto:<?php echo esc_attr(antispambot($broker['email'])); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="13" height="13"><path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75"/></svg>
                <?php echo esc_html(antispambot($broker['email'])); ?>
            </a>
            <div class="rnlp-roster-count">
                <?php echo esc_html($broker['listing_count']); ?> listing<?php echo $broker['listing_count'] !== 1 ? 's' : ''; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
.rnlp-roster-card {
    cursor: pointer;
    transition: border-color .15s, box-shadow .15s, transform .15s;
}
.rnlp-roster-card:hover,
.rnlp-roster-card:focus {
    border-color: var(--rnlp-accent, #013161);
    box-shadow: var(--rnlp-shadow-hover, 0 4px 16px rgba(0,0,0,.12));
    transform: translateY(-2px);
    outline: none;
}
.rnlp-broker-active-filter {
    align-items: center;
    justify-content: space-between;
    gap: 14px;
    margin: 0 0 16px;
    padding: 14px 16px;
    border: 1px solid var(--rnlp-border, #e2e8f0);
    border-radius: 8px;
    background: var(--rnlp-filter-bg, #f8fafc);
}
.rnlp-broker-active-title {
    margin: 0;
    font-size: 18px;
    font-weight: 700;
    color: var(--rnlp-text, #0f172a);
}
@media (max-width: 680px) {
    .rnlp-broker-active-filter {
        align-items: stretch;
        flex-direction: column;
    }
}
</style>

<script>
(function(){
    function applyBrokerFilter(card) {
        var email = (card.getAttribute('data-broker-email') || '').toLowerCase();
        var name = card.getAttribute('data-broker-name') || '';
        if (!email) return;
        if (window.nexFilterPlugin && window.nexFilterPlugin.setBrokerFilter) {
            window.nexFilterPlugin.setBrokerFilter(email, name);
            var grid = document.getElementById('rnlp-wrapper') || document.getElementById('nex-items-container');
            if (grid) grid.scrollIntoView({behavior: 'smooth', block: 'start'});
        }
    }

    document.querySelectorAll('.rnlp-roster-card[data-broker-email]').forEach(function(card) {
        card.addEventListener('click', function(e) {
            if (e.target.closest('a')) return;
            applyBrokerFilter(card);
        });
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                applyBrokerFilter(card);
            }
        });
    });
})();
</script>
