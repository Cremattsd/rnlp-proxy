<?php
if (!defined("ABSPATH")) exit;

$property_id = isset($_GET['prop-id']) ? $_GET['prop-id'] : false;

// ── Company listing via proxy ─────────────────────────────────────────────
if (!$property_id) {
    // Property type filter from shortcode
    $types = (isset($atts['types']) && !is_null($atts['types']))
        ? explode(',', $atts['types'])
        : '';

    // Availability filter from shortcode
    if (isset($atts['avail']) && !is_null($atts['avail'])) {
        $avail       = explode(',', $atts['avail']);
        $mergedArray = [];

        foreach ($avail as $a) {
            $result = rnlp_listings_request([
                'startIndex'    => 0,
                'NoOfRecords'   => 10000,
                'SortBy'        => 'updated',
                'SortHow'       => 'asc',
                'AgentIDs'      => false,
                'PropertyTypes' => $types,
                'SearchType'    => $a,
            ]);
            if (is_array($result[0] ?? null)) {
                $mergedArray = array_merge($mergedArray, $result[0]);
            }
        }
        $response = $mergedArray;
    } else {
        $result   = rnlp_listings_request([
            'startIndex'    => 0,
            'NoOfRecords'   => 10000,
            'SortBy'        => 'updated',
            'SortHow'       => 'asc',
            'AgentIDs'      => false,
            'PropertyTypes' => $types,
            'SearchType'    => '',
        ]);
        $response = $result[0] ?? [];
    }

    $total_records = count($response);
}

// ── Single property ───────────────────────────────────────────────────────
if ($property_id) {
    $data_property  = json_encode(['PropertyId' => $property_id]);
    $PropertyDetail = api_request_single($data_property);
    $PropertyDetail = json_decode($PropertyDetail['PropertyDetail'], true);
    $pr_source      = $PropertyDetail['hits']['hits'][0]['_source'];
}

// ── SEO: JSON-LD + hidden static render for crawlers ─────────────────────
if (!$property_id && !empty($response)) {
    $first      = $response[0];
    $fu         = (array)($first['UserList'] ?? []);
    $fu         = $fu[0] ?? [];
    $comp_city  = esc_attr($first['City']  ?? '');
    $comp_state = esc_attr($first['State'] ?? '');
    $comp_phone = esc_attr($fu['Phone'] ?? '');
    echo '<script type="application/ld+json">' . wp_json_encode([
        '@context'  => 'https://schema.org',
        '@type'     => 'RealEstateAgent',
        'name'      => get_bloginfo('name'),
        'url'       => home_url(),
        'telephone' => $comp_phone,
        'address'   => [
            '@type'           => 'PostalAddress',
            'addressLocality' => $first['City']  ?? '',
            'addressRegion'   => $first['State'] ?? '',
        ],
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";

    echo '<div id="rnlp-seo-listings" style="display:none" aria-hidden="true">' . "\n";
    foreach (array_slice($response, 0, 9) as $l) {
        $l_url   = home_url('/property/' . sanitize_title($l['PropertyName'] ?? '') . '/?id=' . rawurlencode($l['Id'] ?? ''));
        $l_addr  = esc_html(implode(', ', array_filter([$l['Street'] ?? '', $l['City'] ?? '', $l['State'] ?? ''])));
        $l_price = !empty($l['ListPrice']) ? esc_html(number_format((int)$l['ListPrice'], 0, '.', ',')) : '';
        echo '<article itemscope itemtype="https://schema.org/RealEstateListing">' . "\n";
        echo '  <h3 itemprop="name">' . esc_html($l['PropertyName'] ?? '') . '</h3>' . "\n";
        echo '  <p itemprop="description">' . $l_addr . '</p>' . "\n";
        if ($l_price) echo '  <span itemprop="price">' . $l_price . '</span>' . "\n";
        echo '  <a href="' . esc_url($l_url) . '" itemprop="url">View Property</a>' . "\n";
        echo '</article>' . "\n";
    }
    echo '</div>' . "\n";
}

// ── Render ────────────────────────────────────────────────────────────────
if ($property_id) {
    include_once('single-property-tpl.php');
} else {
    if (isset($total_records) && $total_records > 0) {
        include_once('listing-tpl.php');
    } else {
        echo '<h4>No listings found. Check your serial number in Settings &rarr; License &amp; Setup.</h4>';
    }
}

