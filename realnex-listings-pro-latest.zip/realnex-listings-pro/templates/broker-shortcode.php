<?php
if (!defined("ABSPATH")) exit;

function broker_shortcode($atts) { 
      
    // return $atts['id'];
    if($atts){

        ob_start();
        require('broker-listing.php');
        return ob_get_clean();

    }elseif( get_option('api_settings')['brokerId_field'] ){

        $atts = array( 'id' => get_option('api_settings')['brokerId_field'] );
        ob_start();
        require('broker-listing.php');
        return ob_get_clean(); 
        
    }elseif( isset($_GET['prop-id']) ){

        ob_start();
        require('broker-listing.php');
        return ob_get_clean(); 
        
    } else {
        // No broker ID specified — build a roster from all company listings
        $serial = get_option('api_settings', [])['rnlp_serial'] ?? '';
        if (empty($serial)) return '<h4>No serial configured.</h4>';

        $result       = rnlp_listings_request([
            'startIndex'  => 0,
            'NoOfRecords' => 10000,
            'SortBy'      => 'updated',
            'SortHow'     => 'asc',
            'SearchType'  => '',
        ]);
        $all_listings = $result[0] ?? [];

        // Extract unique brokers and count their listings
        $brokers = [];
        foreach ($all_listings as $listing) {
            $users = [];
            if (!empty($listing['User']) && is_array($listing['User'])) {
                $users[] = $listing['User'];
            }
            foreach ((array)($listing['UserList'] ?? []) as $u) {
                if (is_array($u)) {
                    $users[] = $u;
                }
            }
            $seen_in_listing = [];
            foreach ($users as $u) {
                $email = strtolower(sanitize_email($u['Email'] ?? ''));
                if (!$email || in_array($email, $seen_in_listing, true)) continue;
                $seen_in_listing[] = $email;
                if (!isset($brokers[$email])) {
                    $brokers[$email] = [
                        'name'          => trim(($u['FirstName'] ?? '') . ' ' . ($u['LastName'] ?? '')),
                        'email'         => $email,
                        'phone'         => $u['Phone'] ?? '',
                        'initials'      => strtoupper(substr($u['FirstName'] ?? 'B', 0, 1) . substr($u['LastName'] ?? 'R', 0, 1)),
                        'listing_count' => 0,
                    ];
                }
                $brokers[$email]['listing_count']++;
            }
        }

        if (empty($brokers)) return '<h4>No brokers found.</h4>';

        ob_start();
        require('broker-roster-tpl.php');
        return ob_get_clean();
    }

}
add_shortcode('broker', 'broker_shortcode');
