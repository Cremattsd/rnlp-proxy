<?php
if (!defined("ABSPATH")) exit;

$property_id = isset($_GET['prop-id']) ? $_GET['prop-id'] : false;

// broker_id URL param overrides shortcode atts (links from property detail page)
if ( ! $property_id && isset( $_GET['broker_id'] ) && $_GET['broker_id'] !== '' ) {
    $atts['id'] = sanitize_text_field( wp_unslash( $_GET['broker_id'] ) );
}

// ── Broker listing via proxy ──────────────────────────────────────────────
if (!$property_id && isset($atts['id'])) {
    $AgentIDs = explode(',', $atts['id']);

    // Property type filter
    $types = (isset($atts['types']) && !is_null($atts['types']))
        ? explode(',', $atts['types'])
        : '';

    // Availability filter
    if (isset($atts['avail']) && !is_null($atts['avail'])) {
        $avail       = explode(',', $atts['avail']);
        $mergedArray = [];

        foreach ($avail as $a) {
            $result = rnlp_listings_request([
                'startIndex'    => 0,
                'NoOfRecords'   => 10000,
                'SortBy'        => 'updated',
                'SortHow'       => 'asc',
                'AgentIDs'      => $AgentIDs,
                'PropertyTypes' => $types,
                'SearchType'    => $a,
            ]);
            if (is_array($result[0] ?? null)) {
                $mergedArray = array_merge($mergedArray, $result[0]);
            }
        }
        $response = $mergedArray;
    } else {
        $result   = rnlp_listings_request([
            'startIndex'    => 0,
            'NoOfRecords'   => 10000,
            'SortBy'        => 'updated',
            'SortHow'       => 'asc',
            'AgentIDs'      => $AgentIDs,
            'PropertyTypes' => $types,
            'SearchType'    => '',
        ]);
        $response = $result[0] ?? [];
    }

    $total_records = count($response);
}

// ── Single property ───────────────────────────────────────────────────────
if ($property_id) {
    $data_property  = json_encode(['PropertyId' => $property_id]);
    $PropertyDetail = api_request_single($data_property);
    $Property       = $PropertyDetail;
    $PropertyDetail = json_decode($PropertyDetail['PropertyDetail'], true);
    $pr_source      = $PropertyDetail['hits']['hits'][0]['_source'];
}

// ── Render ────────────────────────────────────────────────────────────────
if ($property_id) {
    include_once('single-property-tpl.php');
} else {
    if (isset($total_records) && $total_records > 0) {
        include_once('listing-tpl.php');
    } else {
        echo '<h4>No listings found. Check your serial number or broker ID.</h4>';
    }
}

