<?php
/**
 * RealNex Listings Pro — CRM Lead Capture
 *
 * Data model flow (per RealNex SyncAPI v1):
 *   1. Create Contact   POST /api/v1/Crm/contact
 *   2. Find Projects    GET  /api/v1/CrmOData/Properties?$filter=key eq {id}&$expand=projects
 *                       Fallback: GET /api/v1/CrmOData/Projects?$filter=contains(notes,'{id}')
 *   3. Add Lead         POST /api/v1/Crm/project/{projectKey}/lead
 *   4. Create History   POST /api/v1/Crm/history  → link via POST /api/v1/Crm/history/{key}/object
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_rnlp_submit_lead',        'rnlp_submit_lead');
add_action('wp_ajax_nopriv_rnlp_submit_lead', 'rnlp_submit_lead');

function rnlp_submit_lead() {

    // ── Security ──────────────────────────────────────────────────────────
    if (!check_ajax_referer('rnlp_lead_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => 'Security check failed.'], 403);
    }

    // ── Settings ──────────────────────────────────────────────────────────
    $settings      = get_option('api_settings', []);
    $crm_host      = isset($settings['rnlp_crm_host'])  ? rtrim(sanitize_text_field($settings['rnlp_crm_host']), '/') : '';
    $jwt_token     = $settings['rnlp_jwt_token'] ?? '';
    $crm_connected = !empty($crm_host) && !empty($jwt_token);

    // ── Sanitize inputs ───────────────────────────────────────────────────
    $full_name    = sanitize_text_field($_POST['rnlp_name']        ?? '');
    $email        = sanitize_email($_POST['rnlp_email']            ?? '');
    $phone        = sanitize_text_field($_POST['rnlp_phone']       ?? '');
    $message      = sanitize_textarea_field($_POST['rnlp_message'] ?? '');
    $property     = sanitize_text_field($_POST['rnlp_property']    ?? '');   // display name
    $property_id  = sanitize_text_field($_POST['rnlp_prop_id']     ?? '');   // RealNex property GUID

    // Broker email — passed from the inquiry button's data-broker-email attribute
    $broker_email = sanitize_email($_POST['broker_email'] ?? '');
    if (empty($broker_email)) {
        $broker_email = sanitize_email($settings['rnlp_notify_email'] ?? '');
    }
    if (empty($broker_email)) {
        $broker_email = get_option('admin_email', '');
    }

    if (empty($full_name) || empty($email)) {
        wp_send_json_error(['message' => 'Name and email are required.'], 400);
    }
    if (!is_email($email)) {
        wp_send_json_error(['message' => 'Please enter a valid email address.'], 400);
    }

    $parts      = explode(' ', $full_name, 2);
    $first_name = $parts[0];
    $last_name  = $parts[1] ?? '';

    $contact_key     = null;
    $projects_linked = [];
    $linked_count    = 0;
    $contact_created = false;
    $project_found   = false;

    if ($crm_connected):

    $headers = [
        'Content-Type'        => 'application/json',
        'Authorization'       => 'Bearer ' . $jwt_token,
        'Crm-ApplicationName' => 'RealNexListingsPro',
    ];

    // ── STEP 1: Find or create Contact ────────────────────────────────────

    // Search by email first to avoid duplicates
    $email_filter = urlencode("email eq '{$email}'");
    $search_resp = rnlp_api_get(
        $crm_host . '/api/v1/CrmOData/Contacts?$filter=' . $email_filter . '&$top=1',
        $headers
    );
    if (!is_wp_error($search_resp) && $search_resp['code'] === 200) {
        $found = $search_resp['body']['value'] ?? [];
        if (!empty($found)) {
            $contact_key = $found[0]['key'] ?? $found[0]['Key'] ?? null;
        }
    }

    // Create if not found
    if (!$contact_key) {
        $contact_resp = rnlp_api_post($crm_host . '/api/v1/Crm/contact', $headers, [
            'firstName' => $first_name,
            'lastName'  => $last_name,
            'email'     => $email,
            'mobile'    => $phone,
            'prospect'  => true,
        ]);

        if (!is_wp_error($contact_resp) && $contact_resp['code'] >= 200 && $contact_resp['code'] <= 202) {
            $contact_key     = $contact_resp['body']['key'] ?? null;
            $contact_created = true;
        }
    }

    // ── STEP 2: Find Project(s) linked to this Property ───────────────────

    if (!empty($property_id)) {
        $filter_enc = urlencode("listingId eq {$property_id}");
        $pp_resp    = rnlp_api_get(
            $crm_host . '/api/v1/CrmOData/Properties?$filter=' . $filter_enc . '&$expand=projects',
            $headers
        );

        if (!is_wp_error($pp_resp) && $pp_resp['code'] === 200) {
            foreach (($pp_resp['body']['value'] ?? []) as $prop) {
                foreach (($prop['projects'] ?? $prop['Projects'] ?? []) as $proj) {
                    $pk = $proj['key'] ?? $proj['Key'] ?? null;
                    if ($pk && !in_array($pk, $projects_linked, true)) {
                        $projects_linked[] = $pk;
                    }
                }
            }
        }

        // Fallback: search Projects by notes
        if (empty($projects_linked)) {
            $fb_enc  = urlencode("contains(notes,'{$property_id}')");
            $fb_resp = rnlp_api_get(
                $crm_host . '/api/v1/CrmOData/Projects?$filter=' . $fb_enc,
                $headers
            );

            if (!is_wp_error($fb_resp) && $fb_resp['code'] === 200) {
                foreach (($fb_resp['body']['value'] ?? []) as $proj) {
                    $pk = $proj['key'] ?? $proj['Key'] ?? null;
                    if ($pk && !in_array($pk, $projects_linked, true)) {
                        $projects_linked[] = $pk;
                    }
                }
            }
        }
    }

    $project_found = !empty($projects_linked);

    // ── STEP 3: Add Contact as Lead to each Project ───────────────────────
    if ($contact_key && !empty($projects_linked)) {
        foreach ($projects_linked as $proj_key) {
            $pc_resp = rnlp_api_post(
                $crm_host . '/api/v1/Crm/project/' . rawurlencode($proj_key) . '/lead',
                $headers,
                [
                    'contactKey' => $contact_key,
                    'notes'      => 'Web lead from property inquiry',
                ]
            );
            if (!is_wp_error($pc_resp) && $pc_resp['code'] >= 200 && $pc_resp['code'] <= 202) {
                $linked_count++;
            }
        }
    }

    // ── STEP 4: Create History on the Contact ────────────────────────────
    // Creates the audit trail, then links it to the contact object.
    if ($contact_key) {
        $date_label = wp_date('F j, Y \a\t g:i A');
        $referrer   = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : get_bloginfo('url');

        $history_notes  = "Lead submitted via website inquiry form.\n\n";
        $history_notes .= "Date: {$date_label}\n";
        $history_notes .= "Source page: {$referrer}\n";
        if ($property)    $history_notes .= "Property: {$property}\n";
        if ($property_id) $history_notes .= "Property ID: {$property_id}\n";
        if ($linked_count) {
            $history_notes .= "Auto-linked to {$linked_count} project(s) associated with this property.\n";
        } else {
            $history_notes .= "No projects found for this property — contact added without project link.\n";
        }
        if ($message) {
            $history_notes .= "\nMessage from contact:\n{$message}";
        }

        $now = wp_date('Y-m-d\TH:i:s');

        $hist_resp = rnlp_api_post($crm_host . '/api/v1/Crm/history', $headers, [
            'subject'      => 'Web Lead — ' . ($property ?: 'Property Inquiry'),
            'notes'        => $history_notes,
            'startDate'    => $now,
            'endDate'      => $now,
            'timeless'     => false,
            'eventTypeKey' => 1,
            'published'    => true,
        ]);

        if (!is_wp_error($hist_resp) && $hist_resp['code'] >= 200 && $hist_resp['code'] <= 202) {
            $history_key = $hist_resp['body']['key'] ?? null;
            if ($history_key) {
                // Link history to contact
                rnlp_api_post(
                    $crm_host . '/api/v1/Crm/history/' . rawurlencode($history_key) . '/object',
                    $headers,
                    ['objectKey' => $contact_key, 'objectType' => 'contact']
                );
                // Link history to each project
                foreach ($projects_linked as $proj_key) {
                    rnlp_api_post(
                        $crm_host . '/api/v1/Crm/history/' . rawurlencode($history_key) . '/object',
                        $headers,
                        ['objectKey' => $proj_key, 'objectType' => 'project']
                    );
                }
            }
        }
        // Non-fatal — contact + project link are the critical calls
    }

    endif; // $crm_connected

    // ── Email notification to broker ──────────────────────────────────────
    $admin_url_crm = admin_url('admin.php?page=rnlp-filter_settings&tab=crm');
    if (!$crm_connected) {
        $crm_notice   = 'not_connected';
        $crm_message  = 'Lead received. Connect RealNex CRM to auto-track leads.';
        $crm_link     = $admin_url_crm;
        $email_body   = "You have a new listing inquiry:\n\n"
                      . "Name: {$full_name}\nEmail: {$email}\nPhone: {$phone}\n"
                      . "Property: {$property}\nMessage: {$message}\n\n"
                      . "⚠️ CRM not connected — lead not auto-tracked.\n"
                      . "Connect CRM: {$admin_url_crm}";
    } elseif (!$project_found) {
        $crm_notice   = 'no_project';
        $crm_message  = 'Contact ' . ($contact_created ? 'created' : 'found') . ' in CRM. No project linked to this listing.';
        $crm_link     = rtrim($crm_host, '/') . '/projects/new';
        $email_body   = "You have a new listing inquiry:\n\n"
                      . "Name: {$full_name}\nEmail: {$email}\nPhone: {$phone}\n"
                      . "Property: {$property}\nMessage: {$message}\n\n"
                      . "⚠️ No project was found linked to this listing in RealNex.\n\n"
                      . "To auto-track future leads:\n"
                      . "1. Open RealNex CRM\n"
                      . "2. Find the property: {$property}\n"
                      . "3. Create or link a project to it\n"
                      . "Future leads will auto-attach.\n\n"
                      . "Contact " . ($contact_created ? "created" : "found") . " in CRM: {$full_name} / {$email}";
    } else {
        $crm_notice   = 'success';
        $crm_message  = 'Lead auto-created in RealNex CRM and linked to project.';
        $crm_link     = '';
        $email_body   = "You have a new listing inquiry:\n\n"
                      . "Name: {$full_name}\nEmail: {$email}\nPhone: {$phone}\n"
                      . "Property: {$property}\nMessage: {$message}\n\n"
                      . "✅ Contact and history auto-created in RealNex CRM.\n"
                      . "Linked to {$linked_count} project(s).";
    }

    $email_subj = 'New Inquiry — ' . ($property ?: 'Property Inquiry');
    wp_mail($broker_email, $email_subj, $email_body);

    wp_send_json_success([
        'message'      => 'Thank you! Your inquiry has been submitted.',
        'crm_notice'   => $crm_notice,
        'crm_message'  => $crm_message,
        'crm_link'     => $crm_link,
        'contact_key'  => $contact_key,
        'projects'     => $projects_linked,
        'linked_count' => $linked_count,
    ]);
}

// ── Helpers ───────────────────────────────────────────────────────────────

function rnlp_api_post($url, $headers, $payload) {
    $resp = wp_remote_post($url, [
        'headers' => $headers,
        'body'    => wp_json_encode($payload),
        'timeout' => 20,
    ]);
    if (is_wp_error($resp)) return $resp;
    return [
        'code' => wp_remote_retrieve_response_code($resp),
        'body' => json_decode(wp_remote_retrieve_body($resp), true),
    ];
}

function rnlp_api_get($url, $headers) {
    $resp = wp_remote_get($url, [
        'headers' => $headers,
        'timeout' => 15,
    ]);
    if (is_wp_error($resp)) return $resp;
    return [
        'code' => wp_remote_retrieve_response_code($resp),
        'body' => json_decode(wp_remote_retrieve_body($resp), true),
    ];
}

// ── Enqueue lead form assets ──────────────────────────────────────────────
add_action('wp_enqueue_scripts', 'rnlp_lead_assets');

function rnlp_lead_assets() {
    $settings = get_option('api_settings', []);
    $detail_behavior = $settings['detail_behavior'] ?? 'popup';
    if (empty($settings['rnlp_show_inquire']) && !is_page('single-property') && $detail_behavior !== 'popup') return;

    wp_enqueue_style('rnlp-lead-css',  plugin_dir_url(__FILE__) . 'assets/css/rnlp-lead.css', [], date('Ymd'));
    wp_enqueue_script('rnlp-lead-js',  plugin_dir_url(__FILE__) . 'js/rnlp-lead.js', ['jquery'], date('Ymd'), true);
    wp_localize_script('rnlp-lead-js', 'rnlpLead', [
        'ajaxurl'         => admin_url('admin-ajax.php'),
        'nonce'           => wp_create_nonce('rnlp_lead_nonce'),
        'default_project' => '',
    ]);
}
