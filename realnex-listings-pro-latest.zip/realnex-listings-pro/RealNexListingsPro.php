<?php
/*
 *   ░█▀▀░█▀▄░█▀▀░█▄█░█▀█░▀█▀░▀█▀░█▀▀░█▀▄
 *   ░█░░░█▀▄░█▀▀░█░█░█▀█░░█░░░█░░▀▀█░█░█
 *   ░▀▀▀░▀░▀░▀▀▀░▀░▀░▀░▀░░▀░░░▀░░▀▀▀░▀▀░
 *
 *   RealNex Listings Pro · MP Premier 2.0
 *   M. Crematti · Initial3 Development
 *   github.com/Cremattsd
 */

/*
Plugin Name: RealNex Listings Pro
Plugin URI: https://initial3development.com/realnex-listings-pro
Description: Professional commercial real estate listing pages for WordPress, powered by RealNex. Display listings, capture leads, and connect directly to RealNex CRM.
Version: 3.6.0
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Author: Initial3 Development
Author URI: https://initial3development.com
Author Email: m@cremattsd.com
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: realnex-listings-pro
Domain Path: /languages
*/

if (!defined('ABSPATH')) exit;

if (!defined('RNLP_VERSION')) {
    define('RNLP_VERSION', '3.6.0');
}

class RealNexListingsPro {

    private string $slug    = 'rnlp-filter';
    private string $version = RNLP_VERSION;

    public function __construct() {
        add_filter('the_content',         'do_shortcode');
        add_action('init',                [$this, 'load_textdomain']);
        add_action('init',                [$this, 'register_rewrite_rules']);
        add_action('init',                [$this, 'runtime_checks']);
        add_action('admin_menu',          [$this, 'register_menu'], 25);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_styles']);
        add_action('admin_post_rnlp_activate_serial', [$this, 'handle_serial_activation']);
        add_action('admin_notices',       [$this, 'security_admin_notices']);
        add_filter('query_vars',          [$this, 'register_query_vars']);
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_plugin_update']);
        add_filter('plugins_api',         [$this, 'plugin_update_info'], 10, 3);
        add_action('template_redirect',   [$this, 'maybe_serve_sitemap']);
        add_action('wp_head',             [$this, 'output_meta_tags'], 5);
        register_activation_hook(__FILE__, [$this, 'on_activation']);
        // Update hook — set defaults without wiping existing options
        add_action('upgrader_process_complete', [$this, 'on_plugin_update'], 10, 2);

        // Always load plugin functionality — serial is validated separately
        // in settings.php when the serial field is saved.
        require_once __DIR__ . '/functions.php';
        require_once __DIR__ . '/lead-capture.php';
        require_once __DIR__ . '/settings.php';
        require_once __DIR__ . '/templates/single-property-shortcode.php';
        require_once __DIR__ . '/templates/property-widget-shortcode.php';
        require_once __DIR__ . '/templates/company-shortcode.php';
        require_once __DIR__ . '/templates/broker-shortcode.php';
    }

    // ── Private update checker ───────────────────────────────────────────

    private function update_api_url(string $endpoint): string {
        if (function_exists('rnlp_api_url')) {
            return rnlp_api_url($endpoint);
        }

        return 'https://api.initial3development.com/' . ltrim($endpoint, '/');
    }

    private function saved_serial(): string {
        return sanitize_text_field(get_option('api_settings', [])['rnlp_serial'] ?? '');
    }

    private function fetch_plugin_update_info(): ?array {
        $version_data = null;
        $version_response = wp_remote_get($this->update_api_url('version'), ['timeout' => 10]);
        if (!is_wp_error($version_response) && wp_remote_retrieve_response_code($version_response) === 200) {
            $decoded = json_decode(wp_remote_retrieve_body($version_response), true);
            if (is_array($decoded)) {
                $version_data = $decoded;
            }
        }

        $info_url = !empty($version_data['plugin_info'])
            ? esc_url_raw($version_data['plugin_info'])
            : $this->update_api_url('plugin-info');

        $response = wp_remote_get($info_url, ['timeout' => 10]);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data) || empty($data['version'])) {
            return null;
        }

        if (!empty($version_data['plugin_version'])) {
            $data['version'] = sanitize_text_field($version_data['plugin_version']);
        }

        return $data;
    }

    public function check_for_plugin_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $data = $this->fetch_plugin_update_info();
        if (!$data || !version_compare((string) $data['version'], RNLP_VERSION, '>')) {
            return $transient;
        }

        $serial = $this->saved_serial();
        if ($serial === '' || empty($data['download_url'])) {
            return $transient;
        }

        $download_url = add_query_arg('serial', rawurlencode($serial), esc_url_raw($data['download_url']));
        $transient->response[plugin_basename(__FILE__)] = (object) [
            'slug'        => 'realnex-listings-pro',
            'plugin'      => plugin_basename(__FILE__),
            'new_version' => sanitize_text_field($data['version']),
            'url'         => esc_url_raw($data['url'] ?? 'https://initial3development.com'),
            'package'     => $download_url,
            'requires'    => sanitize_text_field($data['requires'] ?? '6.0'),
            'tested'      => sanitize_text_field($data['tested'] ?? '6.7'),
        ];

        return $transient;
    }

    public function plugin_update_info($result, string $action, object $args) {
        if ($action !== 'plugin_information' || ($args->slug ?? '') !== 'realnex-listings-pro') {
            return $result;
        }

        $data = $this->fetch_plugin_update_info();
        if (!$data) {
            return $result;
        }

        $download_url = esc_url_raw($data['download_url'] ?? '');
        $serial = $this->saved_serial();
        if ($download_url && $serial !== '') {
            $download_url = add_query_arg('serial', rawurlencode($serial), $download_url);
        }

        return (object) [
            'name'          => 'RealNex Listings Pro',
            'slug'          => 'realnex-listings-pro',
            'version'       => sanitize_text_field($data['version']),
            'author'        => '<a href="https://initial3development.com">Initial3 Development</a>',
            'homepage'      => esc_url_raw($data['url'] ?? 'https://initial3development.com'),
            'requires'      => sanitize_text_field($data['requires'] ?? '6.0'),
            'tested'        => sanitize_text_field($data['tested'] ?? '6.7'),
            'last_updated'  => sanitize_text_field($data['last_updated'] ?? ''),
            'download_link' => $download_url,
            'sections'      => [
                'description' => 'Professional commercial real estate listing pages for WordPress, powered by RealNex.',
                'changelog'   => sanitize_textarea_field($data['changelog'] ?? 'See release notes from Initial3 Development.'),
            ],
        ];
    }

    // ── Activation ────────────────────────────────────────────────────────

    public function on_activation(): void {
        $this->register_rewrite_rules();
        flush_rewrite_rules();
        $this->ensure_single_property_page();
        // Fresh install only — add_option does nothing if the option exists
        add_option('api_settings', []);
        add_option('rnlp_serial_meta', []);
        add_option('rnlp_serial_status', '');
    }

    public function on_plugin_update( $upgrader, array $hook_extra ): void {
        if (
            ( $hook_extra['action'] ?? '' ) !== 'update' ||
            ( $hook_extra['type']   ?? '' ) !== 'plugin'
        ) {
            return;
        }
        $plugins = $hook_extra['plugins'] ?? [];
        if ( ! in_array( plugin_basename( __FILE__ ), $plugins, true ) ) {
            return;
        }
        // Defaults only — add_option never overwrites an existing value
        add_option( 'api_settings', [] );
        add_option( 'rnlp_serial_meta', [] );
        add_option( 'rnlp_serial_status', '' );
        $this->register_rewrite_rules();
        flush_rewrite_rules();
    }

    // ── Rewrite rules ─────────────────────────────────────────────────────

    public function register_rewrite_rules(): void {
        add_rewrite_rule(
            '^property/([^/]+)/?$',
            'index.php?pagename=single-property&rnlp_property_slug=$matches[1]',
            'top'
        );
        add_rewrite_rule('^rnlp-sitemap\.xml$', 'index.php?rnlp_sitemap=1', 'top');
    }

    public function register_query_vars( array $vars ): array {
        $vars[] = 'id';
        $vars[] = 'listing_id';
        $vars[] = 'listing';
        $vars[] = 'property_id';
        $vars[] = 'rnlp_property_slug';
        $vars[] = 'rnlp_sitemap';
        return $vars;
    }

    // ── Sitemap ───────────────────────────────────────────────────────────

    public function maybe_serve_sitemap(): void {
        if ( ! get_query_var('rnlp_sitemap') ) return;

        $serial   = get_option('api_settings', [])['rnlp_serial'] ?? '';
        $listings = $serial ? rnlp_proxy_request('/listings', [
            'serial'  => $serial,
            'filters' => ['startIndex' => 0, 'NoOfRecords' => 1000, 'SortBy' => 'updated'],
        ]) : null;

        header('Content-Type: application/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        if ( $listings && isset($listings[0]) ) {
            foreach ( $listings[0] as $l ) {
                $url  = function_exists('rnlp_property_detail_url')
                    ? rnlp_property_detail_url($l)
                    : home_url('/property/' . sanitize_title($l['PropertyName'] ?? '') . '/?listing_id=' . rawurlencode($l['Id'] ?? ''));
                $date = date('Y-m-d', strtotime($l['Updated'] ?? 'now') ?: time());
                echo '<url>'
                   . '<loc>' . esc_url($url) . '</loc>'
                   . '<lastmod>' . esc_html($date) . '</lastmod>'
                   . '<changefreq>weekly</changefreq>'
                   . '<priority>0.8</priority>'
                   . '</url>' . "\n";
            }
        }

        echo '</urlset>';
        exit;
    }

    // ── Meta tags ─────────────────────────────────────────────────────────

    public function output_meta_tags(): void {
        $prop_id = function_exists('rnlp_current_listing_id') ? rnlp_current_listing_id() : get_query_var('id', '');

        if ( ! empty($prop_id) ) {
            // Single property page
            $cache_key = 'rnlp_meta_' . md5($prop_id);
            $meta      = get_transient($cache_key);

            if ( false === $meta ) {
                $serial = get_option('api_settings', [])['rnlp_serial'] ?? '';
                $meta   = [];
                if ( $serial && function_exists('rnlp_proxy_request') ) {
                    $resp = rnlp_proxy_request('/property', [
                        'serial'      => $serial,
                        'property_id' => $prop_id,
                    ]);
                    if ( $resp && ! empty($resp['property']) ) {
                        $p = $resp['property'];
                        $img = '';
                        foreach ( (array)($p['Attachments'] ?? []) as $att ) {
                            if ( ($att['AttachmentType'] ?? '') === 'photo' && ! empty($att['FileName']) ) {
                                $img = $att['FileName'] . '?h=800&mode=max';
                                break;
                            }
                        }
                        $meta = [
                            'name'  => $p['PropertyName'] ?? '',
                            'type'  => $p['ListingType']  ?? '',
                            'city'  => $p['City']         ?? '',
                            'state' => $p['State']        ?? '',
                            'sf'    => $p['BuildingSf']   ?? '',
                            'price' => ( ! empty($p['PriceDisclosed']) && ! empty($p['ListPrice']) )
                                        ? '$' . number_format((int)$p['ListPrice'], 0, '.', ',') : '',
                            'image' => $img,
                        ];
                        set_transient($cache_key, $meta, HOUR_IN_SECONDS);
                    }
                }
            }

            if ( ! empty($meta) ) {
                $desc_parts = array_filter([
                    $meta['name'],
                    $meta['type'] ? '— ' . $meta['type'] : '',
                    ( $meta['city'] && $meta['state'] ) ? 'in ' . $meta['city'] . ', ' . $meta['state'] : '',
                    $meta['sf'] ? number_format((int)$meta['sf'], 0) . ' SF' : '',
                    $meta['price'],
                ]);
                $desc = implode(' ', $desc_parts);
                echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
                echo '<meta property="og:title" content="' . esc_attr($meta['name'] . ' — ' . $meta['city'] . ', ' . $meta['state']) . '">' . "\n";
                if ( $meta['image'] ) {
                    echo '<meta property="og:image" content="' . esc_url($meta['image']) . '">' . "\n";
                }
                echo '<meta property="og:type" content="website">' . "\n";
            }
        } elseif ( is_page() ) {
            // Check if page has [company] or [property-featured] shortcode
            global $post;
            if ( $post && has_shortcode($post->post_content, 'company') ) {
                $name = get_bloginfo('name');
                echo '<meta name="description" content="Browse commercial real estate listings — office, industrial, retail and land available for lease and sale. ' . esc_attr($name) . '">' . "\n";
                echo '<meta property="og:title" content="Property Listings — ' . esc_attr($name) . '">' . "\n";
                echo '<meta property="og:description" content="Browse commercial real estate listings available for lease and sale.">' . "\n";
                echo '<meta property="og:type" content="website">' . "\n";
            }
        }
    }

    // ── Auto-create single-property page ──────────────────────────────────

    private function ensure_single_property_page(): void {
        $existing = get_page_by_path( 'single-property' );
        if ( $existing ) {
            return;
        }
        wp_insert_post( [
            'post_title'   => 'Single Property',
            'post_name'    => 'single-property',
            'post_content' => '[property]',
            'post_status'  => 'publish',
            'post_type'    => 'page',
        ] );
    }

    // ── Security runtime checks ───────────────────────────────────────────

    public function runtime_checks(): void {
        $settings = get_option('api_settings', []);
        $serial   = $settings['rnlp_serial'] ?? '';
        if (empty($serial)) return;

        // PART 1 — Domain lock
        $registered = get_option('rnlp_registered_domain', '');
        if (!empty($registered) && rtrim($registered, '/') !== rtrim(home_url(), '/')) {
            update_option('rnlp_serial_status', 'domain_mismatch');
            return;
        }

        // PART 2 — Weekly phone-home (fail open on network error)
        $last_check = (int) get_option('rnlp_last_check', 0);
        if ((time() - $last_check) > 604800) {
            $this->phone_home($serial);
        }

        // PART 3 — Anti-tamper file integrity
        $this->check_integrity($serial);
    }

    private function phone_home(string $serial): void {
        if (!function_exists('rnlp_get_api_base')) return;
        $resp = wp_remote_post(rnlp_api_url('validate'), [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode(['serial' => $serial, 'domain' => home_url()]),
            'timeout' => 10,
        ]);
        update_option('rnlp_last_check', time());
        if (is_wp_error($resp)) return; // fail open
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (!empty($body) && isset($body['valid']) && !$body['valid']) {
            update_option('rnlp_serial_status', 'revoked');
            $meta          = get_option('rnlp_serial_meta', []);
            $meta['valid'] = false;
            update_option('rnlp_serial_meta', $meta);
        } else {
            update_option('rnlp_serial_status', 'active');
        }
    }

    private function check_integrity(string $serial): void {
        if (!function_exists('rnlp_get_api_base')) return;
        $files = [
            __DIR__ . '/functions.php',
            __DIR__ . '/lead-capture.php',
            __DIR__ . '/settings.php',
        ];
        $current = [];
        foreach ($files as $f) {
            if (file_exists($f)) {
                $current[basename($f)] = md5_file($f);
            }
        }
        $stored = get_option('rnlp_integrity', []);
        if (empty($stored)) {
            update_option('rnlp_integrity', $current);
            return;
        }
        foreach ($current as $name => $hash) {
            if (isset($stored[$name]) && $stored[$name] !== $hash) {
                wp_remote_post(rnlp_api_url('report'), [
                    'headers'  => ['Content-Type' => 'application/json'],
                    'body'     => wp_json_encode([
                        'serial'    => $serial,
                        'domain'    => home_url(),
                        'event'     => 'tamper_detected',
                        'file'      => $name,
                        'timestamp' => gmdate('c'),
                    ]),
                    'timeout'  => 5,
                    'blocking' => false,
                ]);
                $stored[$name] = $hash;
                update_option('rnlp_integrity', $stored);
            }
        }
    }

    public function security_admin_notices(): void {
        if (!current_user_can('manage_options')) return;
        $status = get_option('rnlp_serial_status', '');
        if ($status === 'revoked') {
            echo '<div class="notice notice-error"><p><strong>RealNex Listings Pro:</strong> Your serial has been revoked — listings will not display. <a href="' . esc_url(admin_url('admin.php?page=' . $this->slug)) . '">Re-activate &rarr;</a></p></div>';
        } elseif ($status === 'domain_mismatch') {
            echo '<div class="notice notice-error"><p><strong>RealNex Listings Pro:</strong> This domain does not match the registered activation domain — listings will not display.</p></div>';
        }
    }

    // ── i18n ──────────────────────────────────────────────────────────────

    public function load_textdomain(): void {
        load_plugin_textdomain(
            'realnex-listings-pro',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }

    // ── Admin styles ──────────────────────────────────────────────────────

    public function enqueue_admin_styles(): void {
        wp_enqueue_style(
            'rnlp-admin-css',
            plugins_url('assets/css/rnlp-admin.css', __FILE__),
            [],
            $this->version
        );
        wp_enqueue_script(
            'rnlp-admin-js',
            plugins_url('js/admin.js', __FILE__),
            ['jquery'],
            $this->version,
            true
        );
    }

    // ── Admin menu ────────────────────────────────────────────────────────

    public function register_menu(): void {
        add_menu_page(
            'RealNex Listings Pro',
            'RealNex Listings Pro',
            'manage_options',
            $this->slug,
            [$this, 'render_setup_or_settings'],
            'dashicons-building',
            25
        );

        add_submenu_page(
            $this->slug,
            'Settings',
            'Settings',
            'manage_options',
            $this->slug . '_settings',
            'settings_page_of_plugin'
        );
    }

    // ── Top-level page: setup screen or redirect to settings ─────────────

    public function render_setup_or_settings(): void {
        $serial = get_option('api_settings', [])['rnlp_serial'] ?? '';
        $meta   = get_option('rnlp_serial_meta', []);

        if (!empty($serial) && !empty($meta['valid'])) {
            // Serial already active — show the full settings page
            settings_page_of_plugin();
            return;
        }

        $this->render_setup_page();
    }

    // ── Setup / activation page ───────────────────────────────────────────

    private function render_setup_page(): void {
        $notice = get_transient('rnlp_activation_notice');
        delete_transient('rnlp_activation_notice');
        ?>
        <div class="wrap rnlp-setup-wrap">

            <!-- Wordmark -->
            <div class="rnlp-setup-brand">
                <span class="dashicons dashicons-building rnlp-setup-icon"></span>
                <span class="rnlp-setup-wordmark">RealNex <strong>Listings Pro</strong></span>
            </div>

            <h1 class="rnlp-setup-heading">Welcome to RealNex Listings Pro</h1>
            <p class="rnlp-setup-sub">Enter your serial number to activate your listing pages and connect to RealNex.</p>

            <?php if ($notice): ?>
            <div class="notice notice-<?php echo esc_attr($notice['type']); ?> rnlp-setup-notice">
                <p><?php echo esc_html($notice['msg']); ?></p>
            </div>
            <?php endif; ?>

            <div class="rnlp-setup-card">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="rnlp_activate_serial">
                    <?php wp_nonce_field('rnlp_activate_serial'); ?>

                    <div class="rnlp-setup-field">
                        <label for="rnlp_serial_input" class="rnlp-setup-label">Serial Number</label>
                        <input
                            type="text"
                            id="rnlp_serial_input"
                            name="rnlp_serial"
                            class="rnlp-setup-input"
                            placeholder="RNLP-XXXX-XXXX-XXXX"
                            value="<?php echo esc_attr(get_option('api_settings', [])['rnlp_serial'] ?? ''); ?>"
                            autocomplete="off"
                            spellcheck="false"
                            required>
                        <span class="rnlp-setup-help">Enter the serial number provided by Initial3 Development</span>
                    </div>

                    <button type="submit" class="rnlp-setup-btn">
                        Activate
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" width="15" height="15"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                    </button>
                </form>
            </div>

            <p class="rnlp-setup-footer">
                <button type="button" class="rnlp-request-toggle" id="rnlpRequestToggle" onclick="document.getElementById('rnlpRequestPanel').style.display=document.getElementById('rnlpRequestPanel').style.display==='none'?'block':'none';this.style.display='none';">
                    Don&rsquo;t have a serial? <span>Request one &rarr;</span>
                </button>
            </p>

            <!-- Inline serial request form -->
            <div class="rnlp-setup-card" id="rnlpRequestPanel" style="display:none;margin-top:16px">
                <h3 class="rnlp-request-title">Request a Serial Key</h3>
                <p class="rnlp-request-sub">Fill in your details and you'll receive your serial within one business day.</p>
                <div id="rnlpRequestSuccess" style="display:none" class="rnlp-request-success">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    Request sent! You'll receive your key within one business day.
                </div>
                <form id="rnlpRequestForm">
                    <div class="rnlp-req-grid">
                        <div class="rnlp-setup-field">
                            <label class="rnlp-setup-label">Full Name <span style="color:#ef4444">*</span></label>
                            <input type="text" id="rnlpReqName" class="rnlp-setup-input" placeholder="Jane Smith" required>
                        </div>
                        <div class="rnlp-setup-field">
                            <label class="rnlp-setup-label">Company / Brokerage <span style="color:#ef4444">*</span></label>
                            <input type="text" id="rnlpReqCompany" class="rnlp-setup-input" placeholder="Acme Commercial RE" required>
                        </div>
                        <div class="rnlp-setup-field">
                            <label class="rnlp-setup-label">Email <span style="color:#ef4444">*</span></label>
                            <input type="email" id="rnlpReqEmail" class="rnlp-setup-input" placeholder="jane@yourfirm.com" required>
                        </div>
                        <div class="rnlp-setup-field">
                            <label class="rnlp-setup-label">Phone</label>
                            <input type="tel" id="rnlpReqPhone" class="rnlp-setup-input" placeholder="(555) 000-0000">
                        </div>
                    </div>
                    <div class="rnlp-setup-field">
                        <label class="rnlp-setup-label">WordPress Site URL</label>
                        <input type="url" id="rnlpReqSite" class="rnlp-setup-input" value="<?php echo esc_attr(site_url()); ?>" readonly style="background:#f8fafc;cursor:default">
                    </div>
                    <button type="submit" class="rnlp-setup-btn" id="rnlpRequestBtn">Request Serial Key</button>
                </form>
            </div>

        </div>

        <style>
        .rnlp-setup-wrap {
            max-width: 520px;
            margin: 48px auto 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        .rnlp-setup-brand {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 28px;
        }
        .rnlp-setup-icon {
            font-size: 32px;
            color: #013161;
        }
        .rnlp-setup-wordmark {
            font-size: 22px;
            color: #0f172a;
            letter-spacing: -.3px;
        }
        .rnlp-setup-wordmark strong {
            color: #013161;
            font-weight: 700;
        }
        .rnlp-setup-heading {
            font-size: 26px;
            font-weight: 700;
            color: #0f172a;
            margin: 0 0 8px;
        }
        .rnlp-setup-sub {
            font-size: 15px;
            color: #64748b;
            margin: 0 0 24px;
        }
        .rnlp-setup-notice {
            margin-bottom: 20px;
        }
        .rnlp-setup-card {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 28px 32px 32px;
            box-shadow: 0 1px 3px rgba(0,0,0,.05), 0 4px 14px rgba(0,0,0,.07);
        }
        .rnlp-setup-field {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 24px;
        }
        .rnlp-setup-label {
            font-size: 13px;
            font-weight: 600;
            color: #374151;
        }
        .rnlp-setup-input {
            height: 44px;
            padding: 0 14px;
            border: 1.5px solid #e2e8f0;
            border-radius: 8px;
            font-size: 15px;
            font-family: 'SF Mono', 'Fira Code', monospace;
            letter-spacing: .04em;
            color: #0f172a;
            outline: none;
            transition: border-color .15s, box-shadow .15s;
            width: 100%;
            box-sizing: border-box;
        }
        .rnlp-setup-input:focus {
            border-color: #013161;
            box-shadow: 0 0 0 3px rgba(1,49,97,.12);
        }
        .rnlp-setup-help {
            font-size: 12px;
            color: #94a3b8;
        }
        .rnlp-setup-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            height: 44px;
            padding: 0 24px;
            background: #013161;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            transition: opacity .15s, transform .15s;
            width: 100%;
            justify-content: center;
        }
        .rnlp-setup-btn:hover {
            opacity: .9;
            transform: translateY(-1px);
        }
        .rnlp-setup-btn:active {
            transform: none;
        }
        .rnlp-setup-footer {
            margin-top: 20px;
            font-size: 13px;
            color: #94a3b8;
            text-align: center;
        }
        .rnlp-setup-footer a {
            color: #013161;
            text-decoration: none;
        }
        .rnlp-setup-footer a:hover {
            text-decoration: underline;
        }
        /* Request serial form */
        .rnlp-request-toggle {
            background: none;
            border: none;
            padding: 0;
            font-size: 13px;
            color: #94a3b8;
            cursor: pointer;
            font-family: inherit;
        }
        .rnlp-request-toggle span {
            color: #013161;
            text-decoration: underline;
        }
        .rnlp-request-toggle:hover span { opacity: .75; }
        .rnlp-request-title {
            font-size: 16px;
            font-weight: 700;
            color: #0f172a;
            margin: 0 0 4px;
        }
        .rnlp-request-sub {
            font-size: 13px;
            color: #64748b;
            margin: 0 0 20px;
        }
        .rnlp-req-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0 16px;
        }
        @media (max-width: 520px) { .rnlp-req-grid { grid-template-columns: 1fr; } }
        .rnlp-request-success {
            display: flex;
            align-items: center;
            gap: 10px;
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 8px;
            padding: 14px 16px;
            font-size: 14px;
            color: #166534;
            margin-bottom: 16px;
        }
        </style>
        <script>
        document.getElementById('rnlpRequestForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var btn  = document.getElementById('rnlpRequestBtn');
            var name    = document.getElementById('rnlpReqName').value.trim();
            var company = document.getElementById('rnlpReqCompany').value.trim();
            var email   = document.getElementById('rnlpReqEmail').value.trim();
            var phone   = document.getElementById('rnlpReqPhone').value.trim();
            var site    = document.getElementById('rnlpReqSite').value.trim();
            if (!name || !company || !email) return;
            btn.disabled = true;
            btn.textContent = 'Sending\u2026';
            fetch('https://api.initial3development.com/lead', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    serial:  'RNLP-MDLG-001',
                    name:    name,
                    email:   email,
                    phone:   phone,
                    message: 'SERIAL KEY REQUEST\nCompany: ' + company + '\nSite: ' + site + '\nEmail: ' + email
                })
            })
            .then(function() {
                document.getElementById('rnlpRequestForm').style.display = 'none';
                document.getElementById('rnlpRequestSuccess').style.display = 'flex';
            })
            .catch(function() {
                btn.disabled = false;
                btn.textContent = 'Request Serial Key';
                alert('Could not send request. Please email msmith@initial3development.com directly.');
            });
        });
        </script>
        <?php
    }

    // ── Handle serial activation form POST ────────────────────────────────

    public function handle_serial_activation(): void {
        check_admin_referer('rnlp_activate_serial');

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized', 403);
        }

        $serial = sanitize_text_field(wp_unslash($_POST['rnlp_serial'] ?? ''));

        if (empty($serial)) {
            set_transient('rnlp_activation_notice', [
                'type' => 'error',
                'msg'  => 'Please enter a serial number.',
            ], 60);
            wp_safe_redirect(admin_url('admin.php?page=' . $this->slug));
            exit;
        }

        // Ping the proxy to validate
        $resp = wp_remote_post(rnlp_api_url('validate'), [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode(['serial' => $serial]),
            'timeout' => 15,
        ]);

        if (is_wp_error($resp)) {
            set_transient('rnlp_activation_notice', [
                'type' => 'error',
                'msg'  => 'Could not reach the activation server. Please check your connection and try again.',
            ], 60);
            wp_safe_redirect(admin_url('admin.php?page=' . $this->slug));
            exit;
        }

        $body = json_decode(wp_remote_retrieve_body($resp), true);

        if (empty($body['valid'])) {
            set_transient('rnlp_activation_notice', [
                'type' => 'error',
                'msg'  => 'Invalid or expired serial number. Contact Initial3 Development if you believe this is an error.',
            ], 60);
            wp_safe_redirect(admin_url('admin.php?page=' . $this->slug));
            exit;
        }

        if (empty($body['plugin_allowed'])) {
            set_transient('rnlp_activation_notice', [
                'type' => 'error',
                'msg'  => 'This serial is for iframe embed access only. Use an MP Premier 2.0 serial to activate the WordPress plugin.',
            ], 60);
            wp_safe_redirect(admin_url('admin.php?page=' . $this->slug));
            exit;
        }

        // Save serial into api_settings
        $settings                = get_option('api_settings', []);
        $settings['rnlp_serial'] = $serial;
        update_option('api_settings', $settings);

        // Store encrypted company_id (function defined in settings.php)
        if (function_exists('rnlp_encrypt')) {
            update_option('rnlp_company_id_enc', rnlp_encrypt($body['company_id'] ?? ''));
        }

        update_option('rnlp_serial_meta', [
            'plan'           => $body['plan'] ?? 'basic',
            'product_type'   => $body['product_type'] ?? '',
            'iframe_allowed' => !empty($body['iframe_allowed']),
            'plugin_allowed' => !empty($body['plugin_allowed']),
            'expires_at'     => $body['expires_at'] ?? '',
            'valid'          => true,
        ]);

        // Domain lock — register this site's URL
        update_option('rnlp_registered_domain', home_url());
        update_option('rnlp_serial_status', 'active');
        update_option('rnlp_last_check', time());

        // Compute initial file integrity hashes
        $integrity_files = [
            __DIR__ . '/functions.php',
            __DIR__ . '/lead-capture.php',
            __DIR__ . '/settings.php',
        ];
        $integrity = [];
        foreach ($integrity_files as $f) {
            if (file_exists($f)) {
                $integrity[basename($f)] = md5_file($f);
            }
        }
        update_option('rnlp_integrity', $integrity);

        set_transient('rnlp_activation_notice', [
            'type' => 'success',
            'msg'  => 'Serial activated successfully. Welcome to RealNex Listings Pro!',
        ], 60);

        wp_safe_redirect(admin_url('admin.php?page=' . $this->slug . '_settings'));
        exit;
    }
}

new RealNexListingsPro();
