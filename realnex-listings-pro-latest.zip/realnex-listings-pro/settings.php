<?php
if (!defined("ABSPATH")) exit;
/**
 * RealNex Listings Pro — Settings Page (tabbed, 4 sections)
 */

// ── Serial validation hook ────────────────────────────────────────────────
add_action('updated_option', 'rnlp_on_settings_saved', 10, 3);

function rnlp_on_settings_saved($option_name, $old_value, $new_value) {
    if ($option_name !== 'api_settings') return;

    $new_serial = $new_value['rnlp_serial'] ?? '';
    $old_serial = $old_value['rnlp_serial'] ?? '';

    // Only re-validate when the serial actually changes
    if (empty($new_serial) || $new_serial === $old_serial) return;

    $resp = wp_remote_post(rnlp_api_url('validate'), [
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => wp_json_encode(['serial' => $new_serial]),
        'timeout' => 15,
    ]);

    if (is_wp_error($resp)) {
        set_transient('rnlp_serial_notice', [
            'type' => 'error',
            'msg'  => 'Could not reach the activation server. Please try again.',
        ], 60);
        return;
    }

    $body = json_decode(wp_remote_retrieve_body($resp), true);

    if (empty($body['valid'])) {
        set_transient('rnlp_serial_notice', [
            'type' => 'error',
            'msg'  => 'Invalid or expired serial number.',
        ], 60);
        delete_option('rnlp_company_id_enc');
        delete_option('rnlp_serial_meta');
        return;
    }

    if (empty($body['plugin_allowed'])) {
        set_transient('rnlp_serial_notice', [
            'type' => 'error',
            'msg'  => 'This serial is for iframe embed access only. Use an MP Premier 2.0 serial to activate the WordPress plugin.',
        ], 60);
        delete_option('rnlp_company_id_enc');
        delete_option('rnlp_serial_meta');
        return;
    }

    // Store encrypted company_id — never shown in admin UI
    update_option('rnlp_company_id_enc', rnlp_encrypt($body['company_id']));
    update_option('rnlp_serial_meta', [
        'plan'           => $body['plan'] ?? 'basic',
        'product_type'   => $body['product_type'] ?? '',
        'iframe_allowed' => !empty($body['iframe_allowed']),
        'plugin_allowed' => !empty($body['plugin_allowed']),
        'expires_at'     => $body['expires_at'] ?? '',
        'valid'          => true,
    ]);
    update_option('rnlp_last_check', time());
    set_transient('rnlp_serial_notice', [
        'type' => 'success',
        'msg'  => 'Serial activated successfully. Plan: ' . esc_html($body['plan'] ?? 'basic') . '.',
    ], 60);
}

// ── Encryption helpers ────────────────────────────────────────────────────

function rnlp_encrypt($plaintext) {
    $key = substr(hash('sha256', wp_salt('auth'), true), 0, 32);
    $iv  = openssl_random_pseudo_bytes(16);
    $enc = openssl_encrypt($plaintext, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv . base64_decode($enc));
}

function rnlp_decrypt($ciphertext) {
    $key = substr(hash('sha256', wp_salt('auth'), true), 0, 32);
    $raw = base64_decode($ciphertext);
    $iv  = substr($raw, 0, 16);
    $enc = base64_encode(substr($raw, 16));
    return openssl_decrypt($enc, 'AES-256-CBC', $key, 0, $iv);
}

// ── Settings registration ─────────────────────────────────────────────────

add_action('admin_init', 'rnlp_settings_init');

function rnlp_settings_init() {
    register_setting('api_settings_group', 'api_settings', [
        'sanitize_callback' => 'rnlp_sanitize_settings',
    ]);
}

function rnlp_sanitize_settings($input) {
    $clean    = [];
    $existing = get_option( 'api_settings', [] );

    // Tab 1 — License: preserve existing serial if the field wasn't in this POST
    // (happens when saving from Display/Agents/CRM tabs which don't include the serial field)
    $submitted_serial = sanitize_text_field( $input['rnlp_serial'] ?? '' );
    $clean['rnlp_serial'] = $submitted_serial !== ''
        ? $submitted_serial
        : ( $existing['rnlp_serial'] ?? '' );
    $api_base = esc_url_raw(rtrim($input['rnlp_api_base_url'] ?? 'https://api.initial3development.com', '/'));
    $clean['rnlp_api_base_url'] = $api_base ?: 'https://api.initial3development.com';

    // Tab 2 — Display
    $clean['rnlp_theme']            = sanitize_key($input['rnlp_theme'] ?? 'classic');
    $clean['layout']               = in_array($input['layout'] ?? 'grid-map', ['grid-map','full-grid','hero-grid','list-view','grid_map','full_grid','hero_grid']) ? $input['layout'] : 'grid-map';
    $clean['bg_style']             = in_array($input['bg_style'] ?? 'light', ['light','dark']) ? $input['bg_style'] : 'light';
    $clean['font_style']           = in_array($input['font_style'] ?? 'modern', ['modern','classic','bold']) ? $input['font_style'] : 'modern';
    $detail_behavior               = $input['detail_behavior'] ?? 'popup';
    $clean['detail_behavior']      = in_array($detail_behavior, ['popup','page','full_page'], true) ? $detail_behavior : 'popup';
    $clean['custom_color']          = sanitize_hex_color($input['custom_color'] ?? '#013161');
    $clean['icons_color']           = sanitize_hex_color($input['icons_color'] ?? '#013161');
    $clean['font_color']            = sanitize_hex_color($input['font_color'] ?? '#ffffff');
    $clean['apiKey_field']          = sanitize_text_field($input['apiKey_field'] ?? '');
    $clean['select_mapType_field']  = in_array($input['select_mapType_field'] ?? '', ['googlemap', 'openstreetmap'])
                                        ? $input['select_mapType_field'] : 'googlemap';
    $clean['select_mapPosition_field'] = in_array($input['select_mapPosition_field'] ?? '', ['left', 'right'])
                                        ? $input['select_mapPosition_field'] : 'left';
    $clean['rnlp_items_per_page']   = in_array((int)($input['rnlp_items_per_page'] ?? 12), [6, 9, 12, 18])
                                        ? (int)$input['rnlp_items_per_page'] : 12;
    $clean['marker_id']             = esc_url_raw($input['marker_id'] ?? '');
    $clean['sold_marker_id']        = esc_url_raw($input['sold_marker_id'] ?? '');
    $clean['select_devMode_field']  = in_array($input['select_devMode_field'] ?? 'no', ['yes', 'no'])
                                        ? $input['select_devMode_field'] : 'no';
    $clean['select_btnRight_field'] = in_array($input['select_btnRight_field'] ?? 'no', ['yes', 'no'])
                                        ? $input['select_btnRight_field'] : 'no';

    // Tab 2 — Property type filters
    $all_parent_types = ['OFC','IND','SCR','V','MF','HC','LH','SPEC','SPORT','AG','BO','MU','RES'];
    $clean['property_type_filters'] = !empty($input['property_type_filters'])
        ? array_values(array_intersect((array)$input['property_type_filters'], $all_parent_types))
        : $all_parent_types;
    $clean['show_type_filter'] = isset($input['show_type_filter']) ? '1' : '';

    // Tab 2 — Listings page toggles
    $bool_on  = ['show_map','show_search','show_avail_filter','show_sort','show_list_toggle',
                 'show_inquire_btn','show_price_on_card','show_badges','show_results_count'];
    $bool_off = ['show_broker_on_card'];
    foreach ($bool_on  as $k) $clean[$k] = isset($input[$k]) ? '1' : '';
    foreach ($bool_off as $k) $clean[$k] = isset($input[$k]) ? '1' : '';

    // Tab 2 — Layout selects
    $clean['map_default_zip']  = preg_replace('/[^0-9]/', '', $input['map_default_zip'] ?? '');
    $clean['map_default_zoom'] = max(1, min(18, (int)($input['map_default_zoom'] ?? 10)));

    $clean['grid_columns']  = in_array($input['grid_columns']  ?? '3', ['2','3','4'])          ? $input['grid_columns']  : '3';
    $clean['card_style']    = in_array($input['card_style']    ?? 'standard', ['standard','minimal','large']) ? $input['card_style'] : 'standard';
    $clean['map_height']    = in_array($input['map_height']    ?? '400', ['300','400','500','full']) ? $input['map_height'] : '400';
    $clean['default_view']  = in_array($input['default_view']  ?? 'grid', ['grid','list'])     ? $input['default_view']  : 'grid';
    $clean['rnlp_items_per_page'] = in_array((int)($input['rnlp_items_per_page'] ?? 12), [6,9,12,18,24]) ? (int)$input['rnlp_items_per_page'] : 12;

    // Tab 2 — Property detail page toggles
    $detail_bool_on  = ['show_property_map','show_demographics','show_neighborhood','show_amenities',
                        'show_deal_room','show_brochure_btn','show_share_btn','show_more_listings',
                        'show_space_table','show_photo_strip','show_featured_badge','show_area_intel'];
    $detail_bool_off = ['show_street_view'];
    foreach ($detail_bool_on  as $k) $clean[$k] = isset($input[$k]) ? '1' : '';
    foreach ($detail_bool_off as $k) $clean[$k] = isset($input[$k]) ? '1' : '';

    // Tab 3 — Agents
    $clean['rnlp_show_agents']      = isset($input['rnlp_show_agents']) ? '1' : '';
    $clean['rnlp_agent_page']       = isset($input['rnlp_agent_page'])  ? '1' : '';
    $clean['rnlp_agent_style']      = in_array($input['rnlp_agent_style'] ?? 'card', ['card', 'list', 'minimal'])
                                        ? $input['rnlp_agent_style'] : 'card';
    // Auto-create agent page if toggled on
    if (!empty($clean['rnlp_agent_page'])) {
        create_page('broker', 'Agent listing');
    }

    // Tab 4 — CRM & Leads
    $clean['rnlp_crm_host']    = esc_url_raw(rtrim($input['rnlp_crm_host'] ?? '', '/'));
    $clean['rnlp_jwt_token']   = sanitize_text_field($input['rnlp_jwt_token'] ?? '');
    $clean['rnlp_show_inquire']= isset($input['rnlp_show_inquire']) ? '1' : '';
    $clean['rnlp_notify_email']= sanitize_email($input['rnlp_notify_email'] ?? '');

    return $clean;
}

// ── Settings page renderer ────────────────────────────────────────────────

function settings_page_of_plugin() {
    $plugin_data    = get_plugin_data(pluginPath() . '/RealNexListingsPro.php');
    $plugin_version = $plugin_data['Version'] ?? '3.0.0';
    $options        = get_option('api_settings', []);

    // Active tab
    $active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'license';
    $tabs = [
        'license' => 'License &amp; Setup',
        'display' => 'Display',
        'agents'  => 'Agents',
        'crm'     => 'CRM &amp; Leads',
    ];

    // Serial meta
    $serial_meta   = get_option('rnlp_serial_meta', []);
    $serial_notice = get_transient('rnlp_serial_notice');
    delete_transient('rnlp_serial_notice');
    $api_status    = function_exists('rnlp_get_api_status') ? rnlp_get_api_status() : [];
    $api_base      = function_exists('rnlp_get_api_base') ? rnlp_get_api_base() : 'https://api.initial3development.com';
    $api_env       = $api_status['environment'] ?? 'production';
    $api_version   = $api_status['version']['body']['version'] ?? '';
    $last_check    = (int) get_option('rnlp_last_check', 0);

    $base_url = admin_url('admin.php?page=rnlp-filter_settings');
    ?>
    <div class="wrap rnlp-settings-wrap">
        <div class="rnlp-settings-header">
            <span class="dashicons dashicons-building rnlp-header-icon"></span>
            <div>
                <h1>RealNex Listings Pro — Settings</h1>
                <span class="rnlp-version-badge">v<?php echo esc_html($plugin_version); ?></span>
            </div>
        </div>

        <?php if ($serial_notice): ?>
        <div class="notice notice-<?php echo $serial_notice['type'] === 'success' ? 'success' : 'error'; ?> is-dismissible">
            <p><?php echo esc_html($serial_notice['msg']); ?></p>
        </div>
        <?php endif; ?>

        <!-- Tab navigation -->
        <nav class="nav-tab-wrapper rnlp-tab-nav">
            <?php foreach ($tabs as $slug => $label): ?>
            <a href="<?php echo esc_url($base_url . '&tab=' . $slug); ?>"
               class="nav-tab <?php echo $active_tab === $slug ? 'nav-tab-active' : ''; ?>">
                <?php echo $label; ?>
            </a>
            <?php endforeach; ?>
        </nav>

        <form action="options.php" method="post">
            <?php settings_fields('api_settings_group'); ?>
            <!-- Hidden field preserves the active tab after save redirect -->
            <input type="hidden" name="rnlp_active_tab" value="<?php echo esc_attr($active_tab); ?>">

            <!-- ── Tab 1: License & Setup ────────────────────────────── -->
            <div class="rnlp-tab-panel <?php echo $active_tab === 'license' ? 'rnlp-tab-active' : ''; ?>">
                <h2>License &amp; Setup</h2>

                <div class="rnlp-security-notice" style="display:flex;align-items:flex-start;gap:12px;padding:14px 18px;background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;margin-bottom:20px;font-size:13px;color:#0c4a6e">
                    <span style="font-size:18px;line-height:1">🔒</span>
                    <div>
                        <strong>Secure by design.</strong> Your property data credentials are securely managed server-side by Initial3 Development. Your serial number is the only key you need — no Company ID or API credentials are ever stored in plain text or exposed to the browser.
                    </div>
                </div>

                <table class="form-table">
                    <tr>
                        <th>API Environment</th>
                        <td>
                            <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 12px;background:<?php echo !empty($api_status['connected']) ? '#d1fae5' : '#fee2e2'; ?>;color:<?php echo !empty($api_status['connected']) ? '#065f46' : '#991b1b'; ?>;border-radius:20px;font-weight:600;font-size:13px">
                                <?php echo !empty($api_status['connected']) ? '&#10003; Connected' : '&#10007; API unavailable'; ?>
                            </span>
                            <p class="description">
                                Environment: <strong><?php echo esc_html($api_env); ?></strong>
                                <?php if ($api_version): ?> · Version: <strong><?php echo esc_html($api_version); ?></strong><?php endif; ?>
                                · Base URL: <code><?php echo esc_html($api_base); ?></code>
                            </p>
                            <?php if (!empty($api_status['message'])): ?>
                            <p class="description"><?php echo esc_html($api_status['message']); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>API / Proxy Base URL</th>
                        <td>
                            <input type="url"
                                name="api_settings[rnlp_api_base_url]"
                                class="regular-text code"
                                value="<?php echo esc_attr($options['rnlp_api_base_url'] ?? 'https://api.initial3development.com'); ?>"
                                placeholder="https://api.initial3development.com">
                            <p class="description">Production default is <code>https://api.initial3development.com</code>. Advanced installs can override this with the <code>RNLP_API_BASE_URL</code> constant or <code>rnlp_api_base_url</code> filter.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Serial Number</th>
                        <td>
                            <input type="text"
                                name="api_settings[rnlp_serial]"
                                class="regular-text code"
                                placeholder="RNLP-XXXX-XXXX-XXXX"
                                value="<?php echo esc_attr($options['rnlp_serial'] ?? ''); ?>"
                                autocomplete="off">
                            <p class="description">Enter your RealNex Listings Pro serial number. Saved serials are validated automatically against the activation server.</p>
                        </td>
                    </tr>
                    <?php if (!empty($serial_meta)): ?>
                    <tr>
                        <th>Activation Status</th>
                        <td>
                            <?php if (!empty($serial_meta['valid'])): ?>
                            <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 12px;background:#d1fae5;color:#065f46;border-radius:20px;font-weight:600;font-size:13px">
                                <span>&#10003;</span> Active
                            </span>
                            <?php else: ?>
                            <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 12px;background:#fee2e2;color:#991b1b;border-radius:20px;font-weight:600;font-size:13px">
                                <span>&#10007;</span> Invalid
                            </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Plan</th>
                        <td><strong><?php echo esc_html(ucfirst($serial_meta['plan'] ?? 'basic')); ?></strong></td>
                    </tr>
                    <tr>
                        <th>Expires</th>
                        <td><?php echo esc_html($serial_meta['expires_at'] ? date('F j, Y', strtotime($serial_meta['expires_at'])) : 'Never'); ?></td>
                    </tr>
                    <tr>
                        <th>Company Source</th>
                        <td>
                            <?php if (get_option('rnlp_company_id_enc')): ?>
                            <strong>Connected through license validation</strong>
                            <p class="description">The company ID/company key relationship is stored encrypted and resolved by the proxy. It is not printed into frontend JavaScript.</p>
                            <?php else: ?>
                            <strong>Missing company ID</strong>
                            <p class="description">Validate a license key to connect the company listing source.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Last Sync / Check</th>
                        <td><?php echo $last_check ? esc_html(date_i18n('F j, Y g:i a', $last_check)) : 'Not checked yet'; ?></td>
                    </tr>
                    <?php endif; ?>
                </table>

                <h3>Available Shortcodes</h3>
                <?php rnlp_shortcode_reference(); ?>
                <h3>Embed Code</h3>
                <?php
                $embed_serial = $options['rnlp_serial'] ?? '';
                $embed_src = $embed_serial ? rnlp_api_url('embed') . '?serial=' . rawurlencode($embed_serial) . '&company=' . rawurlencode(get_bloginfo('name')) : '';
                ?>
                <?php if ($embed_src): ?>
                <textarea class="large-text code" rows="5" readonly><?php echo esc_textarea('<iframe src="' . esc_url($embed_src) . '" width="100%" height="950" frameborder="0" style="border:0;max-width:100%" loading="lazy" title="' . esc_attr(get_bloginfo('name')) . ' Listings"></iframe>'); ?></textarea>
                <p class="description">Iframe embed is fastest to place anywhere. Native shortcode rendering is best for SEO and WordPress theme integration.</p>
                <?php else: ?>
                <p class="description">Enter and validate a serial number to generate iframe embed code.</p>
                <?php endif; ?>
            </div>

            <!-- ── Tab 2: Display ────────────────────────────────────── -->
            <div class="rnlp-tab-panel <?php echo $active_tab === 'display' ? 'rnlp-tab-active' : ''; ?>">
                <h2>Display</h2>

                <!-- ── Layout ─────────────────────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Layout</div>
                    <div class="rnlp-cs-inner">
                        <p class="rnlp-cs-desc">Choose how your listings are displayed to visitors.</p>
                        <div class="rnlp-layout-cards">
                        <?php
                        $cur_layout = $options['layout'] ?? 'grid-map';
                        $layouts = [
                            ['grid-map',  'Grid + Map',   'Listings grid with live map sidebar',          'Companies with many listings'],
                            ['full-grid', 'Full Grid',    'Clean full-width listing grid, no map',         'Maximum listings visible'],
                            ['hero-grid', 'Hero + Grid',  'Spotlight your best listing at the top',        'Single property focus'],
                            ['list-view', 'List View',    'Detailed list with more info per listing',      'Data-focused brokers'],
                        ];
                        foreach ($layouts as [$val, $lbl, $desc, $best]):
                        ?>
                        <label class="rnlp-layout-card<?php if($cur_layout===$val) echo ' rnlp-layout-selected'; ?>">
                            <input type="radio" name="api_settings[layout]" value="<?php echo $val; ?>" <?php checked($cur_layout,$val); ?>>
                            <div class="rnlp-layout-mockup rnlp-mock-<?php echo esc_attr($val); ?>">
                                <?php if($val==='grid-map'): ?>
                                <div class="rnlp-mock-gm"><div class="rnlp-mock-cells3"><div></div><div></div></div><div class="rnlp-mock-map-col"></div></div>
                                <?php elseif($val==='full-grid'): ?>
                                <div class="rnlp-mock-cells3"><div></div><div></div><div></div></div>
                                <?php elseif($val==='hero-grid'): ?>
                                <div class="rnlp-mock-hero-wrap"><div class="rnlp-mock-hero-main"></div><div class="rnlp-mock-cells3 rnlp-mock-sub"><div></div><div></div></div></div>
                                <?php elseif($val==='list-view'): ?>
                                <div class="rnlp-mock-rows"><div></div><div></div><div></div></div>
                                <?php endif; ?>
                            </div>
                            <div class="rnlp-layout-label"><?php echo esc_html($lbl); ?></div>
                            <div class="rnlp-layout-desc"><?php echo esc_html($desc); ?></div>
                            <div class="rnlp-layout-best">Best for: <?php echo esc_html($best); ?></div>
                        </label>
                        <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- ── Brand & Appearance ──────────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Brand &amp; Appearance</div>
                    <div class="rnlp-cs-inner">
                        <div class="rnlp-colors-row">
                            <div class="rnlp-color-group">
                                <label class="rnlp-cs-label">Primary / Accent Color</label>
                                <input type="color" name="api_settings[custom_color]" id="rnlp_primary_color"
                                    value="<?php echo esc_attr($options['custom_color'] ?? '#013161'); ?>">
                                <div class="rnlp-color-presets">
                                <?php foreach(['#013161'=>'Navy','#c9a84c'=>'Gold','#2d6a4f'=>'Forest','#2d2d2d'=>'Charcoal','#6b2737'=>'Burgundy','#475569'=>'Slate'] as $hex=>$nm): ?>
                                <span class="rnlp-color-dot" title="<?php echo esc_attr($nm); ?>"
                                      style="background:<?php echo esc_attr($hex); ?>"
                                      data-color="<?php echo esc_attr($hex); ?>"
                                      onclick="document.getElementById('rnlp_primary_color').value=this.dataset.color"></span>
                                <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="rnlp-color-group">
                                <label class="rnlp-cs-label">Background Style</label>
                                <div class="rnlp-pill-group">
                                <?php foreach(['light'=>'&#9728;&#xFE0F; Light','dark'=>'&#127769; Dark'] as $val=>$lbl): ?>
                                <label class="rnlp-pill-opt<?php if(($options['bg_style']??'light')===$val) echo ' rnlp-pill-active'; ?>">
                                    <input type="radio" name="api_settings[bg_style]" value="<?php echo $val; ?>" <?php checked($options['bg_style']??'light',$val); ?>>
                                    <?php echo $lbl; ?>
                                </label>
                                <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="rnlp-color-group">
                                <label class="rnlp-cs-label">Font Style</label>
                                <div class="rnlp-pill-group">
                                <?php foreach(['modern'=>'Modern','classic'=>'Classic','bold'=>'Bold'] as $val=>$lbl): ?>
                                <label class="rnlp-pill-opt<?php if(($options['font_style']??'modern')===$val) echo ' rnlp-pill-active'; ?>">
                                    <input type="radio" name="api_settings[font_style]" value="<?php echo $val; ?>" <?php checked($options['font_style']??'modern',$val); ?>>
                                    <?php echo esc_html($lbl); ?>
                                </label>
                                <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ── Property Detail Behavior ────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Property Detail Behavior</div>
                    <div class="rnlp-cs-inner">
                        <p class="rnlp-cs-desc">How property details are shown when a visitor clicks a listing.</p>
                        <div class="rnlp-detail-cards">
                        <?php
                        $cur_detail = $options['detail_behavior'] ?? 'popup';
                        $detail_opts = [
                            ['popup','Popup Detail','Property details slide up in a modal overlay. Visitor stays on the same page.','Faster browsing, better UX'],
                            ['page','Full Detail Page','Clicking opens a dedicated property page. Better SEO, each listing gets its own URL.','SEO, sharing individual listings'],
                        ];
                        foreach ($detail_opts as [$val,$lbl,$desc,$best]):
                        ?>
                        <label class="rnlp-detail-card<?php if($cur_detail===$val) echo ' rnlp-layout-selected'; ?>">
                            <input type="radio" name="api_settings[detail_behavior]" value="<?php echo $val; ?>" <?php checked($cur_detail,$val); ?>>
                            <div class="rnlp-detail-icon">
                            <?php if($val==='popup'): ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="28" height="28"><rect x="3" y="3" width="18" height="18" rx="2"/><rect x="5" y="11" width="14" height="9" rx="1" fill="currentColor" opacity=".15"/><line x1="5" y1="8" x2="19" y2="8"/></svg>
                            <?php else: ?>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="28" height="28"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                            <?php endif; ?>
                            </div>
                            <div class="rnlp-detail-label"><?php echo esc_html($lbl); ?></div>
                            <div class="rnlp-detail-desc"><?php echo esc_html($desc); ?></div>
                            <div class="rnlp-layout-best">Best for: <?php echo esc_html($best); ?></div>
                        </label>
                        <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- ── Listings Layout ─────────────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Listings Layout</div>
                    <div class="rnlp-cs-inner">
                        <div class="rnlp-form-grid">
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Grid Columns</label>
                                <?php $gc = $options['grid_columns'] ?? '3'; ?>
                                <select name="api_settings[grid_columns]">
                                    <option value="2" <?php selected($gc,'2'); ?>>2 Columns</option>
                                    <option value="3" <?php selected($gc,'3'); ?>>3 Columns (default)</option>
                                    <option value="4" <?php selected($gc,'4'); ?>>4 Columns</option>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Card Style</label>
                                <?php $cs = $options['card_style'] ?? 'standard'; ?>
                                <select name="api_settings[card_style]">
                                    <option value="standard" <?php selected($cs,'standard'); ?>>Standard</option>
                                    <option value="minimal"  <?php selected($cs,'minimal');  ?>>Minimal</option>
                                    <option value="large"    <?php selected($cs,'large');    ?>>Large</option>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Items Per Page</label>
                                <?php $ipp2 = (int)($options['rnlp_items_per_page'] ?? 12); ?>
                                <select name="api_settings[rnlp_items_per_page]">
                                    <?php foreach ([6,9,12,18,24] as $n): ?>
                                    <option value="<?php echo $n; ?>" <?php selected($ipp2,$n); ?>><?php echo $n; ?> per page</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Default View</label>
                                <?php $dv = $options['default_view'] ?? 'grid'; ?>
                                <select name="api_settings[default_view]">
                                    <option value="grid" <?php selected($dv,'grid'); ?>>Grid</option>
                                    <option value="list" <?php selected($dv,'list'); ?>>List</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ── Listings Page Controls ───────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Listings Page Controls</div>
                    <div class="rnlp-toggle-grid">
                    <?php
                    $lp_toggles = [
                        ['show_map',           'Show Map',                  'Interactive map panel',                    true],
                        ['show_search',        'Show Search Bar',           'Address/city/zip search field',            true],
                        ['show_type_filter',   'Show Type Filter',          'Property type dropdown filter',            true],
                        ['show_avail_filter',  'Show Availability Filter',  'For Lease / For Sale / Sold chips',        true],
                        ['show_sort',          'Show Sort Dropdown',        'Sort by price/size control',               true],
                        ['show_list_toggle',   'Show Grid/List Toggle',     'Grid and list view toggle buttons',        true],
                        ['show_inquire_btn',   'Show Inquire Button',       'Inquire button on listing cards',          true],
                        ['show_price_on_card', 'Show Price on Card',        'Price tag overlay on card image',          true],
                        ['show_badges',        'Show For Sale/Lease Badges','For Sale / For Lease / Sold badge',        true],
                        ['show_broker_on_card','Show Broker on Card',       'Broker name on each listing card',         false],
                        ['show_results_count', 'Show Results Count',        '"132 listings" count above results',       true],
                    ];
                    foreach ($lp_toggles as [$key, $label, $desc, $default]):
                        $checked = $options[$key] ?? ($default ? '1' : '');
                    ?>
                    <div class="rnlp-toggle-row">
                        <div>
                            <div class="rnlp-toggle-label"><?php echo esc_html($label); ?></div>
                            <div class="rnlp-toggle-desc"><?php echo esc_html($desc); ?></div>
                        </div>
                        <label class="rnlp-switch">
                            <input type="checkbox" name="api_settings[<?php echo esc_attr($key); ?>]" value="1" <?php checked($checked, '1'); ?>>
                            <span class="rnlp-slider"></span>
                        </label>
                    </div>
                    <?php endforeach; ?>
                    </div>
                </div>

                <!-- ── Property Type Filters ────────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Property Type Filters</div>
                    <div class="rnlp-cs-inner">
                        <p class="rnlp-cs-desc">Select which types appear in your filter. Uncheck types you don't handle to simplify the interface for clients.</p>
                        <div class="rnlp-preset-row" style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px">
                            <strong style="width:100%;font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.06em">Quick Setup — I specialize in:</strong>
                            <button type="button" class="button" onclick="rnlpSetPreset(['OFC','IND'])">Office &amp; Industrial</button>
                            <button type="button" class="button" onclick="rnlpSetPreset(['SCR'])">Retail</button>
                            <button type="button" class="button" onclick="rnlpSetPreset(['MF'])">Multi-Family</button>
                            <button type="button" class="button" onclick="rnlpSetPreset(['V','AG'])">Land &amp; Development</button>
                            <button type="button" class="button" onclick="rnlpSetPreset(['LH'])">Hospitality</button>
                            <button type="button" class="button button-primary" onclick="rnlpSetPreset(['OFC','IND','SCR','V','MF','HC','LH','SPEC','SPORT','AG','BO','MU','RES'])">All Types</button>
                        </div>
                        <?php
                        $enabled_types = $options['property_type_filters'] ?? ['OFC','IND','SCR','V','MF','HC','LH','SPEC','SPORT','AG','BO','MU','RES'];
                        $type_groups = [
                            'OFC'   => 'Office',
                            'IND'   => 'Industrial',
                            'SCR'   => 'Retail / Shopping Center',
                            'V'     => 'Land',
                            'MF'    => 'Multi-Family',
                            'HC'    => 'Health Care',
                            'LH'    => 'Lodging &amp; Hospitality',
                            'SPEC'  => 'Special Purpose',
                            'SPORT' => 'Sports &amp; Entertainment',
                            'AG'    => 'Agricultural',
                            'BO'    => 'Business Opportunities',
                            'MU'    => 'Mixed Use',
                            'RES'   => 'Residential Income',
                        ];
                        ?>
                        <div class="rnlp-type-filter-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:4px 16px">
                            <?php foreach ($type_groups as $code => $label): ?>
                            <label style="display:flex;align-items:center;gap:8px;padding:5px 0;font-size:13px;cursor:pointer">
                                <input type="checkbox"
                                       class="rnlp-type-filter-check"
                                       name="api_settings[property_type_filters][]"
                                       value="<?php echo esc_attr($code); ?>"
                                       <?php checked(in_array($code, $enabled_types)); ?>>
                                <span><?php echo $label; ?> <code style="font-size:10px;color:#94a3b8"><?php echo esc_html($code); ?></code></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                        <script>
                        function rnlpSetPreset(codes) {
                            document.querySelectorAll('.rnlp-type-filter-check').forEach(function(cb) {
                                cb.checked = codes.indexOf(cb.value) !== -1;
                            });
                        }
                        </script>
                    </div>
                </div>

                <!-- ── Map Settings ─────────────────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Map Settings</div>
                    <div class="rnlp-cs-inner">
                        <div class="rnlp-form-grid">
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Map Provider</label>
                                <?php $map_type = $options['select_mapType_field'] ?? 'googlemap'; ?>
                                <select name="api_settings[select_mapType_field]">
                                    <option value="googlemap"     <?php selected($map_type, 'googlemap'); ?>>Google Maps</option>
                                    <option value="openstreetmap" <?php selected($map_type, 'openstreetmap'); ?>>OpenStreetMap (free)</option>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Map Position</label>
                                <?php $map_pos = $options['select_mapPosition_field'] ?? 'left'; ?>
                                <select name="api_settings[select_mapPosition_field]">
                                    <option value="left"  <?php selected($map_pos, 'left'); ?>>Left</option>
                                    <option value="right" <?php selected($map_pos, 'right'); ?>>Right</option>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Map Height</label>
                                <?php $mh = $options['map_height'] ?? '400'; ?>
                                <select name="api_settings[map_height]">
                                    <option value="300"  <?php selected($mh,'300');  ?>>300px</option>
                                    <option value="400"  <?php selected($mh,'400');  ?>>400px (default)</option>
                                    <option value="500"  <?php selected($mh,'500');  ?>>500px</option>
                                    <option value="full" <?php selected($mh,'full'); ?>>Full height</option>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Default Zoom</label>
                                <?php $mz = (int)($options['map_default_zoom'] ?? 10); ?>
                                <select name="api_settings[map_default_zoom]">
                                    <option value="6"  <?php selected($mz, 6);  ?>>6 — Region</option>
                                    <option value="7"  <?php selected($mz, 7);  ?>>7</option>
                                    <option value="8"  <?php selected($mz, 8);  ?>>8</option>
                                    <option value="9"  <?php selected($mz, 9);  ?>>9</option>
                                    <option value="10" <?php selected($mz, 10); ?>>10 (default)</option>
                                    <option value="11" <?php selected($mz, 11); ?>>11</option>
                                    <option value="12" <?php selected($mz, 12); ?>>12</option>
                                    <option value="13" <?php selected($mz, 13); ?>>13</option>
                                    <option value="14" <?php selected($mz, 14); ?>>14 — Street level</option>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Default Map ZIP</label>
                                <input type="text" name="api_settings[map_default_zip]" class="small-text"
                                    value="<?php echo esc_attr($options['map_default_zip'] ?? ''); ?>"
                                    placeholder="e.g. 10001" maxlength="10">
                                <span class="description">Center map when no markers in view.</span>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Google Maps API Key</label>
                                <input type="text" name="api_settings[apiKey_field]" class="regular-text"
                                    value="<?php echo esc_attr($options['apiKey_field'] ?? ''); ?>">
                                <span class="description">Required only for Google Maps.</span>
                            </div>
                        </div>
                        <div class="rnlp-marker-row">
                            <div class="rnlp-marker-item">
                                <label class="rnlp-fg-label">Active Marker</label>
                                <?php $default_marker = plugin_dir_url(__FILE__) . 'assets/images/marker-active.svg';
                                $marker_val = !empty($options['marker_id']) ? $options['marker_id'] : $default_marker; ?>
                                <input type="text" name="api_settings[marker_id]" id="input_marker_url" class="hidden" value="<?php echo esc_attr($marker_val); ?>">
                                <img class="marker_image" src="<?php echo esc_url($marker_val); ?>" alt="Map Marker" style="width:32px;height:32px;">
                                <div style="margin-top:6px;display:flex;gap:6px">
                                    <a href="#" id="choose_image_button" class="button">Change</a>
                                    <a href="#" id="reset_image_button" class="button" data-path="<?php echo esc_url($default_marker); ?>">Reset</a>
                                </div>
                            </div>
                            <div class="rnlp-marker-item">
                                <label class="rnlp-fg-label">Sold Marker</label>
                                <?php $default_sold = plugin_dir_url(__FILE__) . 'assets/images/marker-sold.svg';
                                $sold_val = !empty($options['sold_marker_id']) ? $options['sold_marker_id'] : $default_sold; ?>
                                <input type="text" name="api_settings[sold_marker_id]" id="sold_input_marker_url" class="hidden" value="<?php echo esc_attr($sold_val); ?>">
                                <img class="sold_marker_image" src="<?php echo esc_url($sold_val); ?>" alt="Sold Marker" style="width:32px;height:32px;">
                                <div style="margin-top:6px;display:flex;gap:6px">
                                    <a href="#" id="choose_image_button_sold" class="button">Change</a>
                                    <a href="#" id="reset_sold_image_button" class="button" data-path="<?php echo esc_url($default_sold); ?>">Reset</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ── Property Detail Page ─────────────────────────────────── -->
                <div class="rnlp-settings-card">
                    <div class="rnlp-sc-head">Property Detail Page</div>
                    <div class="rnlp-toggle-grid">
                    <?php
                    $detail_toggles = [
                        ['show_property_map',  'Show Map',               'Interactive map on the property detail page',                  true],
                        ['show_street_view',   'Show Street View',       'Google Street View button (requires Google Maps API key)',     false],
                        ['show_demographics',  'Show Demographics',      'Census demographics (population, income, home value)',         true],
                        ['show_neighborhood',  'Show Neighborhood',      'Nominatim neighborhood name',                                 true],
                        ['show_amenities',     'Show Nearby Amenities',  'OpenStreetMap amenities within 500m',                         true],
                        ['show_deal_room',     'Show Deal Room Button',  'RealNex deal room link (Active listings only)',               true],
                        ['show_brochure_btn',  'Show Brochure Button',   'Download brochure PDF button',                                true],
                        ['show_share_btn',     'Show Share Button',      'Copy link / share property button',                           true],
                        ['show_more_listings', 'Show More From Broker',  '"More from this broker" related listings section',            true],
                        ['show_space_table',   'Show Space Table',       'Available spaces table',                                      true],
                        ['show_photo_strip',   'Show Photo Strip',       'Thumbnail strip below hero image',                            true],
                        ['show_featured_badge','Show Featured Badge',    'Gold "Featured" badge overlay on hero image',                 true],
                        ['show_area_intel',    'Show Area Intelligence', 'Walk Score, traffic, environment &amp; demographics dashboard', true],
                    ];
                    foreach ($detail_toggles as [$key, $label, $desc, $default]):
                        $checked = $options[$key] ?? ($default ? '1' : '');
                    ?>
                    <div class="rnlp-toggle-row">
                        <div>
                            <div class="rnlp-toggle-label"><?php echo esc_html($label); ?></div>
                            <div class="rnlp-toggle-desc"><?php echo esc_html($desc); ?></div>
                        </div>
                        <label class="rnlp-switch">
                            <input type="checkbox" name="api_settings[<?php echo esc_attr($key); ?>]" value="1" <?php checked($checked, '1'); ?>>
                            <span class="rnlp-slider"></span>
                        </label>
                    </div>
                    <?php endforeach; ?>
                    </div>
                    <div class="rnlp-cs-inner" style="border-top:1px solid #e2e8f0">
                        <div class="rnlp-form-grid">
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Brochure &amp; Video Buttons</label>
                                <?php $btn_right = $options['select_btnRight_field'] ?? 'no'; ?>
                                <select name="api_settings[select_btnRight_field]">
                                    <option value="no"  <?php selected($btn_right, 'no'); ?>>Hide buttons</option>
                                    <option value="yes" <?php selected($btn_right, 'yes'); ?>>Show buttons</option>
                                </select>
                            </div>
                            <div class="rnlp-fg-item">
                                <label class="rnlp-fg-label">Dev Mode</label>
                                <?php $dev = $options['select_devMode_field'] ?? 'no'; ?>
                                <select name="api_settings[select_devMode_field]">
                                    <option value="no"  <?php selected($dev, 'no'); ?>>Off</option>
                                    <option value="yes" <?php selected($dev, 'yes'); ?>>On</option>
                                </select>
                                <span class="description">Outputs raw API response for debugging.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ── Tab 3: Agents ─────────────────────────────────────── -->
            <div class="rnlp-tab-panel <?php echo $active_tab === 'agents' ? 'rnlp-tab-active' : ''; ?>">
                <h2>Agents</h2>
                <table class="form-table">
                    <tr>
                        <th>Show Agent Roster</th>
                        <td>
                            <label>
                                <input type="checkbox" name="api_settings[rnlp_show_agents]" value="1"
                                    <?php checked($options['rnlp_show_agents'] ?? '', '1'); ?>>
                                Display an agent roster using the <code>[broker]</code> shortcode
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>Separate Agent Page</th>
                        <td>
                            <label>
                                <input type="checkbox" name="api_settings[rnlp_agent_page]" value="1"
                                    <?php checked($options['rnlp_agent_page'] ?? '', '1'); ?>>
                                Auto-create a dedicated "Agent listing" page (creates page with <code>[broker]</code> shortcode if it doesn't exist)
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>Agent Card Style</th>
                        <td>
                            <?php $agent_style = $options['rnlp_agent_style'] ?? 'card'; ?>
                            <select name="api_settings[rnlp_agent_style]">
                                <option value="card"    <?php selected($agent_style, 'card'); ?>>Card</option>
                                <option value="list"    <?php selected($agent_style, 'list'); ?>>List</option>
                                <option value="minimal" <?php selected($agent_style, 'minimal'); ?>>Minimal</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- ── Tab 4: CRM & Leads ────────────────────────────────── -->
            <div class="rnlp-tab-panel <?php echo $active_tab === 'crm' ? 'rnlp-tab-active' : ''; ?>">
                <h2>CRM &amp; Leads</h2>
                <p>When configured, an "Inquire" button appears on property cards. Submissions create a contact in RealNex CRM and optionally link to a project.</p>
                <table class="form-table">
                    <tr>
                        <th>CRM Host URL</th>
                        <td>
                            <input type="text" name="api_settings[rnlp_crm_host]" class="regular-text"
                                placeholder="https://sync.realnex.com"
                                value="<?php echo esc_attr($options['rnlp_crm_host'] ?? ''); ?>">
                            <p class="description">Your RealNex CRM base URL — no trailing slash.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>API JWT Token</th>
                        <td>
                            <input type="password" name="api_settings[rnlp_jwt_token]" class="regular-text"
                                placeholder="eyJhbGci…"
                                value="<?php echo esc_attr($options['rnlp_jwt_token'] ?? ''); ?>"
                                autocomplete="off">
                            <p class="description">Web API Key from Setup &rarr; Users &rarr; Web API Keys. Used to search and update existing contacts, create new contacts, link to projects, log inquiry history notes, and write leads directly into RealNex CRM.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Inquire Button</th>
                        <td>
                            <label>
                                <input type="checkbox" name="api_settings[rnlp_show_inquire]" value="1"
                                    <?php checked($options['rnlp_show_inquire'] ?? '', '1'); ?>>
                                Show "Inquire" button on property cards
                            </label>
                            <p class="description">Requires CRM Host and JWT token above.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Notify Email</th>
                        <td>
                            <input type="email" name="api_settings[rnlp_notify_email]" class="regular-text"
                                value="<?php echo esc_attr($options['rnlp_notify_email'] ?? get_bloginfo('admin_email')); ?>">
                            <p class="description">Notified when a lead is submitted. Leave blank to disable.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <?php submit_button('Save Settings'); ?>
        </form>
    </div>

    <style>
    .rnlp-tab-panel { display: none; }
    .rnlp-tab-panel.rnlp-tab-active { display: block; }
    .rnlp-settings-header { display:flex;align-items:center;gap:12px;margin-bottom:16px; }
    .rnlp-header-icon { font-size:28px;color:#013161; }
    .rnlp-version-badge { display:inline-block;padding:2px 10px;background:#e0e7ff;color:#3730a3;border-radius:12px;font-size:11px;font-weight:700; }
    .rnlp-theme-grid { display:flex;flex-wrap:wrap;gap:10px;margin-top:4px; }
    .rnlp-theme-card { display:flex;flex-direction:column;gap:3px;padding:10px 14px;border:2px solid #e2e8f0;border-radius:8px;cursor:pointer;transition:border-color .15s;min-width:140px; }
    .rnlp-theme-card:has(input:checked), .rnlp-theme-active { border-color:#013161; }
    .rnlp-theme-card input { display:none; }
    .rnlp-theme-name { font-weight:600;font-size:13px; }
    .rnlp-theme-desc { font-size:11px;color:#64748b; }
    .rnlp-theme-preview { font-size:10px;color:#94a3b8; }
    .rnlp-shortcode-table { width:100%;border-collapse:collapse;margin-top:8px; }
    /* ── Customizer sections ── */
    .rnlp-cs-section { padding:20px 24px;border-bottom:1px solid #e2e8f0; }
    .rnlp-cs-title { font-size:14px;font-weight:700;color:#0f172a;margin:0 0 4px; }
    .rnlp-cs-desc { font-size:12px;color:#64748b;margin:0 0 14px; }
    .rnlp-cs-label { display:block;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:#64748b;margin-bottom:6px; }
    /* Layout cards */
    .rnlp-layout-cards { display:flex;gap:10px;flex-wrap:wrap; }
    .rnlp-layout-card { flex:1;min-width:140px;max-width:190px;border:2px solid #e2e8f0;border-radius:10px;padding:12px;cursor:pointer;transition:border-color .15s;position:relative;display:flex;flex-direction:column;gap:4px; }
    .rnlp-layout-card input { display:none; }
    .rnlp-layout-selected { border-color:#013161;box-shadow:0 0 0 3px rgba(1,49,97,.1); }
    .rnlp-layout-mockup { height:64px;background:#f1f5f9;border-radius:6px;margin-bottom:8px;overflow:hidden;padding:6px; }
    .rnlp-layout-label { font-size:13px;font-weight:700;color:#1e293b; }
    .rnlp-layout-desc { font-size:11px;color:#64748b; }
    .rnlp-layout-best { font-size:10px;color:#94a3b8;margin-top:2px; }
    /* CSS mockups */
    .rnlp-mock-gm { display:flex;gap:3px;height:100%; }
    .rnlp-mock-cells3 { display:grid;grid-template-columns:repeat(3,1fr);gap:3px;flex:1; }
    .rnlp-mock-cells3 div { background:#cbd5e1;border-radius:2px; }
    .rnlp-mock-map-col { width:28%;background:#93c5fd;border-radius:2px;opacity:.7; }
    .rnlp-mock-gm .rnlp-mock-cells3 { grid-template-columns:repeat(2,1fr); }
    .rnlp-mock-rows { display:flex;flex-direction:column;gap:3px;height:100%; }
    .rnlp-mock-rows div { background:#cbd5e1;border-radius:2px;flex:1;display:flex;align-items:center;padding-left:6px; }
    .rnlp-mock-rows div::before { content:'';width:20px;height:70%;background:#94a3b8;border-radius:2px;margin-right:4px; }
    .rnlp-mock-hero-wrap { display:flex;flex-direction:column;gap:3px;height:100%; }
    .rnlp-mock-hero-main { background:#93c5fd;border-radius:2px;flex:2;opacity:.8; }
    .rnlp-mock-sub { grid-template-columns:repeat(2,1fr);flex:1; }
    /* Color presets */
    .rnlp-colors-row { display:flex;gap:24px;flex-wrap:wrap;align-items:flex-start; }
    .rnlp-color-group { display:flex;flex-direction:column;gap:6px; }
    .rnlp-color-presets { display:flex;gap:6px;margin-top:4px; }
    .rnlp-color-dot { width:22px;height:22px;border-radius:50%;cursor:pointer;border:2px solid rgba(0,0,0,.1);transition:transform .15s,box-shadow .15s;display:inline-block; }
    .rnlp-color-dot:hover { transform:scale(1.2); }
    .rnlp-color-dot-active { box-shadow:0 0 0 3px #fff,0 0 0 5px #013161;transform:scale(1.1); }
    /* Pills */
    .rnlp-pill-group { display:flex;gap:6px; }
    .rnlp-pill-opt { padding:6px 14px;border:1.5px solid #e2e8f0;border-radius:20px;font-size:12px;font-weight:500;cursor:pointer;transition:all .15s; }
    .rnlp-pill-opt input { display:none; }
    .rnlp-pill-active { border-color:#013161;background:#eff6ff;color:#013161; }
    /* Detail behavior cards */
    .rnlp-detail-cards { display:flex;gap:12px; }
    .rnlp-detail-card { flex:1;max-width:300px;border:2px solid #e2e8f0;border-radius:10px;padding:16px;cursor:pointer;transition:border-color .15s;display:flex;flex-direction:column;gap:4px; }
    .rnlp-detail-card input { display:none; }
    .rnlp-detail-icon { color:#013161;margin-bottom:4px; }
    .rnlp-detail-label { font-size:13px;font-weight:700;color:#1e293b; }
    .rnlp-detail-desc { font-size:11px;color:#64748b; }
    .rnlp-shortcode-table th,.rnlp-shortcode-table td { padding:8px 12px;border:1px solid #e2e8f0;font-size:13px; }
    .rnlp-shortcode-table th { background:#f8fafc; }
    /* Settings cards */
    .rnlp-settings-card { border:1px solid #e2e8f0;border-radius:10px;overflow:hidden;margin-bottom:14px;background:#fff; }
    .rnlp-sc-head { font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#64748b;padding:9px 16px;background:#f8fafc;border-bottom:1px solid #e2e8f0; }
    .rnlp-cs-inner { padding:16px 20px; }
    .rnlp-settings-card > .rnlp-cs-section { border-bottom:none;padding:16px 20px; }
    /* Form grid (2-col) */
    .rnlp-form-grid { display:grid;grid-template-columns:1fr 1fr;gap:12px 20px; }
    .rnlp-fg-item { display:flex;flex-direction:column;gap:4px; }
    .rnlp-fg-label { font-size:12px;font-weight:600;color:#374151; }
    .rnlp-fg-item select,.rnlp-fg-item input[type=text] { width:100%;box-sizing:border-box; }
    .rnlp-fg-item .description { font-size:11px;color:#94a3b8;margin:0; }
    /* Toggle grid (2-col) */
    .rnlp-toggle-grid { display:grid;grid-template-columns:1fr 1fr; }
    .rnlp-toggle-grid .rnlp-toggle-row { border-bottom:1px solid #f1f5f9;background:#fff; }
    .rnlp-toggle-grid .rnlp-toggle-row:nth-child(odd) { border-right:1px solid #f1f5f9; }
    /* Marker row */
    .rnlp-marker-row { display:flex;gap:32px;margin-top:16px;padding-top:16px;border-top:1px solid #e2e8f0; }
    .rnlp-marker-item { display:flex;flex-direction:column;gap:6px; }
    /* iOS-style toggles */
    .rnlp-toggle-section { border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;margin-bottom:16px; }
    .rnlp-toggle-row { display:flex;align-items:center;justify-content:space-between;padding:10px 16px;border-bottom:1px solid #f1f5f9;background:#fff; }
    .rnlp-toggle-row:last-child { border-bottom:none; }
    .rnlp-toggle-label { font-size:13px;font-weight:500;color:#1e293b; }
    .rnlp-toggle-desc { font-size:11px;color:#94a3b8;margin-top:2px; }
    .rnlp-switch { position:relative;width:44px;height:24px;flex-shrink:0; }
    .rnlp-switch input { opacity:0;width:0;height:0; }
    .rnlp-slider { position:absolute;cursor:pointer;inset:0;background:#cbd5e1;border-radius:24px;transition:.3s; }
    .rnlp-slider:before { content:'';position:absolute;width:18px;height:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s; }
    input:checked + .rnlp-slider { background:#013161; }
    input:checked + .rnlp-slider:before { transform:translateX(20px); }
    </style>
    <?php
}

// ── Theme picker ──────────────────────────────────────────────────────────

function rnlp_theme_render($options) {
    $current = $options['rnlp_theme'] ?? 'classic';
    $themes  = [
        'classic'    => ['label' => 'Classic',    'desc' => 'Clean white, professional',   'preview' => '#fff / #013161'],
        'dark-pro'   => ['label' => 'Dark Pro',   'desc' => 'Sleek dark, high contrast',   'preview' => '#0d1117 / #3b82f6'],
        'steel-blue' => ['label' => 'Steel Blue', 'desc' => 'Corporate navy & steel',      'preview' => '#1e2d4d / #64b5f6'],
        'ember'      => ['label' => 'Ember',      'desc' => 'Warm charcoal & orange',      'preview' => '#1a1a1a / #f97316'],
    ];
    echo '<div class="rnlp-theme-grid">';
    foreach ($themes as $key => $t) {
        printf(
            '<label class="rnlp-theme-card %s">
                <input type="radio" name="api_settings[rnlp_theme]" value="%s" %s>
                <span class="rnlp-theme-name">%s</span>
                <span class="rnlp-theme-desc">%s</span>
                <code class="rnlp-theme-preview">%s</code>
            </label>',
            $current === $key ? 'rnlp-theme-active' : '',
            esc_attr($key),
            checked($current, $key, false),
            esc_html($t['label']),
            esc_html($t['desc']),
            esc_html($t['preview'])
        );
    }
    echo '</div>';
}

// ── Shortcode reference table ─────────────────────────────────────────────

function rnlp_shortcode_reference() {
    echo '<table class="rnlp-shortcode-table">
    <thead><tr><th>Shortcode</th><th>Description</th></tr></thead>
    <tbody>
    <tr><td><code>[company]</code></td><td>All listings for your serial&rsquo;s company</td></tr>
    <tr><td><code>[company id=12345]</code></td><td>Listings filtered to specific company ID(s)</td></tr>
    <tr><td><code>[company types=OFC,HC]</code></td><td>Filter by property type</td></tr>
    <tr><td><code>[company avail=1,2]</code></td><td>Filter by availability (1=Sale, 2=Lease, 4=Wanted, 16=Sold)</td></tr>
    <tr><td><code>[broker]</code></td><td>Listings by Broker/Agent ID (from settings default)</td></tr>
    <tr><td><code>[broker id=12345]</code></td><td>Listings for a specific agent</td></tr>
    <tr><td><code>[property id=12345]</code></td><td>Single property page</td></tr>
    <tr><td><code>[property-widget id=12345]</code></td><td>Compact property widget</td></tr>
    <tr><td><code>[property-featured]</code></td><td>Horizontal scroll row of featured listings</td></tr>
    <tr><td><code>[property-reduced]</code></td><td>Price-reduced listings with ribbon badge</td></tr>
    </tbody>
    </table>';
}

// ── Legacy field renderers (kept for backward compat) ─────────────────────

function apiKey_field_render() {
    $val = get_option('api_settings')['apiKey_field'] ?? '';
    echo '<input type="text" name="api_settings[apiKey_field]" size="42" value="' . esc_attr($val) . '">';
}

function brokerId_field_render() {
    // Removed — serial-based auth replaces direct broker ID storage
    echo '<p class="description">Broker filtering is now handled via shortcode attributes: <code>[broker id=12345]</code></p>';
}

function companyId_field_render() {
    // Removed — company_id is now stored encrypted from serial validation
    echo '<p class="description">Company ID is now managed via your serial number. Go to the <strong>License &amp; Setup</strong> tab.</p>';
    create_page('company', 'Company listing');
    create_page('broker', 'Agent listing');
}

// ── Page creation helpers ──────────────────────────────────────────────────

function page_got_by_title($title) {
    $query = new WP_Query([
        'post_type'              => 'page',
        'title'                  => $title,
        'post_status'            => 'all',
        'posts_per_page'         => 1,
        'no_found_rows'          => true,
        'ignore_sticky_posts'    => true,
        'update_post_term_cache' => false,
        'update_post_meta_cache' => false,
        'orderby'                => 'post_date ID',
        'order'                  => 'ASC',
    ]);
    return !empty($query->post) ? $query->post : null;
}

function create_page($type, $title) {
    if (empty(page_got_by_title($title))) {
        wp_insert_post([
            'comment_status' => 'close',
            'post_author'    => 1,
            'post_title'     => ucwords($title),
            'post_name'      => strtolower(str_replace(' ', '-', trim($title))),
            'post_status'    => 'publish',
            'post_content'   => '[' . $type . ']',
            'post_type'      => 'page',
        ]);
    }
}

// ── Description (legacy, used by old settings renderer) ───────────────────

function description() {
    rnlp_shortcode_reference();
}
