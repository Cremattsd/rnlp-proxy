<?php
/**
 * RealNex Listings Pro — Uninstall
 * Runs when the plugin is deleted from the WordPress admin.
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete all plugin options
delete_option('api_settings');
delete_option('rnlp_serial_meta');
delete_option('rnlp_company_id_enc');
delete_option('rnlp_registered_domain');
delete_option('rnlp_serial_status');
delete_option('rnlp_last_check');
delete_option('rnlp_integrity');

// Flush rewrite rules (removes /property/ and /rnlp-sitemap.xml rules)
flush_rewrite_rules();

// Delete all rnlp_ prefixed transients from the options table
global $wpdb;
$wpdb->query(
    "DELETE FROM {$wpdb->options}
     WHERE option_name LIKE '_transient_rnlp_%'
        OR option_name LIKE '_transient_timeout_rnlp_%'"
);

// Multisite: clean sub-sites
if (is_multisite()) {
    $site_ids = get_sites(['fields' => 'ids', 'number' => 0]);
    foreach ($site_ids as $site_id) {
        switch_to_blog($site_id);
        delete_option('api_settings');
        delete_option('rnlp_serial_meta');
        delete_option('rnlp_company_id_enc');
        delete_option('rnlp_registered_domain');
        delete_option('rnlp_serial_status');
        delete_option('rnlp_last_check');
        delete_option('rnlp_integrity');
        flush_rewrite_rules();
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_rnlp_%'
                OR option_name LIKE '_transient_timeout_rnlp_%'"
        );
        restore_current_blog();
    }
}
